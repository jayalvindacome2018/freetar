/**
 * 							NativeFmodEx Project
 *
 * Do you want to use FMOD Ex API (www.fmod.org) with the Java language ? I've created NativeFmodEx for you.
 * Copyright � 2005-2006 J�r�me JOUVIE (Jouvieje)
 *
 * Created on 23 feb. 2005
 * @version file v1.0.0
 * @author J�r�me JOUVIE (Jouvieje)
 * 
 * 
 * WANT TO CONTACT ME ?
 * E-mail :
 * 		jerome.jouvie@gmail.com
 * My web sites :
 * 		http://jerome.jouvie.free.fr/
 * 		http://topresult.tomato.co.uk/~jerome/
 * 
 * 
 * INTRODUCTION
 * FMOD Ex is an API (Application Programming Interface) that allow you to use music
 * and creating sound effects with a lot of sort of musics.
 * FMOD is at :
 * 		http://www.fmod.org/
 * The reason of this project is that FMOD Ex can't be used direcly with Java, so I've created
 * this project to do this.
 * 
 * 
 * GNU LESSER GENERAL PUBLIC LICENSE
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of the License,
 * or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA 
 */

package org.jouvieje.FmodEx.Structures;

import org.jouvieje.FmodEx.*;
import org.jouvieje.FmodEx.Exceptions.*;
import org.jouvieje.FmodEx.Callbacks.*;
import org.jouvieje.FmodEx.*;
import org.jouvieje.FmodEx.Defines.*;
import org.jouvieje.FmodEx.Enumerations.*;
import org.jouvieje.FmodEx.Structures.*;
import java.nio.*;
import org.jouvieje.FmodEx.Misc.*;
import org.jouvieje.FmodEx.Defines.FMOD_REVERB_PRESETS;

/**
 * <BR>
 * <BR>
 * Structure defining a reverb environment.<BR>
 * <BR>
 * For more indepth descriptions of the reverb properties under win32, please see the EAX2 and EAX3<BR>
 * documentation at http://developer.creative.com/ under the 'downloads' section.<BR>
 * If they do not have the EAX3 documentation, then most information can be attained from<BR>
 * the EAX2 documentation, as EAX3 only adds some more parameters and functionality on top of<BR>
 * EAX2.<BR>
 * <BR>
 * <BR><U><B>Remarks</B></U><BR><BR>
 * Note the default reverb properties are the same as the FMOD_PRESET_GENERIC preset.<BR>
 * Note that integer values that typically range from -10,000 to 1000 are represented in<BR>
 * decibels, and are of a logarithmic scale, not linear, wheras float values are always linear.<BR>
 * PORTABILITY: Each member has the platform it supports in braces ie (win32/Xbox).<BR>
 * Some reverb parameters are only supported in win32 and some only on Xbox. If all parameters are set then<BR>
 * the reverb should product a similar effect on either platform.<BR>
 * Win32/Win64 - This is only supported with FMOD_OUTPUTTYPE_DSOUND and EAX/I3DL2 compatible sound cards.<BR>
 * Xbox - A subset of parameters are supported.<BR>
 * Xbox360 - A subset of parameters are supported.<BR>
 * PlayStation 2 - Only the Environment and Flags paramenters are supported.<BR>
 * GameCube - Only a subset of parameters are supported.<BR>
 * Software - Only 'Room' is supported.<BR>
 * <BR>
 * The numerical values listed below are the maximum, minimum and default values for each variable respectively.<BR>
 * <BR>
 * Members marked with [in] mean the user sets the value before passing it to the function.<BR>
 * Members marked with [out] mean FMOD sets the value to be used after the function exits.<BR>
 * <BR>
 * <BR><U><B>Platforms Supported</B></U><BR><BR>
 * Win32, Win64, Xbox, Xbox360, PlayStation 2, GameCube, PlayStation Portable, PlayStation 3<BR>
 * <BR>
 * <BR><U><B>See Also</B></U><BR><BR>
 * System::setReverbProperties<BR>
 * System::getReverbProperties<BR>
 * FMOD_REVERB_PRESETS<BR>
 * FMOD_REVERB_FLAGS<BR>
 * 
 */
public class FMOD_REVERB_PROPERTIES extends Pointer
{
	/**
	 * Create an <code>FMOD_REVERB_PROPERTIES</code> using a preset <code>FMOD_REVERB_PRESETS</code>.<br>
	 * @param preset a preset of the interface <code>FMOD_REVERB_PRESETS</code>.
	 * @see org.jouvieje.FmodEx.Defines.FMOD_REVERB_PRESETS
	 */
	public static FMOD_REVERB_PROPERTIES create(int preset)
	{
		switch(preset)
		{
			case FMOD_REVERB_PRESETS.FMOD_PRESET_OFF: 				return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_OFF());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_GENERIC: 			return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_GENERIC());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_PADDEDCELL: 		return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_PADDEDCELL());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_ROOM: 				return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_ROOM());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_BATHROOM: 			return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_BATHROOM());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_LIVINGROOM: 		return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_LIVINGROOM());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_STONEROOM: 		return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_STONEROOM());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_AUDITORIUM: 		return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_AUDITORIUM());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_CONCERTHALL: 		return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_CONCERTHALL());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_CAVE: 				return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_CAVE());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_ARENA: 			return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_ARENA());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_HANGAR: 			return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_HANGAR());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_CARPETTEDHALLWAY: 	return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_CARPETTEDHALLWAY());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_HALLWAY: 			return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_HALLWAY());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_STONECORRIDOR: 	return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_STONECORRIDOR());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_ALLEY: 			return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_ALLEY());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_FOREST: 			return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_FOREST());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_CITY: 				return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_CITY());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_MOUNTAINS: 		return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_MOUNTAINS());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_QUARRY: 			return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_QUARRY());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_PLAIN: 			return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_PLAIN());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_PARKINGLOT: 		return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_PARKINGLOT());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_SEWERPIPE: 		return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_SEWERPIPE());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_UNDERWATER: 		return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_UNDERWATER());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_DRUGGED: 			return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_DRUGGED());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_DIZZY: 			return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_DIZZY());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_PSYCHOTIC: 		return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_PSYCHOTIC());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_PS2_ROOM: 			return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_PS2_ROOM());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_PS2_STUDIO_A: 		return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_PS2_STUDIO_A());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_PS2_STUDIO_B: 		return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_PS2_STUDIO_B());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_PS2_STUDIO_C: 		return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_PS2_STUDIO_C());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_PS2_HALL: 			return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_PS2_HALL());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_PS2_SPACE: 		return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_PS2_SPACE());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_PS2_ECHO: 			return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_PS2_ECHO());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_PS2_DELAY: 		return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_PS2_DELAY());
			case FMOD_REVERB_PRESETS.FMOD_PRESET_PS2_PIPE: 			return new FMOD_REVERB_PROPERTIES(StructureJNI.get_FMOD_PRESET_PS2_PIPE());
			default : return create();
		}
	}
	/**
	 * Create a view of the <code>Pointer</code> object as a <code>FMOD_REVERB_PROPERTIES</code> object.<br>
	 * This view is valid only if the memory holded by the <code>Pointer</code> holds a FMOD_REVERB_PROPERTIES object.
	 */
	public static FMOD_REVERB_PROPERTIES createView(Pointer pointer)
	{
		return new FMOD_REVERB_PROPERTIES(Pointer.getPointer(pointer));
	}
	/**
	 * Create a new <code>FMOD_REVERB_PROPERTIES</code>.<br>
	 * The call <code>isNull()</code> on the object created will return false.<br>
	 * <pre><code>  FMOD_REVERB_PROPERTIES obj = FMOD_REVERB_PROPERTIES.create();
	 *  (obj == null) <=> obj.isNull() <=> false
	 * </code></pre>
	 */
	public static FMOD_REVERB_PROPERTIES create()
	{
		return new FMOD_REVERB_PROPERTIES(StructureJNI.FMOD_REVERB_PROPERTIES_new());
	}

	protected FMOD_REVERB_PROPERTIES(long pointer)
	{
		super(pointer);
	}

	/**
	 * Create an object that holds a null <code>FMOD_REVERB_PROPERTIES</code>.<br>
	 * The call <code>isNull()</code> on the object created will returns true.<br>
	 * <pre><code>  FMOD_REVERB_PROPERTIES obj = new FMOD_REVERB_PROPERTIES();
	 *  (obj == null) <=> false
	 *  obj.isNull() <=> true
	 * </code></pre>
	 * To creates a new <code>FMOD_REVERB_PROPERTIES</code>, use the static "constructor" :
	 * <pre><code>  FMOD_REVERB_PROPERTIES obj = FMOD_REVERB_PROPERTIES.create();</code></pre>
	 * @see FMOD_REVERB_PROPERTIES#create()
	 */
	public FMOD_REVERB_PROPERTIES()
	{
		super();
	}

	public void release()
	{
		if(pointer != 0)
		{
			StructureJNI.FMOD_REVERB_PROPERTIES_delete(pointer);
		}
		pointer = 0;
	}

	/**
	 * [in]     0     , 2     , 0      , EAX4/GameCube only. Environment Instance. 3 (2 for GameCube) seperate reverbs simultaneously are possible. This specifies which one to set. (win32/GameCube)
	 */
	public int getInstance()
	{
		if(pointer == 0) throw new NullPointerException();
		int result_ = StructureJNI.FMOD_REVERB_PROPERTIES_get_Instance(pointer);
		return result_;
	}
	public void setInstance(int Instance)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_PROPERTIES_set_Instance(pointer, Instance);
	}

	/**
	 * [in/out] -1    , 25    , -1     , sets all listener properties.  -1 = OFF. (win32/ps2)
	 */
	public int getEnvironment()
	{
		if(pointer == 0) throw new NullPointerException();
		int result_ = StructureJNI.FMOD_REVERB_PROPERTIES_get_Environment(pointer);
		return result_;
	}
	public void setEnvironment(int Environment)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_PROPERTIES_set_Environment(pointer, Environment);
	}

	/**
	 * [in/out] 1.0   , 100.0 , 7.5    , environment size in meters (win32 only)
	 */
	public float getEnvSize()
	{
		if(pointer == 0) throw new NullPointerException();
		float result_ = StructureJNI.FMOD_REVERB_PROPERTIES_get_EnvSize(pointer);
		return result_;
	}
	public void setEnvSize(float EnvSize)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_PROPERTIES_set_EnvSize(pointer, EnvSize);
	}

	/**
	 * [in/out] 0.0   , 1.0   , 1.0    , environment diffusion (win32/Xbox/GameCube)
	 */
	public float getEnvDiffusion()
	{
		if(pointer == 0) throw new NullPointerException();
		float result_ = StructureJNI.FMOD_REVERB_PROPERTIES_get_EnvDiffusion(pointer);
		return result_;
	}
	public void setEnvDiffusion(float EnvDiffusion)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_PROPERTIES_set_EnvDiffusion(pointer, EnvDiffusion);
	}

	/**
	 * [in/out] -10000, 0     , -1000  , room effect level (at mid frequencies) (win32/Xbox/Xbox 360/GameCube/software)
	 */
	public int getRoom()
	{
		if(pointer == 0) throw new NullPointerException();
		int result_ = StructureJNI.FMOD_REVERB_PROPERTIES_get_Room(pointer);
		return result_;
	}
	public void setRoom(int Room)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_PROPERTIES_set_Room(pointer, Room);
	}

	/**
	 * [in/out] -10000, 0     , -100   , relative room effect level at high frequencies (win32/Xbox/Xbox 360)
	 */
	public int getRoomHF()
	{
		if(pointer == 0) throw new NullPointerException();
		int result_ = StructureJNI.FMOD_REVERB_PROPERTIES_get_RoomHF(pointer);
		return result_;
	}
	public void setRoomHF(int RoomHF)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_PROPERTIES_set_RoomHF(pointer, RoomHF);
	}

	/**
	 * [in/out] -10000, 0     , 0      , relative room effect level at low frequencies (win32 only)
	 */
	public int getRoomLF()
	{
		if(pointer == 0) throw new NullPointerException();
		int result_ = StructureJNI.FMOD_REVERB_PROPERTIES_get_RoomLF(pointer);
		return result_;
	}
	public void setRoomLF(int RoomLF)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_PROPERTIES_set_RoomLF(pointer, RoomLF);
	}

	/**
	 * [in/out] 0.1   , 20.0  , 1.49   , reverberation decay time at mid frequencies (win32/Xbox/Xbox 360/GameCube)
	 */
	public float getDecayTime()
	{
		if(pointer == 0) throw new NullPointerException();
		float result_ = StructureJNI.FMOD_REVERB_PROPERTIES_get_DecayTime(pointer);
		return result_;
	}
	public void setDecayTime(float DecayTime)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_PROPERTIES_set_DecayTime(pointer, DecayTime);
	}

	/**
	 * [in/out] 0.1   , 2.0   , 0.83   , high-frequency to mid-frequency decay time ratio (win32/Xbox/Xbox 360)
	 */
	public float getDecayHFRatio()
	{
		if(pointer == 0) throw new NullPointerException();
		float result_ = StructureJNI.FMOD_REVERB_PROPERTIES_get_DecayHFRatio(pointer);
		return result_;
	}
	public void setDecayHFRatio(float DecayHFRatio)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_PROPERTIES_set_DecayHFRatio(pointer, DecayHFRatio);
	}

	/**
	 * [in/out] 0.1   , 2.0   , 1.0    , low-frequency to mid-frequency decay time ratio (win32 only)
	 */
	public float getDecayLFRatio()
	{
		if(pointer == 0) throw new NullPointerException();
		float result_ = StructureJNI.FMOD_REVERB_PROPERTIES_get_DecayLFRatio(pointer);
		return result_;
	}
	public void setDecayLFRatio(float DecayLFRatio)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_PROPERTIES_set_DecayLFRatio(pointer, DecayLFRatio);
	}

	/**
	 * [in/out] -10000, 1000  , -2602  , early reflections level relative to room effect (win32/Xbox/Xbox 360/GameCube)
	 */
	public int getReflections()
	{
		if(pointer == 0) throw new NullPointerException();
		int result_ = StructureJNI.FMOD_REVERB_PROPERTIES_get_Reflections(pointer);
		return result_;
	}
	public void setReflections(int Reflections)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_PROPERTIES_set_Reflections(pointer, Reflections);
	}

	/**
	 * [in/out] 0.0   , 0.3   , 0.007  , initial reflection delay time (win32/Xbox/Xbox 360)
	 */
	public float getReflectionsDelay()
	{
		if(pointer == 0) throw new NullPointerException();
		float result_ = StructureJNI.FMOD_REVERB_PROPERTIES_get_ReflectionsDelay(pointer);
		return result_;
	}
	public void setReflectionsDelay(float ReflectionsDelay)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_PROPERTIES_set_ReflectionsDelay(pointer, ReflectionsDelay);
	}

	/**
	 * [in/out]       ,       , [0,0,0], early reflections panning vector (win32 only)
	 */
	public FloatBuffer getReflectionsPan()
	{
		if(pointer == 0) throw new NullPointerException();
		ByteBuffer result_ = StructureJNI.FMOD_REVERB_PROPERTIES_get_ReflectionsPan(pointer);
		result_.order(ByteOrder.nativeOrder());
		return result_.asFloatBuffer();
	}
	public void setReflectionsPan(FloatBuffer ReflectionsPan)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_PROPERTIES_set_ReflectionsPan(pointer, ReflectionsPan, BufferUtils.getPositionInBytes(ReflectionsPan));
	}

	/**
	 * [in/out] -10000, 2000  , 200    , late reverberation level relative to room effect (win32/Xbox/Xbox 360)
	 */
	public int getReverb()
	{
		if(pointer == 0) throw new NullPointerException();
		int result_ = StructureJNI.FMOD_REVERB_PROPERTIES_get_Reverb(pointer);
		return result_;
	}
	public void setReverb(int Reverb)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_PROPERTIES_set_Reverb(pointer, Reverb);
	}

	/**
	 * [in/out] 0.0   , 0.1   , 0.011  , late reverberation delay time relative to initial reflection (win32/Xbox/Xbox 360/GameCube)
	 */
	public float getReverbDelay()
	{
		if(pointer == 0) throw new NullPointerException();
		float result_ = StructureJNI.FMOD_REVERB_PROPERTIES_get_ReverbDelay(pointer);
		return result_;
	}
	public void setReverbDelay(float ReverbDelay)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_PROPERTIES_set_ReverbDelay(pointer, ReverbDelay);
	}

	/**
	 * [in/out]       ,       , [0,0,0], late reverberation panning vector (win32 only)
	 */
	public FloatBuffer getReverbPan()
	{
		if(pointer == 0) throw new NullPointerException();
		ByteBuffer result_ = StructureJNI.FMOD_REVERB_PROPERTIES_get_ReverbPan(pointer);
		result_.order(ByteOrder.nativeOrder());
		return result_.asFloatBuffer();
	}
	public void setReverbPan(FloatBuffer ReverbPan)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_PROPERTIES_set_ReverbPan(pointer, ReverbPan, BufferUtils.getPositionInBytes(ReverbPan));
	}

	/**
	 * [in/out] .075  , 0.25  , 0.25   , echo time (win32 or ps2 FMOD_PRESET_PS2_ECHO/FMOD_PRESET_PS2_DELAY only)
	 */
	public float getEchoTime()
	{
		if(pointer == 0) throw new NullPointerException();
		float result_ = StructureJNI.FMOD_REVERB_PROPERTIES_get_EchoTime(pointer);
		return result_;
	}
	public void setEchoTime(float EchoTime)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_PROPERTIES_set_EchoTime(pointer, EchoTime);
	}

	/**
	 * [in/out] 0.0   , 1.0   , 0.0    , echo depth (win32 or ps2 FMOD_PRESET_PS2_ECHO only)
	 */
	public float getEchoDepth()
	{
		if(pointer == 0) throw new NullPointerException();
		float result_ = StructureJNI.FMOD_REVERB_PROPERTIES_get_EchoDepth(pointer);
		return result_;
	}
	public void setEchoDepth(float EchoDepth)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_PROPERTIES_set_EchoDepth(pointer, EchoDepth);
	}

	/**
	 * [in/out] 0.04  , 4.0   , 0.25   , modulation time (win32 only)
	 */
	public float getModulationTime()
	{
		if(pointer == 0) throw new NullPointerException();
		float result_ = StructureJNI.FMOD_REVERB_PROPERTIES_get_ModulationTime(pointer);
		return result_;
	}
	public void setModulationTime(float ModulationTime)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_PROPERTIES_set_ModulationTime(pointer, ModulationTime);
	}

	/**
	 * [in/out] 0.0   , 1.0   , 0.0    , modulation depth (win32/GameCube)
	 */
	public float getModulationDepth()
	{
		if(pointer == 0) throw new NullPointerException();
		float result_ = StructureJNI.FMOD_REVERB_PROPERTIES_get_ModulationDepth(pointer);
		return result_;
	}
	public void setModulationDepth(float ModulationDepth)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_PROPERTIES_set_ModulationDepth(pointer, ModulationDepth);
	}

	/**
	 * [in/out] -100  , 0.0   , -5.0   , change in level per meter at high frequencies (win32 only)
	 */
	public float getAirAbsorptionHF()
	{
		if(pointer == 0) throw new NullPointerException();
		float result_ = StructureJNI.FMOD_REVERB_PROPERTIES_get_AirAbsorptionHF(pointer);
		return result_;
	}
	public void setAirAbsorptionHF(float AirAbsorptionHF)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_PROPERTIES_set_AirAbsorptionHF(pointer, AirAbsorptionHF);
	}

	/**
	 * [in/out] 1000.0, 20000 , 5000.0 , reference high frequency (hz) (win32/Xbox/Xbox 360)
	 */
	public float getHFReference()
	{
		if(pointer == 0) throw new NullPointerException();
		float result_ = StructureJNI.FMOD_REVERB_PROPERTIES_get_HFReference(pointer);
		return result_;
	}
	public void setHFReference(float HFReference)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_PROPERTIES_set_HFReference(pointer, HFReference);
	}

	/**
	 * [in/out] 20.0  , 1000.0, 250.0  , reference low frequency (hz) (win32 only)
	 */
	public float getLFReference()
	{
		if(pointer == 0) throw new NullPointerException();
		float result_ = StructureJNI.FMOD_REVERB_PROPERTIES_get_LFReference(pointer);
		return result_;
	}
	public void setLFReference(float LFReference)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_PROPERTIES_set_LFReference(pointer, LFReference);
	}

	/**
	 * [in/out] 0.0   , 10.0  , 0.0    , like rolloffscale in System::set3DSettings but for reverb room size effect (win32/Xbox/Xbox 360)
	 */
	public float getRoomRolloffFactor()
	{
		if(pointer == 0) throw new NullPointerException();
		float result_ = StructureJNI.FMOD_REVERB_PROPERTIES_get_RoomRolloffFactor(pointer);
		return result_;
	}
	public void setRoomRolloffFactor(float RoomRolloffFactor)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_PROPERTIES_set_RoomRolloffFactor(pointer, RoomRolloffFactor);
	}

	/**
	 * [in/out] 0.0   , 100.0 , 100.0  , Value that controls the echo density in the late reverberation decay. (Xbox/Xbox 360)
	 */
	public float getDiffusion()
	{
		if(pointer == 0) throw new NullPointerException();
		float result_ = StructureJNI.FMOD_REVERB_PROPERTIES_get_Diffusion(pointer);
		return result_;
	}
	public void setDiffusion(float Diffusion)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_PROPERTIES_set_Diffusion(pointer, Diffusion);
	}

	/**
	 * [in/out] 0.0   , 100.0 , 100.0  , Value that controls the modal density in the late reverberation decay (Xbox/Xbox 360)
	 */
	public float getDensity()
	{
		if(pointer == 0) throw new NullPointerException();
		float result_ = StructureJNI.FMOD_REVERB_PROPERTIES_get_Density(pointer);
		return result_;
	}
	public void setDensity(float Density)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_PROPERTIES_set_Density(pointer, Density);
	}

	/**
	 * [in/out] FMOD_REVERB_FLAGS - modifies the behavior of above properties (win32/ps2)
	 */
	public int getFlags()
	{
		if(pointer == 0) throw new NullPointerException();
		int result_ = StructureJNI.FMOD_REVERB_PROPERTIES_get_Flags(pointer);
		return result_;
	}
	public void setFlags(int Flags)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_PROPERTIES_set_Flags(pointer, Flags);
	}

}