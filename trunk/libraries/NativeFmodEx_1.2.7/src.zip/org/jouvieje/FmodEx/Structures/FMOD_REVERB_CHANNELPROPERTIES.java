/**
 * 							NativeFmodEx Project
 *
 * Do you want to use FMOD Ex API (www.fmod.org) with the Java language ? I've created NativeFmodEx for you.
 * Copyright � 2005-2006 J�r�me JOUVIE (Jouvieje)
 *
 * Created on 23 feb. 2005
 * @version file v1.0.0
 * @author J�r�me JOUVIE (Jouvieje)
 * 
 * 
 * WANT TO CONTACT ME ?
 * E-mail :
 * 		jerome.jouvie@gmail.com
 * My web sites :
 * 		http://jerome.jouvie.free.fr/
 * 		http://topresult.tomato.co.uk/~jerome/
 * 
 * 
 * INTRODUCTION
 * FMOD Ex is an API (Application Programming Interface) that allow you to use music
 * and creating sound effects with a lot of sort of musics.
 * FMOD is at :
 * 		http://www.fmod.org/
 * The reason of this project is that FMOD Ex can't be used direcly with Java, so I've created
 * this project to do this.
 * 
 * 
 * GNU LESSER GENERAL PUBLIC LICENSE
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of the License,
 * or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA 
 */

package org.jouvieje.FmodEx.Structures;

import org.jouvieje.FmodEx.*;
import org.jouvieje.FmodEx.Exceptions.*;
import org.jouvieje.FmodEx.Callbacks.*;
import org.jouvieje.FmodEx.*;
import org.jouvieje.FmodEx.Defines.*;
import org.jouvieje.FmodEx.Enumerations.*;
import org.jouvieje.FmodEx.Structures.*;
import java.nio.*;
import org.jouvieje.FmodEx.Misc.*;

/**
 * <BR>
 * <BR>
 * Structure defining the properties for a reverb source, related to a FMOD channel.<BR>
 * <BR>
 * For more indepth descriptions of the reverb properties under win32, please see the EAX3<BR>
 * documentation at http://developer.creative.com/ under the 'downloads' section.<BR>
 * If they do not have the EAX3 documentation, then most information can be attained from<BR>
 * the EAX2 documentation, as EAX3 only adds some more parameters and functionality on top of<BR>
 * EAX2.<BR>
 * <BR>
 * Note the default reverb properties are the same as the FMOD_PRESET_GENERIC preset.<BR>
 * Note that integer values that typically range from -10,000 to 1000 are represented in<BR>
 * decibels, and are of a logarithmic scale, not linear, wheras float values are typically linear.<BR>
 * PORTABILITY: Each member has the platform it supports in braces ie (win32/Xbox).<BR>
 * Some reverb parameters are only supported in win32 and some only on Xbox. If all parameters are set then<BR>
 * the reverb should product a similar effect on either platform.<BR>
 * <BR>
 * The numerical values listed below are the maximum, minimum and default values for each variable respectively.<BR>
 * <BR>
 * <BR><U><B>Remarks</B></U><BR><BR>
 * <BR>
 * <BR><U><B>Platforms Supported</B></U><BR><BR>
 * Win32, Win64, Linux, Linux64, Macintosh, Xbox, Xbox360, PlayStation 2, GameCube, PlayStation Portable, PlayStation 3<BR>
 * <BR>
 * <BR><U><B>See Also</B></U><BR><BR>
 * Channel::setReverbProperties<BR>
 * Channel::getReverbProperties<BR>
 * FMOD_REVERB_CHANNELFLAGS<BR>
 * 
 */
public class FMOD_REVERB_CHANNELPROPERTIES extends Pointer
{
	/**
	 * Create a view of the <code>Pointer</code> object as a <code>FMOD_REVERB_CHANNELPROPERTIES</code> object.<br>
	 * This view is valid only if the memory holded by the <code>Pointer</code> holds a FMOD_REVERB_CHANNELPROPERTIES object.
	 */
	public static FMOD_REVERB_CHANNELPROPERTIES createView(Pointer pointer)
	{
		return new FMOD_REVERB_CHANNELPROPERTIES(Pointer.getPointer(pointer));
	}
	/**
	 * Create a new <code>FMOD_REVERB_CHANNELPROPERTIES</code>.<br>
	 * The call <code>isNull()</code> on the object created will return false.<br>
	 * <pre><code>  FMOD_REVERB_CHANNELPROPERTIES obj = FMOD_REVERB_CHANNELPROPERTIES.create();
	 *  (obj == null) <=> obj.isNull() <=> false
	 * </code></pre>
	 */
	public static FMOD_REVERB_CHANNELPROPERTIES create()
	{
		return new FMOD_REVERB_CHANNELPROPERTIES(StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_new());
	}

	protected FMOD_REVERB_CHANNELPROPERTIES(long pointer)
	{
		super(pointer);
	}

	/**
	 * Create an object that holds a null <code>FMOD_REVERB_CHANNELPROPERTIES</code>.<br>
	 * The call <code>isNull()</code> on the object created will returns true.<br>
	 * <pre><code>  FMOD_REVERB_CHANNELPROPERTIES obj = new FMOD_REVERB_CHANNELPROPERTIES();
	 *  (obj == null) <=> false
	 *  obj.isNull() <=> true
	 * </code></pre>
	 * To creates a new <code>FMOD_REVERB_CHANNELPROPERTIES</code>, use the static "constructor" :
	 * <pre><code>  FMOD_REVERB_CHANNELPROPERTIES obj = FMOD_REVERB_CHANNELPROPERTIES.create();</code></pre>
	 * @see FMOD_REVERB_CHANNELPROPERTIES#create()
	 */
	public FMOD_REVERB_CHANNELPROPERTIES()
	{
		super();
	}

	public void release()
	{
		if(pointer != 0)
		{
			StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_delete(pointer);
		}
		pointer = 0;
	}

	/**
	 * [in/out] -10000, 1000,  0,       direct path level (at low and mid frequencies) (win32/Xbox)
	 */
	public int getDirect()
	{
		if(pointer == 0) throw new NullPointerException();
		int result_ = StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_get_Direct(pointer);
		return result_;
	}
	public void setDirect(int Direct)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_set_Direct(pointer, Direct);
	}

	/**
	 * [in/out] -10000, 0,     0,       relative direct path level at high frequencies (win32/Xbox)
	 */
	public int getDirectHF()
	{
		if(pointer == 0) throw new NullPointerException();
		int result_ = StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_get_DirectHF(pointer);
		return result_;
	}
	public void setDirectHF(int DirectHF)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_set_DirectHF(pointer, DirectHF);
	}

	/**
	 * [in/out] -10000, 1000,  0,       room effect level (at low and mid frequencies) (win32/Xbox/Gamecube/Xbox360)
	 */
	public int getRoom()
	{
		if(pointer == 0) throw new NullPointerException();
		int result_ = StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_get_Room(pointer);
		return result_;
	}
	public void setRoom(int Room)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_set_Room(pointer, Room);
	}

	/**
	 * [in/out] -10000, 0,     0,       relative room effect level at high frequencies (win32/Xbox)
	 */
	public int getRoomHF()
	{
		if(pointer == 0) throw new NullPointerException();
		int result_ = StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_get_RoomHF(pointer);
		return result_;
	}
	public void setRoomHF(int RoomHF)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_set_RoomHF(pointer, RoomHF);
	}

	/**
	 * [in/out] -10000, 0,     0,       main obstruction control (attenuation at high frequencies)  (win32/Xbox)
	 */
	public int getObstruction()
	{
		if(pointer == 0) throw new NullPointerException();
		int result_ = StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_get_Obstruction(pointer);
		return result_;
	}
	public void setObstruction(int Obstruction)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_set_Obstruction(pointer, Obstruction);
	}

	/**
	 * [in/out] 0.0,    1.0,   0.0,     obstruction low-frequency level re. main control (win32/Xbox)
	 */
	public float getObstructionLFRatio()
	{
		if(pointer == 0) throw new NullPointerException();
		float result_ = StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_get_ObstructionLFRatio(pointer);
		return result_;
	}
	public void setObstructionLFRatio(float ObstructionLFRatio)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_set_ObstructionLFRatio(pointer, ObstructionLFRatio);
	}

	/**
	 * [in/out] -10000, 0,     0,       main occlusion control (attenuation at high frequencies) (win32/Xbox)
	 */
	public int getOcclusion()
	{
		if(pointer == 0) throw new NullPointerException();
		int result_ = StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_get_Occlusion(pointer);
		return result_;
	}
	public void setOcclusion(int Occlusion)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_set_Occlusion(pointer, Occlusion);
	}

	/**
	 * [in/out] 0.0,    1.0,   0.25,    occlusion low-frequency level re. main control (win32/Xbox)
	 */
	public float getOcclusionLFRatio()
	{
		if(pointer == 0) throw new NullPointerException();
		float result_ = StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_get_OcclusionLFRatio(pointer);
		return result_;
	}
	public void setOcclusionLFRatio(float OcclusionLFRatio)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_set_OcclusionLFRatio(pointer, OcclusionLFRatio);
	}

	/**
	 * [in/out] 0.0,    10.0,  1.5,     relative occlusion control for room effect (win32)
	 */
	public float getOcclusionRoomRatio()
	{
		if(pointer == 0) throw new NullPointerException();
		float result_ = StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_get_OcclusionRoomRatio(pointer);
		return result_;
	}
	public void setOcclusionRoomRatio(float OcclusionRoomRatio)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_set_OcclusionRoomRatio(pointer, OcclusionRoomRatio);
	}

	/**
	 * [in/out] 0.0,    10.0,  1.0,     relative occlusion control for direct path (win32)
	 */
	public float getOcclusionDirectRatio()
	{
		if(pointer == 0) throw new NullPointerException();
		float result_ = StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_get_OcclusionDirectRatio(pointer);
		return result_;
	}
	public void setOcclusionDirectRatio(float OcclusionDirectRatio)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_set_OcclusionDirectRatio(pointer, OcclusionDirectRatio);
	}

	/**
	 * [in/out] -10000, 0,     0,       main exlusion control (attenuation at high frequencies) (win32)
	 */
	public int getExclusion()
	{
		if(pointer == 0) throw new NullPointerException();
		int result_ = StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_get_Exclusion(pointer);
		return result_;
	}
	public void setExclusion(int Exclusion)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_set_Exclusion(pointer, Exclusion);
	}

	/**
	 * [in/out] 0.0,    1.0,   1.0,     exclusion low-frequency level re. main control (win32)
	 */
	public float getExclusionLFRatio()
	{
		if(pointer == 0) throw new NullPointerException();
		float result_ = StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_get_ExclusionLFRatio(pointer);
		return result_;
	}
	public void setExclusionLFRatio(float ExclusionLFRatio)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_set_ExclusionLFRatio(pointer, ExclusionLFRatio);
	}

	/**
	 * [in/out] -10000, 0,     0,       outside sound cone level at high frequencies (win32)
	 */
	public int getOutsideVolumeHF()
	{
		if(pointer == 0) throw new NullPointerException();
		int result_ = StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_get_OutsideVolumeHF(pointer);
		return result_;
	}
	public void setOutsideVolumeHF(int OutsideVolumeHF)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_set_OutsideVolumeHF(pointer, OutsideVolumeHF);
	}

	/**
	 * [in/out] 0.0,    10.0,  0.0,     like DS3D flDopplerFactor but per source (win32)
	 */
	public float getDopplerFactor()
	{
		if(pointer == 0) throw new NullPointerException();
		float result_ = StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_get_DopplerFactor(pointer);
		return result_;
	}
	public void setDopplerFactor(float DopplerFactor)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_set_DopplerFactor(pointer, DopplerFactor);
	}

	/**
	 * [in/out] 0.0,    10.0,  0.0,     like DS3D flRolloffFactor but per source (win32)
	 */
	public float getRolloffFactor()
	{
		if(pointer == 0) throw new NullPointerException();
		float result_ = StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_get_RolloffFactor(pointer);
		return result_;
	}
	public void setRolloffFactor(float RolloffFactor)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_set_RolloffFactor(pointer, RolloffFactor);
	}

	/**
	 * [in/out] 0.0,    10.0,  0.0,     like DS3D flRolloffFactor but for room effect (win32/Xbox)
	 */
	public float getRoomRolloffFactor()
	{
		if(pointer == 0) throw new NullPointerException();
		float result_ = StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_get_RoomRolloffFactor(pointer);
		return result_;
	}
	public void setRoomRolloffFactor(float RoomRolloffFactor)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_set_RoomRolloffFactor(pointer, RoomRolloffFactor);
	}

	/**
	 * [in/out] 0.0,    10.0,  1.0,     multiplies AirAbsorptionHF member of FMOD_REVERB_PROPERTIES (win32)
	 */
	public float getAirAbsorptionFactor()
	{
		if(pointer == 0) throw new NullPointerException();
		float result_ = StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_get_AirAbsorptionFactor(pointer);
		return result_;
	}
	public void setAirAbsorptionFactor(float AirAbsorptionFactor)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_set_AirAbsorptionFactor(pointer, AirAbsorptionFactor);
	}

	/**
	 * [in/out] FMOD_REVERB_CHANNELFLAGS - modifies the behavior of properties (win32)
	 */
	public int getFlags()
	{
		if(pointer == 0) throw new NullPointerException();
		int result_ = StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_get_Flags(pointer);
		return result_;
	}
	public void setFlags(int Flags)
	{
		if(pointer == 0) throw new NullPointerException();
		StructureJNI.FMOD_REVERB_CHANNELPROPERTIES_set_Flags(pointer, Flags);
	}

}