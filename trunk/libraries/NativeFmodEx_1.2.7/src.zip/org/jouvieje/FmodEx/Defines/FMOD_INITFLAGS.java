/**
 * 							NativeFmodEx Project
 *
 * Do you want to use FMOD Ex API (www.fmod.org) with the Java language ? I've created NativeFmodEx for you.
 * Copyright � 2005-2006 J�r�me JOUVIE (Jouvieje)
 *
 * Created on 23 feb. 2005
 * @version file v1.0.0
 * @author J�r�me JOUVIE (Jouvieje)
 * 
 * 
 * WANT TO CONTACT ME ?
 * E-mail :
 * 		jerome.jouvie@gmail.com
 * My web sites :
 * 		http://jerome.jouvie.free.fr/
 * 		http://topresult.tomato.co.uk/~jerome/
 * 
 * 
 * INTRODUCTION
 * FMOD Ex is an API (Application Programming Interface) that allow you to use music
 * and creating sound effects with a lot of sort of musics.
 * FMOD is at :
 * 		http://www.fmod.org/
 * The reason of this project is that FMOD Ex can't be used direcly with Java, so I've created
 * this project to do this.
 * 
 * 
 * GNU LESSER GENERAL PUBLIC LICENSE
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of the License,
 * or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA 
 */

package org.jouvieje.FmodEx.Defines;

/**
 * <BR>
 * Initialization flags.  Use them with System::init in the flags parameter to change various behaviour.<BR>
 * <BR>
 * <BR><U><B>Remarks</B></U><BR><BR>
 * <BR>
 * <BR><U><B>Platforms Supported</B></U><BR><BR>
 * Win32, Win64, Linux, Linux64, Macintosh, Xbox, Xbox360, PlayStation 2, GameCube, PlayStation Portable, PlayStation 3<BR>
 * <BR>
 * <BR><U><B>See Also</B></U><BR><BR>
 * System::init<BR>
 * System::update<BR>
 * 
 */
public interface FMOD_INITFLAGS
{
	/** All platforms - Initialize normally */
	public static final int FMOD_INIT_NORMAL = 0x00000000;
	/** All platforms - No stream thread is created internally.  Streams are driven from System::update.  Mainly used with non-realtime outputs. */
	public static final int FMOD_INIT_STREAM_FROM_UPDATE = 0x00000001;
	/** All platforms - FMOD will treat +X as left, +Y as up and +Z as forwards. */
	public static final int FMOD_INIT_3D_RIGHTHANDED = 0x00000002;
	/** All platforms - Disable software mixer to save memory.  Anything created with FMOD_SOFTWARE will fail and DSP will not work. */
	public static final int FMOD_INIT_DISABLESOFTWARE = 0x00000004;
	/** Win32 only - for DirectSound output - FMOD_HARDWARE | FMOD_3D buffers use simple stereo panning/doppler/attenuation when 3D hardware acceleration is not present. */
	public static final int FMOD_INIT_DSOUND_HRTFNONE = 0x00000200;
	/** Win32 only - for DirectSound output - FMOD_HARDWARE | FMOD_3D buffers use a slightly higher quality algorithm when 3D hardware acceleration is not present. */
	public static final int FMOD_INIT_DSOUND_HRTFLIGHT = 0x00000400;
	/** Win32 only - for DirectSound output - FMOD_HARDWARE | FMOD_3D buffers use full quality 3D playback when 3d hardware acceleration is not present. */
	public static final int FMOD_INIT_DSOUND_HRTFFULL = 0x00000800;
	/** PS2 only - Disable reverb on CORE 0 to regain 256k SRAM. */
	public static final int FMOD_INIT_PS2_DISABLECORE0REVERB = 0x00010000;
	/** PS2 only - Disable reverb on CORE 1 to regain 256k SRAM. */
	public static final int FMOD_INIT_PS2_DISABLECORE1REVERB = 0x00020000;
	/** PS2 only - Disable FMOD's usage of the scratchpad. */
	public static final int FMOD_INIT_PS2_DONTUSESCRATCHPAD = 0x00040000;
	/** Xbox only - By default DirectSound attenuates all sound by 6db to avoid clipping/distortion.  CAUTION.  If you use this flag you are responsible for the final mix to make sure clipping / distortion doesn't happen. */
	public static final int FMOD_INIT_XBOX_REMOVEHEADROOM = 0x00100000;
}