/**
 * 							NativeFmodEx Project
 *
 * Do you want to use FMOD Ex API (www.fmod.org) with the Java language ? I've created NativeFmodEx for you.
 * Copyright � 2005-2006 J�r�me JOUVIE (Jouvieje)
 *
 * Created on 23 feb. 2005
 * @version file v1.0.0
 * @author J�r�me JOUVIE (Jouvieje)
 * 
 * 
 * WANT TO CONTACT ME ?
 * E-mail :
 * 		jerome.jouvie@gmail.com
 * My web sites :
 * 		http://jerome.jouvie.free.fr/
 * 		http://topresult.tomato.co.uk/~jerome/
 * 
 * 
 * INTRODUCTION
 * FMOD Ex is an API (Application Programming Interface) that allow you to use music
 * and creating sound effects with a lot of sort of musics.
 * FMOD is at :
 * 		http://www.fmod.org/
 * The reason of this project is that FMOD Ex can't be used direcly with Java, so I've created
 * this project to do this.
 * 
 * 
 * GNU LESSER GENERAL PUBLIC LICENSE
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of the License,
 * or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA 
 */

package org.jouvieje.FmodEx.Callbacks;

import org.jouvieje.FmodEx.*;
import org.jouvieje.FmodEx.Exceptions.*;
import org.jouvieje.FmodEx.Callbacks.*;
import org.jouvieje.FmodEx.*;
import org.jouvieje.FmodEx.Defines.*;
import org.jouvieje.FmodEx.Enumerations.*;
import org.jouvieje.FmodEx.Structures.*;
import java.nio.*;
import org.jouvieje.FmodEx.Misc.*;

class CallbackBridge extends Pointer
{
	protected final static int NB_CALLBACKS = 19;

	public static int FMOD_SOUND_NONBLOCKCALLBACK_BRIDGE(long sound, int result)
	{
		FMOD_SOUND_NONBLOCKCALLBACK callback = (FMOD_SOUND_NONBLOCKCALLBACK)CallbackManager.getCallback(0, sound, false);
		FMOD_RESULT result_ = callback.FMOD_SOUND_NONBLOCKCALLBACK(sound == 0 ? null : Sound.createView(Pointer.newPointer(sound)), FMOD_RESULT.get(result));
		return result_ == null ? FMOD_RESULT.FMOD_RESULT_FORCEINT.asInt() : result_.asInt();
	}
	public static int FMOD_SOUND_PCMREADCALLBACK_BRIDGE(long sound, ByteBuffer data, int datalen)
	{
		FMOD_SOUND_PCMREADCALLBACK callback = (FMOD_SOUND_PCMREADCALLBACK)CallbackManager.getCallback(1, sound, false);
		if(data != null) {
			data.order(ByteOrder.nativeOrder());
		}
		FMOD_RESULT result_ = callback.FMOD_SOUND_PCMREADCALLBACK(sound == 0 ? null : Sound.createView(Pointer.newPointer(sound)), data, datalen);
		return result_ == null ? FMOD_RESULT.FMOD_RESULT_FORCEINT.asInt() : result_.asInt();
	}
	public static int FMOD_SOUND_PCMSETPOSCALLBACK_BRIDGE(long sound, int subsound, int position, int postype)
	{
		FMOD_SOUND_PCMSETPOSCALLBACK callback = (FMOD_SOUND_PCMSETPOSCALLBACK)CallbackManager.getCallback(2, sound, false);
		FMOD_RESULT result_ = callback.FMOD_SOUND_PCMSETPOSCALLBACK(sound == 0 ? null : Sound.createView(Pointer.newPointer(sound)), subsound, position, postype);
		return result_ == null ? FMOD_RESULT.FMOD_RESULT_FORCEINT.asInt() : result_.asInt();
	}
	public static int FMOD_CHANNEL_CALLBACK_BRIDGE(long channel, int type, int command, int commanddata1, int commanddata2)
	{
		FMOD_CHANNEL_CALLBACK callback = (FMOD_CHANNEL_CALLBACK)CallbackManager.getCallback(3, channel, false);
		FMOD_RESULT result_ = callback.FMOD_CHANNEL_CALLBACK(channel == 0 ? null : Channel.createView(Pointer.newPointer(channel)), FMOD_CHANNEL_CALLBACKTYPE.get(type), command, commanddata1, commanddata2);
		return result_ == null ? FMOD_RESULT.FMOD_RESULT_FORCEINT.asInt() : result_.asInt();
	}
	public static int FMOD_FILE_OPENCALLBACK_BRIDGE(String name, int unicode, ByteBuffer filesize, Pointer handle, Pointer userdata)
	{
		FMOD_FILE_OPENCALLBACK callback = (FMOD_FILE_OPENCALLBACK)CallbackManager.getCallback(4);
		if(filesize != null) {
			filesize.order(ByteOrder.nativeOrder());
		}
		FMOD_RESULT result_ = callback.FMOD_FILE_OPENCALLBACK(name, unicode, filesize == null ? null : filesize.asIntBuffer(), handle, userdata);
		return result_ == null ? FMOD_RESULT.FMOD_RESULT_FORCEINT.asInt() : result_.asInt();
	}
	public static int FMOD_FILE_CLOSECALLBACK_BRIDGE(long handle, long userdata)
	{
		FMOD_FILE_CLOSECALLBACK callback = (FMOD_FILE_CLOSECALLBACK)CallbackManager.getCallback(5);
		FMOD_RESULT result_ = callback.FMOD_FILE_CLOSECALLBACK(handle == 0 ? null : Pointer.newPointer(handle), userdata == 0 ? null : Pointer.newPointer(userdata));
		return result_ == null ? FMOD_RESULT.FMOD_RESULT_FORCEINT.asInt() : result_.asInt();
	}
	public static int FMOD_FILE_READCALLBACK_BRIDGE(long handle, ByteBuffer buffer, int sizebytes, ByteBuffer bytesread, long userdata)
	{
		FMOD_FILE_READCALLBACK callback = (FMOD_FILE_READCALLBACK)CallbackManager.getCallback(6);
		if(buffer != null) {
			buffer.order(ByteOrder.nativeOrder());
		}
		if(bytesread != null) {
			bytesread.order(ByteOrder.nativeOrder());
		}
		FMOD_RESULT result_ = callback.FMOD_FILE_READCALLBACK(handle == 0 ? null : Pointer.newPointer(handle), buffer, sizebytes, bytesread == null ? null : bytesread.asIntBuffer(), userdata == 0 ? null : Pointer.newPointer(userdata));
		return result_ == null ? FMOD_RESULT.FMOD_RESULT_FORCEINT.asInt() : result_.asInt();
	}
	public static int FMOD_FILE_SEEKCALLBACK_BRIDGE(long handle, int pos, long userdata)
	{
		FMOD_FILE_SEEKCALLBACK callback = (FMOD_FILE_SEEKCALLBACK)CallbackManager.getCallback(7);
		FMOD_RESULT result_ = callback.FMOD_FILE_SEEKCALLBACK(handle == 0 ? null : Pointer.newPointer(handle), pos, userdata == 0 ? null : Pointer.newPointer(userdata));
		return result_ == null ? FMOD_RESULT.FMOD_RESULT_FORCEINT.asInt() : result_.asInt();
	}
	public static ByteBuffer FMOD_MEMORY_ALLOCCALLBACK_BRIDGE(int size)
	{
		FMOD_MEMORY_ALLOCCALLBACK callback = (FMOD_MEMORY_ALLOCCALLBACK)CallbackManager.getCallback(8);
		ByteBuffer result_ = callback.FMOD_MEMORY_ALLOCCALLBACK(size);
		return result_;
	}
	public static ByteBuffer FMOD_MEMORY_REALLOCCALLBACK_BRIDGE(ByteBuffer ptr, int size)
	{
		FMOD_MEMORY_REALLOCCALLBACK callback = (FMOD_MEMORY_REALLOCCALLBACK)CallbackManager.getCallback(9);
		if(ptr != null) {
			ptr.order(ByteOrder.nativeOrder());
		}
		ByteBuffer result_ = callback.FMOD_MEMORY_REALLOCCALLBACK(ptr, size);
		return result_;
	}
	public static void FMOD_MEMORY_FREECALLBACK_BRIDGE(ByteBuffer ptr)
	{
		FMOD_MEMORY_FREECALLBACK callback = (FMOD_MEMORY_FREECALLBACK)CallbackManager.getCallback(10);
		if(ptr != null) {
			ptr.order(ByteOrder.nativeOrder());
		}
		callback.FMOD_MEMORY_FREECALLBACK(ptr);
	}
	public static int FMOD_DSP_CREATECALLBACK_BRIDGE(long dsp_state)
	{
		FMOD_DSP_CREATECALLBACK callback = (FMOD_DSP_CREATECALLBACK)CallbackManager.getCallback(11, dsp_state, true);
		FMOD_RESULT result_ = callback.FMOD_DSP_CREATECALLBACK(dsp_state == 0 ? null : FMOD_DSP_STATE.createView(Pointer.newPointer(dsp_state)));
		return result_ == null ? FMOD_RESULT.FMOD_RESULT_FORCEINT.asInt() : result_.asInt();
	}
	public static int FMOD_DSP_RELEASECALLBACK_BRIDGE(long dsp_state)
	{
		FMOD_DSP_RELEASECALLBACK callback = (FMOD_DSP_RELEASECALLBACK)CallbackManager.getCallback(12, dsp_state, false);
		FMOD_RESULT result_ = callback.FMOD_DSP_RELEASECALLBACK(dsp_state == 0 ? null : FMOD_DSP_STATE.createView(Pointer.newPointer(dsp_state)));
		CallbackManager.addOwner(0, dsp_state);
		return result_ == null ? FMOD_RESULT.FMOD_RESULT_FORCEINT.asInt() : result_.asInt();
	}
	public static int FMOD_DSP_RESETCALLBACK_BRIDGE(long dsp_state)
	{
		FMOD_DSP_RESETCALLBACK callback = (FMOD_DSP_RESETCALLBACK)CallbackManager.getCallback(13, dsp_state, false);
		FMOD_RESULT result_ = callback.FMOD_DSP_RESETCALLBACK(dsp_state == 0 ? null : FMOD_DSP_STATE.createView(Pointer.newPointer(dsp_state)));
		return result_ == null ? FMOD_RESULT.FMOD_RESULT_FORCEINT.asInt() : result_.asInt();
	}
	public static int FMOD_DSP_READCALLBACK_BRIDGE(long dsp_state, ByteBuffer inbuffer, ByteBuffer outbuffer, int length, int inchannels, int outchannels)
	{
		FMOD_DSP_READCALLBACK callback = (FMOD_DSP_READCALLBACK)CallbackManager.getCallback(14, dsp_state, false);
		if(inbuffer != null) {
			inbuffer.order(ByteOrder.nativeOrder());
		}
		if(outbuffer != null) {
			outbuffer.order(ByteOrder.nativeOrder());
		}
		FMOD_RESULT result_ = callback.FMOD_DSP_READCALLBACK(dsp_state == 0 ? null : FMOD_DSP_STATE.createView(Pointer.newPointer(dsp_state)), inbuffer == null ? null : inbuffer.asFloatBuffer(), outbuffer == null ? null : outbuffer.asFloatBuffer(), length, inchannels, outchannels);
		return result_ == null ? FMOD_RESULT.FMOD_RESULT_FORCEINT.asInt() : result_.asInt();
	}
	public static int FMOD_DSP_SETPOSITIONCALLBACK_BRIDGE(long dsp_state, int pos)
	{
		FMOD_DSP_SETPOSITIONCALLBACK callback = (FMOD_DSP_SETPOSITIONCALLBACK)CallbackManager.getCallback(15, dsp_state, false);
		FMOD_RESULT result_ = callback.FMOD_DSP_SETPOSITIONCALLBACK(dsp_state == 0 ? null : FMOD_DSP_STATE.createView(Pointer.newPointer(dsp_state)), pos);
		return result_ == null ? FMOD_RESULT.FMOD_RESULT_FORCEINT.asInt() : result_.asInt();
	}
	public static int FMOD_DSP_SETPARAMCALLBACK_BRIDGE(long dsp_state, int index, float value)
	{
		FMOD_DSP_SETPARAMCALLBACK callback = (FMOD_DSP_SETPARAMCALLBACK)CallbackManager.getCallback(16, dsp_state, false);
		FMOD_RESULT result_ = callback.FMOD_DSP_SETPARAMCALLBACK(dsp_state == 0 ? null : FMOD_DSP_STATE.createView(Pointer.newPointer(dsp_state)), index, value);
		return result_ == null ? FMOD_RESULT.FMOD_RESULT_FORCEINT.asInt() : result_.asInt();
	}
	public static int FMOD_DSP_GETPARAMCALLBACK_BRIDGE(long dsp_state, int index, ByteBuffer value, ByteBuffer valuestr)
	{
		FMOD_DSP_GETPARAMCALLBACK callback = (FMOD_DSP_GETPARAMCALLBACK)CallbackManager.getCallback(17, dsp_state, false);
		if(value != null) {
			value.order(ByteOrder.nativeOrder());
		}
		if(valuestr != null) {
			valuestr.order(ByteOrder.nativeOrder());
		}
		FMOD_RESULT result_ = callback.FMOD_DSP_GETPARAMCALLBACK(dsp_state == 0 ? null : FMOD_DSP_STATE.createView(Pointer.newPointer(dsp_state)), index, value == null ? null : value.asFloatBuffer(), valuestr);
		return result_ == null ? FMOD_RESULT.FMOD_RESULT_FORCEINT.asInt() : result_.asInt();
	}
	public static int FMOD_DSP_DIALOGCALLBACK_BRIDGE(long dsp_state, long hwnd, int show)
	{
		FMOD_DSP_DIALOGCALLBACK callback = (FMOD_DSP_DIALOGCALLBACK)CallbackManager.getCallback(18, dsp_state, false);
		java.awt.Component hwndComponent = ComponentManager.getComponent(hwnd);
		FMOD_RESULT result_ = callback.FMOD_DSP_DIALOGCALLBACK(dsp_state == 0 ? null : FMOD_DSP_STATE.createView(Pointer.newPointer(dsp_state)), hwndComponent, show);
		return result_ == null ? FMOD_RESULT.FMOD_RESULT_FORCEINT.asInt() : result_.asInt();
	}

	protected static String getCallbackName(int type)
	{
		switch(type)
		{
			case 0: return "FMOD_SOUND_NONBLOCKCALLBACK";
			case 1: return "FMOD_SOUND_PCMREADCALLBACK";
			case 2: return "FMOD_SOUND_PCMSETPOSCALLBACK";
			case 3: return "FMOD_CHANNEL_CALLBACK";
			case 4: return "FMOD_FILE_OPENCALLBACK";
			case 5: return "FMOD_FILE_CLOSECALLBACK";
			case 6: return "FMOD_FILE_READCALLBACK";
			case 7: return "FMOD_FILE_SEEKCALLBACK";
			case 8: return "FMOD_MEMORY_ALLOCCALLBACK";
			case 9: return "FMOD_MEMORY_REALLOCCALLBACK";
			case 10: return "FMOD_MEMORY_FREECALLBACK";
			case 11: return "FMOD_DSP_CREATECALLBACK";
			case 12: return "FMOD_DSP_RELEASECALLBACK";
			case 13: return "FMOD_DSP_RESETCALLBACK";
			case 14: return "FMOD_DSP_READCALLBACK";
			case 15: return "FMOD_DSP_SETPOSITIONCALLBACK";
			case 16: return "FMOD_DSP_SETPARAMCALLBACK";
			case 17: return "FMOD_DSP_GETPARAMCALLBACK";
			case 18: return "FMOD_DSP_DIALOGCALLBACK";
			default: return "UNKNOW_"+type;
		}
	}
}