/**
 * 							NativeFmodEx Project
 *
 * Do you want to use FMOD Ex API (www.fmod.org) with the Java language ? I've created NativeFmodEx for you.
 * Copyright � 2005-2006 J�r�me JOUVIE (Jouvieje)
 *
 * Created on 23 feb. 2005
 * @version file v1.0.0
 * @author J�r�me JOUVIE (Jouvieje)
 * 
 * 
 * WANT TO CONTACT ME ?
 * E-mail :
 * 		jerome.jouvie@gmail.com
 * My web sites :
 * 		http://jerome.jouvie.free.fr/
 * 		http://topresult.tomato.co.uk/~jerome/
 * 
 * 
 * INTRODUCTION
 * FMOD Ex is an API (Application Programming Interface) that allow you to use music
 * and creating sound effects with a lot of sort of musics.
 * FMOD is at :
 * 		http://www.fmod.org/
 * The reason of this project is that FMOD Ex can't be used direcly with Java, so I've created
 * this project to do this.
 * 
 * 
 * GNU LESSER GENERAL PUBLIC LICENSE
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of the License,
 * or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA 
 */

package org.jouvieje.FmodEx.Enumerations;

import org.jouvieje.FmodEx.*;
import org.jouvieje.FmodEx.Exceptions.*;
import org.jouvieje.FmodEx.Callbacks.*;
import org.jouvieje.FmodEx.*;
import org.jouvieje.FmodEx.Defines.*;
import org.jouvieje.FmodEx.Enumerations.*;
import org.jouvieje.FmodEx.Structures.*;
import java.nio.*;
import org.jouvieje.FmodEx.Misc.*;
import java.util.HashMap;

/**
 * <BR>
 * <BR>
 * Parameter types for the FMOD_DSP_TYPE_CHORUS filter.<BR>
 * <BR>
 * <BR><U><B>Remarks</B></U><BR><BR>
 * Chrous is an effect where the sound is more 'spacious' due to 1 to 3 versions of the sound being played along side the original signal but with the pitch of each copy modulating on a sine wave.<BR>
 * This is a highly configurable chorus unit.  It supports 3 taps, small and large delay times and also feedback.<BR>
 * This unit also could be used to do a simple echo, or a flange effect.<BR>
 * <BR>
 * <BR><U><B>Platforms Supported</B></U><BR><BR>
 * Win32, Win64, Linux, Linux64, Macintosh, Xbox, Xbox360, PlayStation 2, GameCube, PlayStation Portable, PlayStation 3<BR>
 * <BR>
 * <BR><U><B>See Also</B></U><BR><BR>
 * DSP::setParameter<BR>
 * DSP::getParameter<BR>
 * FMOD_DSP_TYPE<BR>
 * 
 */
public class FMOD_DSP_CHORUS implements Enumeration, Comparable
{
	/**  */
	public final static FMOD_DSP_CHORUS FMOD_DSP_CHORUS_DRYMIX = new FMOD_DSP_CHORUS("FMOD_DSP_CHORUS_DRYMIX", EnumerationJNI.get_FMOD_DSP_CHORUS_DRYMIX());
	/** Volume of 1st chorus tap.  0.0 to 1.0.  Default = 0.5. */
	public final static FMOD_DSP_CHORUS FMOD_DSP_CHORUS_WETMIX1 = new FMOD_DSP_CHORUS("FMOD_DSP_CHORUS_WETMIX1", EnumerationJNI.get_FMOD_DSP_CHORUS_WETMIX1());
	/** Volume of 2nd chorus tap. This tap is 90 degrees out of phase of the first tap.  0.0 to 1.0.  Default = 0.5. */
	public final static FMOD_DSP_CHORUS FMOD_DSP_CHORUS_WETMIX2 = new FMOD_DSP_CHORUS("FMOD_DSP_CHORUS_WETMIX2", EnumerationJNI.get_FMOD_DSP_CHORUS_WETMIX2());
	/** Volume of 3rd chorus tap. This tap is 90 degrees out of phase of the second tap.  0.0 to 1.0.  Default = 0.5. */
	public final static FMOD_DSP_CHORUS FMOD_DSP_CHORUS_WETMIX3 = new FMOD_DSP_CHORUS("FMOD_DSP_CHORUS_WETMIX3", EnumerationJNI.get_FMOD_DSP_CHORUS_WETMIX3());
	/** Chorus delay in ms.  0.1 to 100.0.  Default = 40.0 ms. */
	public final static FMOD_DSP_CHORUS FMOD_DSP_CHORUS_DELAY = new FMOD_DSP_CHORUS("FMOD_DSP_CHORUS_DELAY", EnumerationJNI.get_FMOD_DSP_CHORUS_DELAY());
	/** Chorus modulation rate in hz.  0.0 to 20.0.  Default = 0.8 hz. */
	public final static FMOD_DSP_CHORUS FMOD_DSP_CHORUS_RATE = new FMOD_DSP_CHORUS("FMOD_DSP_CHORUS_RATE", EnumerationJNI.get_FMOD_DSP_CHORUS_RATE());
	/** Chorus modulation depth.  0.0 to 1.0.  Default = 0.03. */
	public final static FMOD_DSP_CHORUS FMOD_DSP_CHORUS_DEPTH = new FMOD_DSP_CHORUS("FMOD_DSP_CHORUS_DEPTH", EnumerationJNI.get_FMOD_DSP_CHORUS_DEPTH());
	/** Chorus feedback.  Controls how much of the wet signal gets fed back into the chorus buffer.  0.0 to 1.0.  Default = 0.0. */
	public final static FMOD_DSP_CHORUS FMOD_DSP_CHORUS_FEEDBACK = new FMOD_DSP_CHORUS("FMOD_DSP_CHORUS_FEEDBACK", EnumerationJNI.get_FMOD_DSP_CHORUS_FEEDBACK());

	private final static HashMap VALUES = new HashMap(2*8);
	static
	{
		VALUES.put(new Integer(FMOD_DSP_CHORUS_DRYMIX.asInt()), FMOD_DSP_CHORUS_DRYMIX);
		VALUES.put(new Integer(FMOD_DSP_CHORUS_WETMIX1.asInt()), FMOD_DSP_CHORUS_WETMIX1);
		VALUES.put(new Integer(FMOD_DSP_CHORUS_WETMIX2.asInt()), FMOD_DSP_CHORUS_WETMIX2);
		VALUES.put(new Integer(FMOD_DSP_CHORUS_WETMIX3.asInt()), FMOD_DSP_CHORUS_WETMIX3);
		VALUES.put(new Integer(FMOD_DSP_CHORUS_DELAY.asInt()), FMOD_DSP_CHORUS_DELAY);
		VALUES.put(new Integer(FMOD_DSP_CHORUS_RATE.asInt()), FMOD_DSP_CHORUS_RATE);
		VALUES.put(new Integer(FMOD_DSP_CHORUS_DEPTH.asInt()), FMOD_DSP_CHORUS_DEPTH);
		VALUES.put(new Integer(FMOD_DSP_CHORUS_FEEDBACK.asInt()), FMOD_DSP_CHORUS_FEEDBACK);
	}

	private String name;
	private int nativeValue;
	private FMOD_DSP_CHORUS(String name, int nativeValue)
	{
		this.name = name;
		this.nativeValue = nativeValue;
	}

	public int asInt()
	{
		return nativeValue;
	}
	public String toString()
	{
		return name;
	}
	public boolean equals(Object object)
	{
		if(object instanceof FMOD_DSP_CHORUS)
			return asInt() == ((FMOD_DSP_CHORUS)object).asInt();
		return false;
	}
	public int compareTo(Object object)
	{
		return asInt() - ((FMOD_DSP_CHORUS)object).asInt();
	}


	/**
	 * Retrieve a FMOD_DSP_CHORUS enum field with his integer value
	 * @param nativeValue the integer value of the field to retrieve
	 * @return the FMOD_DSP_CHORUS enum field that correspond to the integer value
	 */
	public static FMOD_DSP_CHORUS get(int nativeValue)
	{
		return (FMOD_DSP_CHORUS)VALUES.get(new Integer(nativeValue));
	}

	/**
	 * Retrieve a FMOD_DSP_CHORUS enum field from a Pointer
	 * @param pointer a pointer holding an FMOD_DSP_CHORUS enum field
	 * @return the FMOD_DSP_CHORUS enum field that correspond to the enum field in the pointer
	 */
	public static FMOD_DSP_CHORUS get(Pointer pointer)
	{
		return get(pointer.asInt());
	}
}