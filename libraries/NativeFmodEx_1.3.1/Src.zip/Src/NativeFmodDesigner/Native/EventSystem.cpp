/**
 * 							NativeFmodEx Project
 *
 * Do you want to use FMOD Ex API (www.fmod.org) with the Java language ? I've created NativeFmodEx for you.
 * Copyright � 2005-2006 J�r�me JOUVIE (Jouvieje)
 *
 * Created on 23 feb. 2005
 * @version file v1.0.0
 * @author J�r�me JOUVIE (Jouvieje)
 * 
 * 
 * WANT TO CONTACT ME ?
 * E-mail :
 * 		jerome.jouvie@gmail.com
 * My web sites :
 * 		http://jerome.jouvie.free.fr/
 * 		http://topresult.tomato.co.uk/~jerome/
 * 
 * 
 * INTRODUCTION
 * FMOD Ex is an API (Application Programming Interface) that allow you to use music
 * and creating sound effects with a lot of sort of musics.
 * FMOD is at :
 * 		http://www.fmod.org/
 * The reason of this project is that FMOD Ex can't be used direcly with Java, so I've created
 * this project to do this.
 * 
 * 
 * GNU LESSER GENERAL PUBLIC LICENSE
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of the License,
 * or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA 
 */
#include "Utils.h"
#include "Pointer.h"
#include "fmod_event.h"
#include "fmod_event_net.h"
#include "org_jouvieje_FmodDesigner_FmodDesignerJNI.h"
#include "CallbackManager.h"

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1init(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jmaxchannels, jint jflags, jlong jextradriverdata, jint jeventflags) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}
	int maxchannels = (int)jmaxchannels;
	FMOD_INITFLAGS flags = (FMOD_INITFLAGS)jflags;
	void *extradriverdata = *(void **)&jextradriverdata;
	EVENT_INITFLAGS eventflags = (EVENT_INITFLAGS)jeventflags;

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->init(maxchannels, flags, extradriverdata, eventflags);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1release(JNIEnv *jenv, jclass jcls, jlong jPointer) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->release();

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1update(JNIEnv *jenv, jclass jcls, jlong jPointer) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->update();

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1setMediaPath(JNIEnv *jenv, jclass jcls, jlong jPointer, jbyteArray jpath) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}
	char *path = getByteArrayElements(jenv, jpath);

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->setMediaPath(path);

	releaseByteArrayElements(jenv, jpath, (const char *)path);
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1setPluginPath(JNIEnv *jenv, jclass jcls, jlong jPointer, jbyteArray jpath) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}
	char *path = getByteArrayElements(jenv, jpath);

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->setPluginPath(path);

	releaseByteArrayElements(jenv, jpath, (const char *)path);
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1getVersion(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jversion, jlong jversion_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}
	unsigned int *version = 0;
	if(jversion) {
		version = (unsigned int *)((char *)jenv->GetDirectBufferAddress(jversion)+jversion_);
	}

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->getVersion(version);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1getInfo(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jinfo) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}
	FMOD::EVENT_SYSTEMINFO *info = *(FMOD::EVENT_SYSTEMINFO **)&jinfo;

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->getInfo(info);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1getSystemObject(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jsystem) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}
	FMOD::System *system;

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->getSystemObject(&system);

	if(system && jsystem) {
		jlong newAddress = 0;
		*(FMOD::System **)&newAddress = system;
		setPointerAddress(jenv, jsystem, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1load(JNIEnv *jenv, jclass jcls, jlong jPointer, jbyteArray jfilename, jbyteArray jencryptionkey, jobject jproject) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}
	char *filename = getByteArrayElements(jenv, jfilename);
	char *encryptionkey = getByteArrayElements(jenv, jencryptionkey);
	FMOD::EventProject *project;

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->load(filename, encryptionkey, &project);

	releaseByteArrayElements(jenv, jfilename, (const char *)filename);
	releaseByteArrayElements(jenv, jencryptionkey, (const char *)encryptionkey);
	if(project && jproject) {
		jlong newAddress = 0;
		*(FMOD::EventProject **)&newAddress = project;
		setPointerAddress(jenv, jproject, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1unload(JNIEnv *jenv, jclass jcls, jlong jPointer) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->unload();

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1getProject(JNIEnv *jenv, jclass jcls, jlong jPointer, jbyteArray jname, jobject jproject) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}
	char *name = getByteArrayElements(jenv, jname);
	FMOD::EventProject *project;

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->getProject(name, &project);

	releaseByteArrayElements(jenv, jname, (const char *)name);
	if(project && jproject) {
		jlong newAddress = 0;
		*(FMOD::EventProject **)&newAddress = project;
		setPointerAddress(jenv, jproject, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1getProjectByIndex(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jobject jproject) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}
	int index = (int)jindex;
	FMOD::EventProject *project;

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->getProjectByIndex(index, &project);

	if(project && jproject) {
		jlong newAddress = 0;
		*(FMOD::EventProject **)&newAddress = project;
		setPointerAddress(jenv, jproject, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1getNumProjects(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jnumprojects, jlong jnumprojects_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}
	int *numprojects = 0;
	if(jnumprojects) {
		numprojects = (int *)((char *)jenv->GetDirectBufferAddress(jnumprojects)+jnumprojects_);
	}

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->getNumProjects(numprojects);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1getCategory(JNIEnv *jenv, jclass jcls, jlong jPointer, jbyteArray jname, jobject jcategory) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}
	char *name = getByteArrayElements(jenv, jname);
	FMOD::EventCategory *category;

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->getCategory(name, &category);

	releaseByteArrayElements(jenv, jname, (const char *)name);
	if(category && jcategory) {
		jlong newAddress = 0;
		*(FMOD::EventCategory **)&newAddress = category;
		setPointerAddress(jenv, jcategory, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1getCategoryByIndex(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jobject jcategory) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}
	int index = (int)jindex;
	FMOD::EventCategory *category;

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->getCategoryByIndex(index, &category);

	if(category && jcategory) {
		jlong newAddress = 0;
		*(FMOD::EventCategory **)&newAddress = category;
		setPointerAddress(jenv, jcategory, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1getNumCategories(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jnumcategories, jlong jnumcategories_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}
	int *numcategories = 0;
	if(jnumcategories) {
		numcategories = (int *)((char *)jenv->GetDirectBufferAddress(jnumcategories)+jnumcategories_);
	}

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->getNumCategories(numcategories);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1getReverb(JNIEnv *jenv, jclass jcls, jlong jPointer, jbyteArray jname, jobject jreverb) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}
	char *name = getByteArrayElements(jenv, jname);
	FMOD::EventReverb *reverb;

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->getReverb(name, &reverb);

	releaseByteArrayElements(jenv, jname, (const char *)name);
	if(reverb && jreverb) {
		jlong newAddress = 0;
		*(FMOD::EventReverb **)&newAddress = reverb;
		setPointerAddress(jenv, jreverb, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1getReverbByIndex(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jobject jreverb) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}
	int index = (int)jindex;
	FMOD::EventReverb *reverb;

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->getReverbByIndex(index, &reverb);

	if(reverb && jreverb) {
		jlong newAddress = 0;
		*(FMOD::EventReverb **)&newAddress = reverb;
		setPointerAddress(jenv, jreverb, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1getNumReverbs(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jnumreverbs, jlong jnumreverbs_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}
	int *numreverbs = 0;
	if(jnumreverbs) {
		numreverbs = (int *)((char *)jenv->GetDirectBufferAddress(jnumreverbs)+jnumreverbs_);
	}

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->getNumReverbs(numreverbs);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1getGroup(JNIEnv *jenv, jclass jcls, jlong jPointer, jbyteArray jname, jboolean jcacheevents, jobject jgroup) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}
	char *name = getByteArrayElements(jenv, jname);
	bool cacheevents = (bool)(jcacheevents != 0);
	FMOD::EventGroup *group;

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->getGroup(name, cacheevents, &group);

	releaseByteArrayElements(jenv, jname, (const char *)name);
	if(group && jgroup) {
		jlong newAddress = 0;
		*(FMOD::EventGroup **)&newAddress = group;
		setPointerAddress(jenv, jgroup, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1getEvent(JNIEnv *jenv, jclass jcls, jlong jPointer, jbyteArray jname, jint jmode, jobject jevent) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}
	char *name = getByteArrayElements(jenv, jname);
	EVENT_MODE mode = (EVENT_MODE)jmode;
	FMOD::Event *event;

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->getEvent(name, mode, &event);

	releaseByteArrayElements(jenv, jname, (const char *)name);
	if(event && jevent) {
		jlong newAddress = 0;
		*(FMOD::Event **)&newAddress = event;
		setPointerAddress(jenv, jevent, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1getEventBySystemID(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jsystemid, jint jmode, jobject jevent) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}
	int systemid = (int)jsystemid;
	EVENT_MODE mode = (EVENT_MODE)jmode;
	FMOD::Event *event;

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->getEventBySystemID(systemid, mode, &event);

	if(event && jevent) {
		jlong newAddress = 0;
		*(FMOD::Event **)&newAddress = event;
		setPointerAddress(jenv, jevent, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1getNumEvents(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jnumevents, jlong jnumevents_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}
	int *numevents = 0;
	if(jnumevents) {
		numevents = (int *)((char *)jenv->GetDirectBufferAddress(jnumevents)+jnumevents_);
	}

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->getNumEvents(numevents);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1set3DNumListeners(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jnumlisteners) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}
	int numlisteners = (int)jnumlisteners;

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->set3DNumListeners(numlisteners);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1get3DNumListeners(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jnumlisteners, jlong jnumlisteners_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}
	int *numlisteners = 0;
	if(jnumlisteners) {
		numlisteners = (int *)((char *)jenv->GetDirectBufferAddress(jnumlisteners)+jnumlisteners_);
	}

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->get3DNumListeners(numlisteners);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1set3DListenerAttributes(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jlistener, jlong jpos, jlong jvel, jlong jforward, jlong jup) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}
	int listener = (int)jlistener;
	FMOD_VECTOR *pos = *(FMOD_VECTOR **)&jpos;
	FMOD_VECTOR *vel = *(FMOD_VECTOR **)&jvel;
	FMOD_VECTOR *forward = *(FMOD_VECTOR **)&jforward;
	FMOD_VECTOR *up = *(FMOD_VECTOR **)&jup;

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->set3DListenerAttributes(listener, pos, vel, forward, up);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1get3DListenerAttributes(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jlistener, jlong jpos, jlong jvel, jlong jforward, jlong jup) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}
	int listener = (int)jlistener;
	FMOD_VECTOR *pos = *(FMOD_VECTOR **)&jpos;
	FMOD_VECTOR *vel = *(FMOD_VECTOR **)&jvel;
	FMOD_VECTOR *forward = *(FMOD_VECTOR **)&jforward;
	FMOD_VECTOR *up = *(FMOD_VECTOR **)&jup;

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->get3DListenerAttributes(listener, pos, vel, forward, up);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1registerMemoryFSB(JNIEnv *jenv, jclass jcls, jlong jPointer, jbyteArray jfilename, jlong jfsbdata, jint jfsbdatalen) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}
	char *filename = getByteArrayElements(jenv, jfilename);
	void *fsbdata = *(void **)&jfsbdata;
	int fsbdatalen = (int)jfsbdatalen;

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->registerMemoryFSB(filename, fsbdata, fsbdatalen);

	releaseByteArrayElements(jenv, jfilename, (const char *)filename);
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventSystem_1unregisterMemoryFSB(JNIEnv *jenv, jclass jcls, jlong jPointer, jbyteArray jfilename) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTSYSTEM);
		return 0;
	}
	char *filename = getByteArrayElements(jenv, jfilename);

	FMOD_RESULT result_ = (*(FMOD::EventSystem **)&jPointer)->unregisterMemoryFSB(filename);

	releaseByteArrayElements(jenv, jfilename, (const char *)filename);
	return (jint)result_;
}


