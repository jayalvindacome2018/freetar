/**
 * 							NativeFmodEx Project
 *
 * Do you want to use FMOD Ex API (www.fmod.org) with the Java language ? I've created NativeFmodEx for you.
 * Copyright � 2005-2006 J�r�me JOUVIE (Jouvieje)
 *
 * Created on 23 feb. 2005
 * @version file v1.0.0
 * @author J�r�me JOUVIE (Jouvieje)
 * 
 * 
 * WANT TO CONTACT ME ?
 * E-mail :
 * 		jerome.jouvie@gmail.com
 * My web sites :
 * 		http://jerome.jouvie.free.fr/
 * 		http://topresult.tomato.co.uk/~jerome/
 * 
 * 
 * INTRODUCTION
 * FMOD Ex is an API (Application Programming Interface) that allow you to use music
 * and creating sound effects with a lot of sort of musics.
 * FMOD is at :
 * 		http://www.fmod.org/
 * The reason of this project is that FMOD Ex can't be used direcly with Java, so I've created
 * this project to do this.
 * 
 * 
 * GNU LESSER GENERAL PUBLIC LICENSE
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of the License,
 * or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA 
 */
#include "Utils.h"
#include "Pointer.h"
#include "fmod_event.h"
#include "fmod_event_net.h"
#include "org_jouvieje_FmodDesigner_FmodDesignerJNI.h"
#include "CallbackManager.h"

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1start(JNIEnv *jenv, jclass jcls, jlong jPointer) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->start();

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1stop(JNIEnv *jenv, jclass jcls, jlong jPointer, jboolean jimmediate) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	bool immediate = (bool)(jimmediate != 0);

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->stop(immediate);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1getInfo(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jindex, jlong jindex_, jobject jname, jlong jinfo) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	int *index = 0;
	if(jindex) {
		index = (int *)((char *)jenv->GetDirectBufferAddress(jindex)+jindex_);
	}
	char *name;
	FMOD::EVENT_INFO *info = *(FMOD::EVENT_INFO **)&jinfo;

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->getInfo(index, &name, info);

	if(name && jname) {
		jlong newAddress;
		*(char **)&newAddress = name;
		setPointerAddress(jenv, jname, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1getState(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jstate, jlong jstate_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	EVENT_STATE *state = 0;
	if(jstate) {
		state = (EVENT_STATE *)(int *)((char *)jenv->GetDirectBufferAddress(jstate)+jstate_);
	}

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->getState(state);

	jobject jresult = 0;
	if(result_) {
		jresult = jenv->NewDirectByteBuffer((EVENT_STATE *)(int *)result_, (jlong)-1);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1getParentGroup(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jgroup) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	FMOD::EventGroup *group;

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->getParentGroup(&group);

	if(group && jgroup) {
		jlong newAddress = 0;
		*(FMOD::EventGroup **)&newAddress = group;
		setPointerAddress(jenv, jgroup, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1getChannelGroup(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jchannelgroup) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	FMOD::ChannelGroup *channelgroup;

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->getChannelGroup(&channelgroup);

	if(channelgroup && jchannelgroup) {
		jlong newAddress = 0;
		*(FMOD::ChannelGroup **)&newAddress = channelgroup;
		setPointerAddress(jenv, jchannelgroup, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1setCallback(JNIEnv *jenv, jclass jcls, jlong jPointer, jboolean jcallback, jlong juserdata) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	void *userdata = *(void **)&juserdata;

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->setCallback(jcallback == 0 ? NULL : EVENT_CALLBACK_BRIDGE, userdata);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1getParameter(JNIEnv *jenv, jclass jcls, jlong jPointer, jbyteArray jname, jobject jparameter) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	char *name = getByteArrayElements(jenv, jname);
	FMOD::EventParameter *parameter;

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->getParameter(name, &parameter);

	releaseByteArrayElements(jenv, jname, (const char *)name);
	if(parameter && jparameter) {
		jlong newAddress = 0;
		*(FMOD::EventParameter **)&newAddress = parameter;
		setPointerAddress(jenv, jparameter, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1getParameterByIndex(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jobject jparameter) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	int index = (int)jindex;
	FMOD::EventParameter *parameter;

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->getParameterByIndex(index, &parameter);

	if(parameter && jparameter) {
		jlong newAddress = 0;
		*(FMOD::EventParameter **)&newAddress = parameter;
		setPointerAddress(jenv, jparameter, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1getNumParameters(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jnumparameters, jlong jnumparameters_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	int *numparameters = 0;
	if(jnumparameters) {
		numparameters = (int *)((char *)jenv->GetDirectBufferAddress(jnumparameters)+jnumparameters_);
	}

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->getNumParameters(numparameters);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1getProperty(JNIEnv *jenv, jclass jcls, jlong jPointer, jbyteArray jpropertyname, jlong jvalue) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	char *propertyname = getByteArrayElements(jenv, jpropertyname);
	void *value = *(void **)&jvalue;

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->getProperty(propertyname, value);

	releaseByteArrayElements(jenv, jpropertyname, (const char *)propertyname);
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1getPropertyByIndex(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jpropertyindex, jlong jvalue) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	int propertyindex = (int)jpropertyindex;
	void *value = *(void **)&jvalue;

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->getPropertyByIndex(propertyindex, value);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1getNumProperties(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jnumproperties, jlong jnumproperties_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	int *numproperties = 0;
	if(jnumproperties) {
		numproperties = (int *)((char *)jenv->GetDirectBufferAddress(jnumproperties)+jnumproperties_);
	}

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->getNumProperties(numproperties);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1getCategoryByIndex(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jcategoryindex, jobject jcategory) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	int categoryindex = (int)jcategoryindex;
	FMOD::EventCategory *category;

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->getCategoryByIndex(categoryindex, &category);

	if(category && jcategory) {
		jlong newAddress = 0;
		*(FMOD::EventCategory **)&newAddress = category;
		setPointerAddress(jenv, jcategory, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1getNumCategories(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jnumcategories, jlong jnumcategories_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	int *numcategories = 0;
	if(jnumcategories) {
		numcategories = (int *)((char *)jenv->GetDirectBufferAddress(jnumcategories)+jnumcategories_);
	}

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->getNumCategories(numcategories);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1setVolume(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jvolume) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	float volume = (float)jvolume;

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->setVolume(volume);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1getVolume(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jvolume, jlong jvolume_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	float *volume = 0;
	if(jvolume) {
		volume = (float *)((char *)jenv->GetDirectBufferAddress(jvolume)+jvolume_);
	}

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->getVolume(volume);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1setPitch(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jpitch) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	float pitch = (float)jpitch;

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->setPitch(pitch);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1getPitch(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jpitch, jlong jpitch_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	float *pitch = 0;
	if(jpitch) {
		pitch = (float *)((char *)jenv->GetDirectBufferAddress(jpitch)+jpitch_);
	}

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->getPitch(pitch);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1setPaused(JNIEnv *jenv, jclass jcls, jlong jPointer, jboolean jpaused) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	bool paused = (bool)(jpaused != 0);

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->setPaused(paused);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1getPaused(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jpaused, jlong jpaused_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	bool *paused =  0;
	if(jpaused) {
		paused = (bool *)((char *)jenv->GetDirectBufferAddress(jpaused)+jpaused_);
	}

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->getPaused(paused);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1setMute(JNIEnv *jenv, jclass jcls, jlong jPointer, jboolean jmute) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	bool mute = (bool)(jmute != 0);

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->setMute(mute);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1getMute(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jmute, jlong jmute_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	bool *mute =  0;
	if(jmute) {
		mute = (bool *)((char *)jenv->GetDirectBufferAddress(jmute)+jmute_);
	}

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->getMute(mute);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1set3DAttributes(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jposition, jlong jvelocity, jlong jorientation) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	FMOD_VECTOR *position = *(FMOD_VECTOR **)&jposition;
	FMOD_VECTOR *velocity = *(FMOD_VECTOR **)&jvelocity;
	FMOD_VECTOR *orientation = *(FMOD_VECTOR **)&jorientation;

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->set3DAttributes(position, velocity, orientation);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1get3DAttributes(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jposition, jlong jvelocity, jlong jorientation) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	FMOD_VECTOR *position = *(FMOD_VECTOR **)&jposition;
	FMOD_VECTOR *velocity = *(FMOD_VECTOR **)&jvelocity;
	FMOD_VECTOR *orientation = *(FMOD_VECTOR **)&jorientation;

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->get3DAttributes(position, velocity, orientation);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1set3DOcclusion(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jdirectocclusion, jfloat jreverbocclusion) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	float directocclusion = (float)jdirectocclusion;
	float reverbocclusion = (float)jreverbocclusion;

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->set3DOcclusion(directocclusion, reverbocclusion);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1get3DOcclusion(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jdirectocclusion, jlong jdirectocclusion_, jobject jreverbocclusion, jlong jreverbocclusion_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	float *directocclusion = 0;
	if(jdirectocclusion) {
		directocclusion = (float *)((char *)jenv->GetDirectBufferAddress(jdirectocclusion)+jdirectocclusion_);
	}
	float *reverbocclusion = 0;
	if(jreverbocclusion) {
		reverbocclusion = (float *)((char *)jenv->GetDirectBufferAddress(jreverbocclusion)+jreverbocclusion_);
	}

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->get3DOcclusion(directocclusion, reverbocclusion);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1setReverbProperties(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jprop) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	FMOD_REVERB_CHANNELPROPERTIES *prop = *(FMOD_REVERB_CHANNELPROPERTIES **)&jprop;

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->setReverbProperties(prop);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_Event_1getReverbProperties(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jprop) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENT);
		return 0;
	}
	FMOD_REVERB_CHANNELPROPERTIES *prop = *(FMOD_REVERB_CHANNELPROPERTIES **)&jprop;

	FMOD_RESULT result_ = (*(FMOD::Event **)&jPointer)->getReverbProperties(prop);

	return (jint)result_;
}


