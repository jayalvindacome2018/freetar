/**
 * 							NativeFmodEx Project
 *
 * Do you want to use FMOD Ex API (www.fmod.org) with the Java language ? I've created NativeFmodEx for you.
 * Copyright � 2005-2006 J�r�me JOUVIE (Jouvieje)
 *
 * Created on 23 feb. 2005
 * @version file v1.0.0
 * @author J�r�me JOUVIE (Jouvieje)
 * 
 * 
 * WANT TO CONTACT ME ?
 * E-mail :
 * 		jerome.jouvie@gmail.com
 * My web sites :
 * 		http://jerome.jouvie.free.fr/
 * 		http://topresult.tomato.co.uk/~jerome/
 * 
 * 
 * INTRODUCTION
 * FMOD Ex is an API (Application Programming Interface) that allow you to use music
 * and creating sound effects with a lot of sort of musics.
 * FMOD is at :
 * 		http://www.fmod.org/
 * The reason of this project is that FMOD Ex can't be used direcly with Java, so I've created
 * this project to do this.
 * 
 * 
 * GNU LESSER GENERAL PUBLIC LICENSE
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of the License,
 * or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA 
 */
#include "Utils.h"
#include "Pointer.h"
#include "fmod_event.h"
#include "fmod_event_net.h"
#include "org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI.h"
#include "CallbackManager.h"

				/* EVENT_PROPERTY */

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_1NAME(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_NAME;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_1VOLUME(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_VOLUME;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_1PITCH(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_PITCH;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_1PITCHRANDOMIZATION(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_PITCHRANDOMIZATION;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_1PRIORITY(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_PRIORITY;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_1MAX_1PLAYBACKS(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_MAX_PLAYBACKS;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_1MAX_1PLAYBACKS_1BEHAVIOR(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_MAX_PLAYBACKS_BEHAVIOR;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_1MODE(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_MODE;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_13D_1ROLLOFF(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_3D_ROLLOFF;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_13D_1MINDISTANCE(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_3D_MINDISTANCE;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_13D_1MAXDISTANCE(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_3D_MAXDISTANCE;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_13D_1POSITION(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_3D_POSITION;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_13D_1CONEINSIDEANGLE(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_3D_CONEINSIDEANGLE;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_13D_1CONEOUTSIDEANGLE(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_3D_CONEOUTSIDEANGLE;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_13D_1CONEOUTSIDEVOLUME(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_3D_CONEOUTSIDEVOLUME;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_13D_1DOPPLERSCALE(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_3D_DOPPLERSCALE;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_13D_1SPEAKERSPREAD(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_3D_SPEAKERSPREAD;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_13D_1PANLEVEL(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_3D_PANLEVEL;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_1SPEAKER_1L(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_SPEAKER_L;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_1SPEAKER_1C(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_SPEAKER_C;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_1SPEAKER_1R(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_SPEAKER_R;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_1SPEAKER_1LS(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_SPEAKER_LS;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_1SPEAKER_1RS(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_SPEAKER_RS;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_1SPEAKER_1LR(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_SPEAKER_LR;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_1SPEAKER_1RR(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_SPEAKER_RR;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_1SPEAKER_1LFE(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_SPEAKER_LFE;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_1REVERBLEVEL(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_REVERBLEVEL;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_1MUSIC(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_MUSIC;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_1ONESHOT(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_ONESHOT;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_1FADEIN(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_FADEIN;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_1FADEOUT(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_FADEOUT;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENTPROPERTY_1USER_1BASE(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENTPROPERTY_USER_BASE;
}

				/* EVENT_RESOURCE */

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENT_1RESOURCE_1STREAMS_1AND_1SAMPLES(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENT_RESOURCE_STREAMS_AND_SAMPLES;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENT_1RESOURCE_1STREAMS(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENT_RESOURCE_STREAMS;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENT_1RESOURCE_1SAMPLES(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENT_RESOURCE_SAMPLES;
}

				/* EVENT_CALLBACKTYPE */

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENT_1CALLBACKTYPE_1SYNCPOINT(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENT_CALLBACKTYPE_SYNCPOINT;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENT_1CALLBACKTYPE_1SOUNDDEF_1START(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENT_CALLBACKTYPE_SOUNDDEF_START;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENT_1CALLBACKTYPE_1SOUNDDEF_1END(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENT_CALLBACKTYPE_SOUNDDEF_END;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENT_1CALLBACKTYPE_1STOLEN(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENT_CALLBACKTYPE_STOLEN;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENT_1CALLBACKTYPE_1EVENTFINISHED(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENT_CALLBACKTYPE_EVENTFINISHED;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENT_1CALLBACKTYPE_1NET_1MODIFIED(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENT_CALLBACKTYPE_NET_MODIFIED;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENT_1CALLBACKTYPE_1SOUNDDEF_1CREATE(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENT_CALLBACKTYPE_SOUNDDEF_CREATE;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENT_1CALLBACKTYPE_1SOUNDDEF_1RELEASE(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENT_CALLBACKTYPE_SOUNDDEF_RELEASE;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_Enumerations_EnumerationJNI_get_1EVENT_1CALLBACKTYPE_1SOUNDDEF_1INFO(JNIEnv *jenv, jclass jcls) {
	return (jint)FMOD::EVENT_CALLBACKTYPE_SOUNDDEF_INFO;
}


