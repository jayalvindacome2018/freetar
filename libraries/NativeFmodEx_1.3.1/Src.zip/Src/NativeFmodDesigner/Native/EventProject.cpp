/**
 * 							NativeFmodEx Project
 *
 * Do you want to use FMOD Ex API (www.fmod.org) with the Java language ? I've created NativeFmodEx for you.
 * Copyright � 2005-2006 J�r�me JOUVIE (Jouvieje)
 *
 * Created on 23 feb. 2005
 * @version file v1.0.0
 * @author J�r�me JOUVIE (Jouvieje)
 * 
 * 
 * WANT TO CONTACT ME ?
 * E-mail :
 * 		jerome.jouvie@gmail.com
 * My web sites :
 * 		http://jerome.jouvie.free.fr/
 * 		http://topresult.tomato.co.uk/~jerome/
 * 
 * 
 * INTRODUCTION
 * FMOD Ex is an API (Application Programming Interface) that allow you to use music
 * and creating sound effects with a lot of sort of musics.
 * FMOD is at :
 * 		http://www.fmod.org/
 * The reason of this project is that FMOD Ex can't be used direcly with Java, so I've created
 * this project to do this.
 * 
 * 
 * GNU LESSER GENERAL PUBLIC LICENSE
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of the License,
 * or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA 
 */
#include "Utils.h"
#include "Pointer.h"
#include "fmod_event.h"
#include "fmod_event_net.h"
#include "org_jouvieje_FmodDesigner_FmodDesignerJNI.h"
#include "CallbackManager.h"

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventProject_1release(JNIEnv *jenv, jclass jcls, jlong jPointer) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTPROJECT);
		return 0;
	}

	FMOD_RESULT result_ = (*(FMOD::EventProject **)&jPointer)->release();

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventProject_1getInfo(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jindex, jlong jindex_, jobject jname) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTPROJECT);
		return 0;
	}
	int *index = 0;
	if(jindex) {
		index = (int *)((char *)jenv->GetDirectBufferAddress(jindex)+jindex_);
	}
	char *name;

	FMOD_RESULT result_ = (*(FMOD::EventProject **)&jPointer)->getInfo(index, &name);

	if(name && jname) {
		jlong newAddress;
		*(char **)&newAddress = name;
		setPointerAddress(jenv, jname, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventProject_1getGroup(JNIEnv *jenv, jclass jcls, jlong jPointer, jbyteArray jname, jboolean jcacheevents, jobject jgroup) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTPROJECT);
		return 0;
	}
	char *name = getByteArrayElements(jenv, jname);
	bool cacheevents = (bool)(jcacheevents != 0);
	FMOD::EventGroup *group;

	FMOD_RESULT result_ = (*(FMOD::EventProject **)&jPointer)->getGroup(name, cacheevents, &group);

	releaseByteArrayElements(jenv, jname, (const char *)name);
	if(group && jgroup) {
		jlong newAddress = 0;
		*(FMOD::EventGroup **)&newAddress = group;
		setPointerAddress(jenv, jgroup, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventProject_1getGroupByIndex(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jboolean jcacheevents, jobject jgroup) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTPROJECT);
		return 0;
	}
	int index = (int)jindex;
	bool cacheevents = (bool)(jcacheevents != 0);
	FMOD::EventGroup *group;

	FMOD_RESULT result_ = (*(FMOD::EventProject **)&jPointer)->getGroupByIndex(index, cacheevents, &group);

	if(group && jgroup) {
		jlong newAddress = 0;
		*(FMOD::EventGroup **)&newAddress = group;
		setPointerAddress(jenv, jgroup, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventProject_1getNumGroups(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jnumgroups, jlong jnumgroups_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTPROJECT);
		return 0;
	}
	int *numgroups = 0;
	if(jnumgroups) {
		numgroups = (int *)((char *)jenv->GetDirectBufferAddress(jnumgroups)+jnumgroups_);
	}

	FMOD_RESULT result_ = (*(FMOD::EventProject **)&jPointer)->getNumGroups(numgroups);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventProject_1getEvent(JNIEnv *jenv, jclass jcls, jlong jPointer, jbyteArray jname, jint jmode, jobject jevent) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTPROJECT);
		return 0;
	}
	char *name = getByteArrayElements(jenv, jname);
	EVENT_MODE mode = (EVENT_MODE)jmode;
	FMOD::Event *event;

	FMOD_RESULT result_ = (*(FMOD::EventProject **)&jPointer)->getEvent(name, mode, &event);

	releaseByteArrayElements(jenv, jname, (const char *)name);
	if(event && jevent) {
		jlong newAddress = 0;
		*(FMOD::Event **)&newAddress = event;
		setPointerAddress(jenv, jevent, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventProject_1getEventByProjectID(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jprojectid, jint jmode, jobject jevent) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTPROJECT);
		return 0;
	}
	int projectid = (int)jprojectid;
	EVENT_MODE mode = (EVENT_MODE)jmode;
	FMOD::Event *event;

	FMOD_RESULT result_ = (*(FMOD::EventProject **)&jPointer)->getEventByProjectID(projectid, mode, &event);

	if(event && jevent) {
		jlong newAddress = 0;
		*(FMOD::Event **)&newAddress = event;
		setPointerAddress(jenv, jevent, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventProject_1getNumEvents(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jnumevents, jlong jnumevents_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTPROJECT);
		return 0;
	}
	int *numevents = 0;
	if(jnumevents) {
		numevents = (int *)((char *)jenv->GetDirectBufferAddress(jnumevents)+jnumevents_);
	}

	FMOD_RESULT result_ = (*(FMOD::EventProject **)&jPointer)->getNumEvents(numevents);

	return (jint)result_;
}


