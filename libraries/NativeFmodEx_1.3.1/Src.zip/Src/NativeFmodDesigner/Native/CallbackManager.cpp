/**
 * 							NativeFmodEx Project
 *
 * Do you want to use FMOD Ex API (www.fmod.org) with the Java language ? I've created NativeFmodEx for you.
 * Copyright � 2005-2006 J�r�me JOUVIE (Jouvieje)
 *
 * Created on 23 feb. 2005
 * @version file v1.0.0
 * @author J�r�me JOUVIE (Jouvieje)
 * 
 * 
 * WANT TO CONTACT ME ?
 * E-mail :
 * 		jerome.jouvie@gmail.com
 * My web sites :
 * 		http://jerome.jouvie.free.fr/
 * 		http://topresult.tomato.co.uk/~jerome/
 * 
 * 
 * INTRODUCTION
 * FMOD Ex is an API (Application Programming Interface) that allow you to use music
 * and creating sound effects with a lot of sort of musics.
 * FMOD is at :
 * 		http://www.fmod.org/
 * The reason of this project is that FMOD Ex can't be used direcly with Java, so I've created
 * this project to do this.
 * 
 * 
 * GNU LESSER GENERAL PUBLIC LICENSE
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of the License,
 * or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA 
 */
#include "Utils.h"
#include "Pointer.h"
#include "fmod_event.h"
#include "fmod_event_net.h"
#include "malloc.h"
#include "CallbackManager.h"

jclass byteBufferClass = 0;
jclass getByteBufferClass(JNIEnv *jenv) {
	if(!byteBufferClass) {
		byteBufferClass = (jclass)jenv->NewGlobalRef(jenv->FindClass("java/nio/ByteBuffer"));
	}
	return byteBufferClass;
}

jclass caller = 0;
void connectCaller(JNIEnv *jenv) {
	caller = (jclass)jenv->NewGlobalRef(jenv->FindClass("org/jouvieje/FmodDesigner/Callbacks/CallbackBridge"));
	if(jenv->ExceptionCheck()) {
		jenv->ExceptionClear();
		caller = 0;
		ThrowException(jenv, InitException, "Connection to CallbackBridge fails.");
	}
}

jmethodID callbackId[1];
void connectCallbacks(JNIEnv *jenv) {
	static struct {
		const char *name;
		const char *signature;
	}callbacks[1] = {
		{"EVENT_CALLBACK_BRIDGE", "(JIJJJ)I"}
	};

	for(int i = 0; i < 1; i++) {
		callbackId[i] = jenv->GetStaticMethodID(caller, callbacks[i].name, callbacks[i].signature);
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionClear();
			ThrowException(jenv, InitException, "Connection to a Callback fails.");
			return;
		}
	}
}

JavaVM *jvm;
void attachJavaVM(JNIEnv *jenv) {
	jenv->GetJavaVM(&jvm);
	connectCaller(jenv);
	if(caller) {
		connectCallbacks(jenv);
	}
}
bool acquire_jenv(JNIEnv **jenv) {
	if(jvm->GetEnv((void **)jenv, JNI_VERSION_1_4) != JNI_OK) {
		jvm->AttachCurrentThread((void **)jenv, 0);
		return true;
	}
	return false;
}
void leave_jenv(bool attached) {
	if(attached) {
		jvm->DetachCurrentThread();
	}
}

FMOD_RESULT F_CALLBACK EVENT_CALLBACK_BRIDGE(FMOD::Event * event, FMOD::EVENT_CALLBACKTYPE type, void * param1, void * param2, void * userdata) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jlong jevent = 0;
	*(FMOD::Event **)&jevent = (FMOD::Event *)event;
	jlong jparam1 = 0;
	*(void **)&jparam1 = param1;
	jlong jparam2 = 0;
	*(void **)&jparam2 = param2;
	jlong juserdata = 0;
	*(void **)&juserdata = userdata;
	jint result_ = jenv->CallStaticIntMethod(caller, callbackId[0], jevent, (jint)type, jparam1, jparam2, juserdata);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	leave_jenv(attached);
	return (FMOD_RESULT)result_;
}


