/**
 * 							NativeFmodEx Project
 *
 * Do you want to use FMOD Ex API (www.fmod.org) with the Java language ? I've created NativeFmodEx for you.
 * Copyright � 2005-2006 J�r�me JOUVIE (Jouvieje)
 *
 * Created on 23 feb. 2005
 * @version file v1.0.0
 * @author J�r�me JOUVIE (Jouvieje)
 * 
 * 
 * WANT TO CONTACT ME ?
 * E-mail :
 * 		jerome.jouvie@gmail.com
 * My web sites :
 * 		http://jerome.jouvie.free.fr/
 * 		http://topresult.tomato.co.uk/~jerome/
 * 
 * 
 * INTRODUCTION
 * FMOD Ex is an API (Application Programming Interface) that allow you to use music
 * and creating sound effects with a lot of sort of musics.
 * FMOD is at :
 * 		http://www.fmod.org/
 * The reason of this project is that FMOD Ex can't be used direcly with Java, so I've created
 * this project to do this.
 * 
 * 
 * GNU LESSER GENERAL PUBLIC LICENSE
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of the License,
 * or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA 
 */
#include "Utils.h"
#include "Pointer.h"
#include "fmod_event.h"
#include "fmod_event_net.h"
#include "org_jouvieje_FmodDesigner_FmodDesignerJNI.h"
#include "CallbackManager.h"

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventCategory_1getInfo(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jindex, jlong jindex_, jobject jname) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTCATEGORY);
		return 0;
	}
	int *index = 0;
	if(jindex) {
		index = (int *)((char *)jenv->GetDirectBufferAddress(jindex)+jindex_);
	}
	char *name;

	FMOD_RESULT result_ = (*(FMOD::EventCategory **)&jPointer)->getInfo(index, &name);

	if(name && jname) {
		jlong newAddress;
		*(char **)&newAddress = name;
		setPointerAddress(jenv, jname, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventCategory_1getCategory(JNIEnv *jenv, jclass jcls, jlong jPointer, jbyteArray jname, jobject jcategory) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTCATEGORY);
		return 0;
	}
	char *name = getByteArrayElements(jenv, jname);
	FMOD::EventCategory *category;

	FMOD_RESULT result_ = (*(FMOD::EventCategory **)&jPointer)->getCategory(name, &category);

	releaseByteArrayElements(jenv, jname, (const char *)name);
	if(category && jcategory) {
		jlong newAddress = 0;
		*(FMOD::EventCategory **)&newAddress = category;
		setPointerAddress(jenv, jcategory, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventCategory_1getCategoryByIndex(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jobject jcategory) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTCATEGORY);
		return 0;
	}
	int index = (int)jindex;
	FMOD::EventCategory *category;

	FMOD_RESULT result_ = (*(FMOD::EventCategory **)&jPointer)->getCategoryByIndex(index, &category);

	if(category && jcategory) {
		jlong newAddress = 0;
		*(FMOD::EventCategory **)&newAddress = category;
		setPointerAddress(jenv, jcategory, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventCategory_1getNumCategories(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jnumcategories, jlong jnumcategories_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTCATEGORY);
		return 0;
	}
	int *numcategories = 0;
	if(jnumcategories) {
		numcategories = (int *)((char *)jenv->GetDirectBufferAddress(jnumcategories)+jnumcategories_);
	}

	FMOD_RESULT result_ = (*(FMOD::EventCategory **)&jPointer)->getNumCategories(numcategories);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventCategory_1getParameter(JNIEnv *jenv, jclass jcls, jlong jPointer, jbyteArray jname, jobject jparameter) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTCATEGORY);
		return 0;
	}
	char *name = getByteArrayElements(jenv, jname);
	FMOD::EventParameter *parameter;

	FMOD_RESULT result_ = (*(FMOD::EventCategory **)&jPointer)->getParameter(name, &parameter);

	releaseByteArrayElements(jenv, jname, (const char *)name);
	if(parameter && jparameter) {
		jlong newAddress = 0;
		*(FMOD::EventParameter **)&newAddress = parameter;
		setPointerAddress(jenv, jparameter, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventCategory_1getParameterByIndex(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jobject jparameter) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTCATEGORY);
		return 0;
	}
	int index = (int)jindex;
	FMOD::EventParameter *parameter;

	FMOD_RESULT result_ = (*(FMOD::EventCategory **)&jPointer)->getParameterByIndex(index, &parameter);

	if(parameter && jparameter) {
		jlong newAddress = 0;
		*(FMOD::EventParameter **)&newAddress = parameter;
		setPointerAddress(jenv, jparameter, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventCategory_1getNumParameters(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jnumparameters, jlong jnumparameters_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTCATEGORY);
		return 0;
	}
	int *numparameters = 0;
	if(jnumparameters) {
		numparameters = (int *)((char *)jenv->GetDirectBufferAddress(jnumparameters)+jnumparameters_);
	}

	FMOD_RESULT result_ = (*(FMOD::EventCategory **)&jPointer)->getNumParameters(numparameters);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventCategory_1stopAllEvents(JNIEnv *jenv, jclass jcls, jlong jPointer) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTCATEGORY);
		return 0;
	}

	FMOD_RESULT result_ = (*(FMOD::EventCategory **)&jPointer)->stopAllEvents();

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventCategory_1setVolume(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jvolume) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTCATEGORY);
		return 0;
	}
	float volume = (float)jvolume;

	FMOD_RESULT result_ = (*(FMOD::EventCategory **)&jPointer)->setVolume(volume);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventCategory_1getVolume(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jvolume, jlong jvolume_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTCATEGORY);
		return 0;
	}
	float *volume = 0;
	if(jvolume) {
		volume = (float *)((char *)jenv->GetDirectBufferAddress(jvolume)+jvolume_);
	}

	FMOD_RESULT result_ = (*(FMOD::EventCategory **)&jPointer)->getVolume(volume);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventCategory_1setPitch(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jpitch) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTCATEGORY);
		return 0;
	}
	float pitch = (float)jpitch;

	FMOD_RESULT result_ = (*(FMOD::EventCategory **)&jPointer)->setPitch(pitch);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventCategory_1getPitch(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jpitch, jlong jpitch_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTCATEGORY);
		return 0;
	}
	float *pitch = 0;
	if(jpitch) {
		pitch = (float *)((char *)jenv->GetDirectBufferAddress(jpitch)+jpitch_);
	}

	FMOD_RESULT result_ = (*(FMOD::EventCategory **)&jPointer)->getPitch(pitch);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventCategory_1setPaused(JNIEnv *jenv, jclass jcls, jlong jPointer, jboolean jpaused) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTCATEGORY);
		return 0;
	}
	bool paused = (bool)(jpaused != 0);

	FMOD_RESULT result_ = (*(FMOD::EventCategory **)&jPointer)->setPaused(paused);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventCategory_1getPaused(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jpaused, jlong jpaused_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTCATEGORY);
		return 0;
	}
	bool *paused =  0;
	if(jpaused) {
		paused = (bool *)((char *)jenv->GetDirectBufferAddress(jpaused)+jpaused_);
	}

	FMOD_RESULT result_ = (*(FMOD::EventCategory **)&jPointer)->getPaused(paused);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventCategory_1setMute(JNIEnv *jenv, jclass jcls, jlong jPointer, jboolean jmute) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTCATEGORY);
		return 0;
	}
	bool mute = (bool)(jmute != 0);

	FMOD_RESULT result_ = (*(FMOD::EventCategory **)&jPointer)->setMute(mute);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventCategory_1getMute(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jmute, jlong jmute_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTCATEGORY);
		return 0;
	}
	bool *mute =  0;
	if(jmute) {
		mute = (bool *)((char *)jenv->GetDirectBufferAddress(jmute)+jmute_);
	}

	FMOD_RESULT result_ = (*(FMOD::EventCategory **)&jPointer)->getMute(mute);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodDesigner_FmodDesignerJNI_EventCategory_1getChannelGroup(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jchannelgroup) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_EVENTCATEGORY);
		return 0;
	}
	FMOD::ChannelGroup *channelgroup;

	FMOD_RESULT result_ = (*(FMOD::EventCategory **)&jPointer)->getChannelGroup(&channelgroup);

	if(channelgroup && jchannelgroup) {
		jlong newAddress = 0;
		*(FMOD::ChannelGroup **)&newAddress = channelgroup;
		setPointerAddress(jenv, jchannelgroup, newAddress);
	}
	return (jint)result_;
}


