/**
 * 							NativeFmodEx Project
 *
 * Do you want to use FMOD Ex API (www.fmod.org) with the Java language ? I've created NativeFmodEx for you.
 * Copyright � 2005-2006 J�r�me JOUVIE (Jouvieje)
 *
 * Created on 23 feb. 2005
 * @version file v1.0.0
 * @author J�r�me JOUVIE (Jouvieje)
 * 
 * 
 * WANT TO CONTACT ME ?
 * E-mail :
 * 		jerome.jouvie@gmail.com
 * My web sites :
 * 		http://jerome.jouvie.free.fr/
 * 		http://topresult.tomato.co.uk/~jerome/
 * 
 * 
 * INTRODUCTION
 * FMOD Ex is an API (Application Programming Interface) that allow you to use music
 * and creating sound effects with a lot of sort of musics.
 * FMOD is at :
 * 		http://www.fmod.org/
 * The reason of this project is that FMOD Ex can't be used direcly with Java, so I've created
 * this project to do this.
 * 
 * 
 * GNU LESSER GENERAL PUBLIC LICENSE
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of the License,
 * or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA 
 */
#include "Utils.h"
#include "Pointer.h"
#include "fmod.h"
#include "fmod.hpp"
#include "fmod_codec.h"
#include "fmod_dsp.h"
#include "fmod_output.h"
#include "org_jouvieje_FmodEx_Structures_StructureJNI.h"
#include "CallbackManager.h"

JNIEXPORT jlong JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1new(JNIEnv *jenv, jclass jcls) {
	FMOD_REVERB_PROPERTIES *result_ = new FMOD_REVERB_PROPERTIES();
	jlong jresult = 0;
	*(FMOD_REVERB_PROPERTIES **)&jresult = result_;
	return jresult;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1delete(JNIEnv *jenv, jclass jcls, jlong pointer) {
	delete *(FMOD_REVERB_PROPERTIES **)&pointer;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1get_1Instance(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return 0;
	}
	int result_ = (*(FMOD_REVERB_PROPERTIES **)&pointer)->Instance;
	return (jint)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1set_1Instance(JNIEnv *jenv, jclass jcls, jlong pointer, jint jInstance) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return;
	}
	int Instance = (int)jInstance;
	(*(FMOD_REVERB_PROPERTIES **)&pointer)->Instance = Instance;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1get_1Environment(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return 0;
	}
	int result_ = (*(FMOD_REVERB_PROPERTIES **)&pointer)->Environment;
	return (jint)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1set_1Environment(JNIEnv *jenv, jclass jcls, jlong pointer, jint jEnvironment) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return;
	}
	int Environment = (int)jEnvironment;
	(*(FMOD_REVERB_PROPERTIES **)&pointer)->Environment = Environment;
}

JNIEXPORT jfloat JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1get_1EnvSize(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return 0;
	}
	float result_ = (*(FMOD_REVERB_PROPERTIES **)&pointer)->EnvSize;
	return (jfloat)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1set_1EnvSize(JNIEnv *jenv, jclass jcls, jlong pointer, jfloat jEnvSize) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return;
	}
	float EnvSize = (float)jEnvSize;
	(*(FMOD_REVERB_PROPERTIES **)&pointer)->EnvSize = EnvSize;
}

JNIEXPORT jfloat JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1get_1EnvDiffusion(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return 0;
	}
	float result_ = (*(FMOD_REVERB_PROPERTIES **)&pointer)->EnvDiffusion;
	return (jfloat)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1set_1EnvDiffusion(JNIEnv *jenv, jclass jcls, jlong pointer, jfloat jEnvDiffusion) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return;
	}
	float EnvDiffusion = (float)jEnvDiffusion;
	(*(FMOD_REVERB_PROPERTIES **)&pointer)->EnvDiffusion = EnvDiffusion;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1get_1Room(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return 0;
	}
	int result_ = (*(FMOD_REVERB_PROPERTIES **)&pointer)->Room;
	return (jint)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1set_1Room(JNIEnv *jenv, jclass jcls, jlong pointer, jint jRoom) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return;
	}
	int Room = (int)jRoom;
	(*(FMOD_REVERB_PROPERTIES **)&pointer)->Room = Room;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1get_1RoomHF(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return 0;
	}
	int result_ = (*(FMOD_REVERB_PROPERTIES **)&pointer)->RoomHF;
	return (jint)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1set_1RoomHF(JNIEnv *jenv, jclass jcls, jlong pointer, jint jRoomHF) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return;
	}
	int RoomHF = (int)jRoomHF;
	(*(FMOD_REVERB_PROPERTIES **)&pointer)->RoomHF = RoomHF;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1get_1RoomLF(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return 0;
	}
	int result_ = (*(FMOD_REVERB_PROPERTIES **)&pointer)->RoomLF;
	return (jint)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1set_1RoomLF(JNIEnv *jenv, jclass jcls, jlong pointer, jint jRoomLF) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return;
	}
	int RoomLF = (int)jRoomLF;
	(*(FMOD_REVERB_PROPERTIES **)&pointer)->RoomLF = RoomLF;
}

JNIEXPORT jfloat JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1get_1DecayTime(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return 0;
	}
	float result_ = (*(FMOD_REVERB_PROPERTIES **)&pointer)->DecayTime;
	return (jfloat)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1set_1DecayTime(JNIEnv *jenv, jclass jcls, jlong pointer, jfloat jDecayTime) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return;
	}
	float DecayTime = (float)jDecayTime;
	(*(FMOD_REVERB_PROPERTIES **)&pointer)->DecayTime = DecayTime;
}

JNIEXPORT jfloat JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1get_1DecayHFRatio(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return 0;
	}
	float result_ = (*(FMOD_REVERB_PROPERTIES **)&pointer)->DecayHFRatio;
	return (jfloat)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1set_1DecayHFRatio(JNIEnv *jenv, jclass jcls, jlong pointer, jfloat jDecayHFRatio) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return;
	}
	float DecayHFRatio = (float)jDecayHFRatio;
	(*(FMOD_REVERB_PROPERTIES **)&pointer)->DecayHFRatio = DecayHFRatio;
}

JNIEXPORT jfloat JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1get_1DecayLFRatio(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return 0;
	}
	float result_ = (*(FMOD_REVERB_PROPERTIES **)&pointer)->DecayLFRatio;
	return (jfloat)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1set_1DecayLFRatio(JNIEnv *jenv, jclass jcls, jlong pointer, jfloat jDecayLFRatio) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return;
	}
	float DecayLFRatio = (float)jDecayLFRatio;
	(*(FMOD_REVERB_PROPERTIES **)&pointer)->DecayLFRatio = DecayLFRatio;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1get_1Reflections(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return 0;
	}
	int result_ = (*(FMOD_REVERB_PROPERTIES **)&pointer)->Reflections;
	return (jint)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1set_1Reflections(JNIEnv *jenv, jclass jcls, jlong pointer, jint jReflections) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return;
	}
	int Reflections = (int)jReflections;
	(*(FMOD_REVERB_PROPERTIES **)&pointer)->Reflections = Reflections;
}

JNIEXPORT jfloat JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1get_1ReflectionsDelay(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return 0;
	}
	float result_ = (*(FMOD_REVERB_PROPERTIES **)&pointer)->ReflectionsDelay;
	return (jfloat)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1set_1ReflectionsDelay(JNIEnv *jenv, jclass jcls, jlong pointer, jfloat jReflectionsDelay) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return;
	}
	float ReflectionsDelay = (float)jReflectionsDelay;
	(*(FMOD_REVERB_PROPERTIES **)&pointer)->ReflectionsDelay = ReflectionsDelay;
}

JNIEXPORT jobject JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1get_1ReflectionsPan(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return 0;
	}
	float *result_ = (float *)(*(FMOD_REVERB_PROPERTIES **)&pointer)->ReflectionsPan;
	jobject jresult = 0;
	if(result_) {
		jresult = jenv->NewDirectByteBuffer(result_, (jlong)(3*sizeof(float)));
	}
	return jresult;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1set_1ReflectionsPan(JNIEnv *jenv, jclass jcls, jlong pointer, jobject jReflectionsPan, jlong jReflectionsPan_) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return;
	}
	float *ReflectionsPan = 0;
	if(jReflectionsPan) {
		ReflectionsPan = (float *)((char *)jenv->GetDirectBufferAddress(jReflectionsPan)+jReflectionsPan_);
	}
	float *temp = (float *)(*(FMOD_REVERB_PROPERTIES **)&pointer)->ReflectionsPan;
	for(int i = 0; i < 3; i++) {
		temp[i] = *((float *) ReflectionsPan + i);
	}
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1get_1Reverb(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return 0;
	}
	int result_ = (*(FMOD_REVERB_PROPERTIES **)&pointer)->Reverb;
	return (jint)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1set_1Reverb(JNIEnv *jenv, jclass jcls, jlong pointer, jint jReverb) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return;
	}
	int Reverb = (int)jReverb;
	(*(FMOD_REVERB_PROPERTIES **)&pointer)->Reverb = Reverb;
}

JNIEXPORT jfloat JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1get_1ReverbDelay(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return 0;
	}
	float result_ = (*(FMOD_REVERB_PROPERTIES **)&pointer)->ReverbDelay;
	return (jfloat)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1set_1ReverbDelay(JNIEnv *jenv, jclass jcls, jlong pointer, jfloat jReverbDelay) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return;
	}
	float ReverbDelay = (float)jReverbDelay;
	(*(FMOD_REVERB_PROPERTIES **)&pointer)->ReverbDelay = ReverbDelay;
}

JNIEXPORT jobject JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1get_1ReverbPan(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return 0;
	}
	float *result_ = (float *)(*(FMOD_REVERB_PROPERTIES **)&pointer)->ReverbPan;
	jobject jresult = 0;
	if(result_) {
		jresult = jenv->NewDirectByteBuffer(result_, (jlong)(3*sizeof(float)));
	}
	return jresult;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1set_1ReverbPan(JNIEnv *jenv, jclass jcls, jlong pointer, jobject jReverbPan, jlong jReverbPan_) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return;
	}
	float *ReverbPan = 0;
	if(jReverbPan) {
		ReverbPan = (float *)((char *)jenv->GetDirectBufferAddress(jReverbPan)+jReverbPan_);
	}
	float *temp = (float *)(*(FMOD_REVERB_PROPERTIES **)&pointer)->ReverbPan;
	for(int i = 0; i < 3; i++) {
		temp[i] = *((float *) ReverbPan + i);
	}
}

JNIEXPORT jfloat JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1get_1EchoTime(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return 0;
	}
	float result_ = (*(FMOD_REVERB_PROPERTIES **)&pointer)->EchoTime;
	return (jfloat)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1set_1EchoTime(JNIEnv *jenv, jclass jcls, jlong pointer, jfloat jEchoTime) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return;
	}
	float EchoTime = (float)jEchoTime;
	(*(FMOD_REVERB_PROPERTIES **)&pointer)->EchoTime = EchoTime;
}

JNIEXPORT jfloat JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1get_1EchoDepth(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return 0;
	}
	float result_ = (*(FMOD_REVERB_PROPERTIES **)&pointer)->EchoDepth;
	return (jfloat)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1set_1EchoDepth(JNIEnv *jenv, jclass jcls, jlong pointer, jfloat jEchoDepth) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return;
	}
	float EchoDepth = (float)jEchoDepth;
	(*(FMOD_REVERB_PROPERTIES **)&pointer)->EchoDepth = EchoDepth;
}

JNIEXPORT jfloat JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1get_1ModulationTime(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return 0;
	}
	float result_ = (*(FMOD_REVERB_PROPERTIES **)&pointer)->ModulationTime;
	return (jfloat)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1set_1ModulationTime(JNIEnv *jenv, jclass jcls, jlong pointer, jfloat jModulationTime) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return;
	}
	float ModulationTime = (float)jModulationTime;
	(*(FMOD_REVERB_PROPERTIES **)&pointer)->ModulationTime = ModulationTime;
}

JNIEXPORT jfloat JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1get_1ModulationDepth(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return 0;
	}
	float result_ = (*(FMOD_REVERB_PROPERTIES **)&pointer)->ModulationDepth;
	return (jfloat)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1set_1ModulationDepth(JNIEnv *jenv, jclass jcls, jlong pointer, jfloat jModulationDepth) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return;
	}
	float ModulationDepth = (float)jModulationDepth;
	(*(FMOD_REVERB_PROPERTIES **)&pointer)->ModulationDepth = ModulationDepth;
}

JNIEXPORT jfloat JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1get_1AirAbsorptionHF(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return 0;
	}
	float result_ = (*(FMOD_REVERB_PROPERTIES **)&pointer)->AirAbsorptionHF;
	return (jfloat)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1set_1AirAbsorptionHF(JNIEnv *jenv, jclass jcls, jlong pointer, jfloat jAirAbsorptionHF) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return;
	}
	float AirAbsorptionHF = (float)jAirAbsorptionHF;
	(*(FMOD_REVERB_PROPERTIES **)&pointer)->AirAbsorptionHF = AirAbsorptionHF;
}

JNIEXPORT jfloat JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1get_1HFReference(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return 0;
	}
	float result_ = (*(FMOD_REVERB_PROPERTIES **)&pointer)->HFReference;
	return (jfloat)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1set_1HFReference(JNIEnv *jenv, jclass jcls, jlong pointer, jfloat jHFReference) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return;
	}
	float HFReference = (float)jHFReference;
	(*(FMOD_REVERB_PROPERTIES **)&pointer)->HFReference = HFReference;
}

JNIEXPORT jfloat JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1get_1LFReference(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return 0;
	}
	float result_ = (*(FMOD_REVERB_PROPERTIES **)&pointer)->LFReference;
	return (jfloat)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1set_1LFReference(JNIEnv *jenv, jclass jcls, jlong pointer, jfloat jLFReference) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return;
	}
	float LFReference = (float)jLFReference;
	(*(FMOD_REVERB_PROPERTIES **)&pointer)->LFReference = LFReference;
}

JNIEXPORT jfloat JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1get_1RoomRolloffFactor(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return 0;
	}
	float result_ = (*(FMOD_REVERB_PROPERTIES **)&pointer)->RoomRolloffFactor;
	return (jfloat)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1set_1RoomRolloffFactor(JNIEnv *jenv, jclass jcls, jlong pointer, jfloat jRoomRolloffFactor) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return;
	}
	float RoomRolloffFactor = (float)jRoomRolloffFactor;
	(*(FMOD_REVERB_PROPERTIES **)&pointer)->RoomRolloffFactor = RoomRolloffFactor;
}

JNIEXPORT jfloat JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1get_1Diffusion(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return 0;
	}
	float result_ = (*(FMOD_REVERB_PROPERTIES **)&pointer)->Diffusion;
	return (jfloat)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1set_1Diffusion(JNIEnv *jenv, jclass jcls, jlong pointer, jfloat jDiffusion) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return;
	}
	float Diffusion = (float)jDiffusion;
	(*(FMOD_REVERB_PROPERTIES **)&pointer)->Diffusion = Diffusion;
}

JNIEXPORT jfloat JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1get_1Density(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return 0;
	}
	float result_ = (*(FMOD_REVERB_PROPERTIES **)&pointer)->Density;
	return (jfloat)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1set_1Density(JNIEnv *jenv, jclass jcls, jlong pointer, jfloat jDensity) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return;
	}
	float Density = (float)jDensity;
	(*(FMOD_REVERB_PROPERTIES **)&pointer)->Density = Density;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1get_1Flags(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return 0;
	}
	int result_ = (*(FMOD_REVERB_PROPERTIES **)&pointer)->Flags;
	return (jint)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1REVERB_1PROPERTIES_1set_1Flags(JNIEnv *jenv, jclass jcls, jlong pointer, jint jFlags) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_REVERB_PROPERTIES);
		return;
	}
	int Flags = (int)jFlags;
	(*(FMOD_REVERB_PROPERTIES **)&pointer)->Flags = Flags;
}



