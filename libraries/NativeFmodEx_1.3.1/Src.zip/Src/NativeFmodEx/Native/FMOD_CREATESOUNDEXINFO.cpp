/**
 * 							NativeFmodEx Project
 *
 * Do you want to use FMOD Ex API (www.fmod.org) with the Java language ? I've created NativeFmodEx for you.
 * Copyright � 2005-2006 J�r�me JOUVIE (Jouvieje)
 *
 * Created on 23 feb. 2005
 * @version file v1.0.0
 * @author J�r�me JOUVIE (Jouvieje)
 * 
 * 
 * WANT TO CONTACT ME ?
 * E-mail :
 * 		jerome.jouvie@gmail.com
 * My web sites :
 * 		http://jerome.jouvie.free.fr/
 * 		http://topresult.tomato.co.uk/~jerome/
 * 
 * 
 * INTRODUCTION
 * FMOD Ex is an API (Application Programming Interface) that allow you to use music
 * and creating sound effects with a lot of sort of musics.
 * FMOD is at :
 * 		http://www.fmod.org/
 * The reason of this project is that FMOD Ex can't be used direcly with Java, so I've created
 * this project to do this.
 * 
 * 
 * GNU LESSER GENERAL PUBLIC LICENSE
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of the License,
 * or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA 
 */
#include "Utils.h"
#include "Pointer.h"
#include "fmod.h"
#include "fmod.hpp"
#include "fmod_codec.h"
#include "fmod_dsp.h"
#include "fmod_output.h"
#include "org_jouvieje_FmodEx_Structures_StructureJNI.h"
#include "CallbackManager.h"

JNIEXPORT jlong JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1new(JNIEnv *jenv, jclass jcls) {
	FMOD_CREATESOUNDEXINFO *result_ = new FMOD_CREATESOUNDEXINFO();
	result_->cbsize = sizeof(FMOD_CREATESOUNDEXINFO);
	jlong jresult = 0;
	*(FMOD_CREATESOUNDEXINFO **)&jresult = result_;
	return jresult;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1delete(JNIEnv *jenv, jclass jcls, jlong pointer) {
	delete *(FMOD_CREATESOUNDEXINFO **)&pointer;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1get_1cbsize(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return 0;
	}
	int result_ = (*(FMOD_CREATESOUNDEXINFO **)&pointer)->cbsize;
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1get_1length(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return 0;
	}
	int result_ = (*(FMOD_CREATESOUNDEXINFO **)&pointer)->length;
	return (jint)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1set_1length(JNIEnv *jenv, jclass jcls, jlong pointer, jint jlength) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return;
	}
	int length = (int)jlength;
	(*(FMOD_CREATESOUNDEXINFO **)&pointer)->length = length;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1get_1fileoffset(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return 0;
	}
	int result_ = (*(FMOD_CREATESOUNDEXINFO **)&pointer)->fileoffset;
	return (jint)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1set_1fileoffset(JNIEnv *jenv, jclass jcls, jlong pointer, jint jfileoffset) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return;
	}
	int fileoffset = (int)jfileoffset;
	(*(FMOD_CREATESOUNDEXINFO **)&pointer)->fileoffset = fileoffset;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1get_1numchannels(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return 0;
	}
	int result_ = (*(FMOD_CREATESOUNDEXINFO **)&pointer)->numchannels;
	return (jint)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1set_1numchannels(JNIEnv *jenv, jclass jcls, jlong pointer, jint jnumchannels) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return;
	}
	int numchannels = (int)jnumchannels;
	(*(FMOD_CREATESOUNDEXINFO **)&pointer)->numchannels = numchannels;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1get_1defaultfrequency(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return 0;
	}
	int result_ = (*(FMOD_CREATESOUNDEXINFO **)&pointer)->defaultfrequency;
	return (jint)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1set_1defaultfrequency(JNIEnv *jenv, jclass jcls, jlong pointer, jint jdefaultfrequency) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return;
	}
	int defaultfrequency = (int)jdefaultfrequency;
	(*(FMOD_CREATESOUNDEXINFO **)&pointer)->defaultfrequency = defaultfrequency;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1get_1format(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return 0;
	}
	FMOD_SOUND_FORMAT result_ = (*(FMOD_CREATESOUNDEXINFO **)&pointer)->format;
	return (jint)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1set_1format(JNIEnv *jenv, jclass jcls, jlong pointer, jint jformat) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return;
	}
	int format = (int)jformat;
	(*(FMOD_CREATESOUNDEXINFO **)&pointer)->format = (FMOD_SOUND_FORMAT)format;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1get_1decodebuffersize(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return 0;
	}
	int result_ = (*(FMOD_CREATESOUNDEXINFO **)&pointer)->decodebuffersize;
	return (jint)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1set_1decodebuffersize(JNIEnv *jenv, jclass jcls, jlong pointer, jint jdecodebuffersize) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return;
	}
	int decodebuffersize = (int)jdecodebuffersize;
	(*(FMOD_CREATESOUNDEXINFO **)&pointer)->decodebuffersize = decodebuffersize;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1get_1initialsubsound(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return 0;
	}
	int result_ = (*(FMOD_CREATESOUNDEXINFO **)&pointer)->initialsubsound;
	return (jint)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1set_1initialsubsound(JNIEnv *jenv, jclass jcls, jlong pointer, jint jinitialsubsound) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return;
	}
	int initialsubsound = (int)jinitialsubsound;
	(*(FMOD_CREATESOUNDEXINFO **)&pointer)->initialsubsound = initialsubsound;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1get_1numsubsounds(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return 0;
	}
	int result_ = (*(FMOD_CREATESOUNDEXINFO **)&pointer)->numsubsounds;
	return (jint)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1set_1numsubsounds(JNIEnv *jenv, jclass jcls, jlong pointer, jint jnumsubsounds) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return;
	}
	int numsubsounds = (int)jnumsubsounds;
	(*(FMOD_CREATESOUNDEXINFO **)&pointer)->numsubsounds = numsubsounds;
}

JNIEXPORT jobject JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1get_1inclusionlist(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return 0;
	}
	int *result_ = (int *)((*(FMOD_CREATESOUNDEXINFO **)&pointer)->inclusionlist);
	jobject jresult = 0;
	if(result_) {
		jresult = jenv->NewDirectByteBuffer(result_, (*(FMOD_CREATESOUNDEXINFO **)&pointer)->inclusionlistnum*sizeof(int));
	}
	return jresult;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1set_1inclusionlist(JNIEnv *jenv, jclass jcls, jlong pointer, jobject jinclusionlist, jlong jinclusionlist_) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return;
	}
	int *inclusionlist = 0;
	if(jinclusionlist) {
		inclusionlist = (int *)((char *)jenv->GetDirectBufferAddress(jenv->NewGlobalRef(jinclusionlist))+jinclusionlist_);
	}
	(*(FMOD_CREATESOUNDEXINFO **)&pointer)->inclusionlist = inclusionlist;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1get_1inclusionlistnum(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return 0;
	}
	int result_ = (*(FMOD_CREATESOUNDEXINFO **)&pointer)->inclusionlistnum;
	return (jint)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1set_1inclusionlistnum(JNIEnv *jenv, jclass jcls, jlong pointer, jint jinclusionlistnum) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return;
	}
	int inclusionlistnum = (int)jinclusionlistnum;
	(*(FMOD_CREATESOUNDEXINFO **)&pointer)->inclusionlistnum = inclusionlistnum;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1set_1pcmreadcallback(JNIEnv *jenv, jclass jcls, jlong pointer, jboolean jpcmreadcallback) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return;
	}
	(*(FMOD_CREATESOUNDEXINFO **)&pointer)->pcmreadcallback = ((jpcmreadcallback == 0) ? NULL : FMOD_SOUND_PCMREADCALLBACK_BRIDGE);
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1set_1pcmsetposcallback(JNIEnv *jenv, jclass jcls, jlong pointer, jboolean jpcmsetposcallback) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return;
	}
	(*(FMOD_CREATESOUNDEXINFO **)&pointer)->pcmsetposcallback = ((jpcmsetposcallback == 0) ? NULL : FMOD_SOUND_PCMSETPOSCALLBACK_BRIDGE);
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1set_1nonblockcallback(JNIEnv *jenv, jclass jcls, jlong pointer, jboolean jnonblockcallback) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return;
	}
	(*(FMOD_CREATESOUNDEXINFO **)&pointer)->nonblockcallback = ((jnonblockcallback == 0) ? NULL : FMOD_SOUND_NONBLOCKCALLBACK_BRIDGE);
}

JNIEXPORT jstring JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1get_1dlsname(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return 0;
	}
	char *result_ = (char *)((*(FMOD_CREATESOUNDEXINFO **)&pointer)->dlsname);
	jstring jresult = 0;
	if(result_) {
		jresult = jenv->NewStringUTF(result_);
	}
	return jresult;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1set_1dlsname(JNIEnv *jenv, jclass jcls, jlong pointer, jbyteArray jdlsname) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return;
	}
	char *dlsname = 0;
	if(jdlsname) {
		dlsname = getByteArrayElements(jenv, jdlsname);
		(*(FMOD_CREATESOUNDEXINFO **)&pointer)->dlsname = dlsname;
	}
	else {
		(*(FMOD_CREATESOUNDEXINFO **)&pointer)->dlsname = (char *)0;
	}
}

JNIEXPORT jstring JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1get_1encryptionkey(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return 0;
	}
	char *result_ = (char *)((*(FMOD_CREATESOUNDEXINFO **)&pointer)->encryptionkey);
	jstring jresult = 0;
	if(result_) {
		jresult = jenv->NewStringUTF(result_);
	}
	return jresult;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1set_1encryptionkey(JNIEnv *jenv, jclass jcls, jlong pointer, jbyteArray jencryptionkey) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return;
	}
	char *encryptionkey = 0;
	if(jencryptionkey) {
		encryptionkey = getByteArrayElements(jenv, jencryptionkey);
		(*(FMOD_CREATESOUNDEXINFO **)&pointer)->encryptionkey = encryptionkey;
	}
	else {
		(*(FMOD_CREATESOUNDEXINFO **)&pointer)->encryptionkey = (char *)0;
	}
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1get_1maxpolyphony(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return 0;
	}
	int result_ = (*(FMOD_CREATESOUNDEXINFO **)&pointer)->maxpolyphony;
	return (jint)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1set_1maxpolyphony(JNIEnv *jenv, jclass jcls, jlong pointer, jint jmaxpolyphony) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return;
	}
	int maxpolyphony = (int)jmaxpolyphony;
	(*(FMOD_CREATESOUNDEXINFO **)&pointer)->maxpolyphony = maxpolyphony;
}

JNIEXPORT jlong JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1get_1userdata(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return 0;
	}
	jlong jresult;
	*(void **)&jresult = (*(FMOD_CREATESOUNDEXINFO **)&pointer)->userdata;
	return jresult;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1set_1userdata(JNIEnv *jenv, jclass jcls, jlong pointer, jlong juserdata) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return;
	}
	(*(FMOD_CREATESOUNDEXINFO **)&pointer)->userdata = *(void **)&juserdata;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1get_1suggestedsoundtype(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return 0;
	}
	FMOD_SOUND_TYPE result_ = (*(FMOD_CREATESOUNDEXINFO **)&pointer)->suggestedsoundtype;
	return (jint)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CREATESOUNDEXINFO_1set_1suggestedsoundtype(JNIEnv *jenv, jclass jcls, jlong pointer, jint jsuggestedsoundtype) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CREATESOUNDEXINFO);
		return;
	}
	int suggestedsoundtype = (int)jsuggestedsoundtype;
	(*(FMOD_CREATESOUNDEXINFO **)&pointer)->suggestedsoundtype = (FMOD_SOUND_TYPE)suggestedsoundtype;
}



