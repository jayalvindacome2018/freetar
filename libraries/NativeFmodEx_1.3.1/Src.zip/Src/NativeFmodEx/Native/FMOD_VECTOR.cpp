/**
 * 							NativeFmodEx Project
 *
 * Do you want to use FMOD Ex API (www.fmod.org) with the Java language ? I've created NativeFmodEx for you.
 * Copyright � 2005-2006 J�r�me JOUVIE (Jouvieje)
 *
 * Created on 23 feb. 2005
 * @version file v1.0.0
 * @author J�r�me JOUVIE (Jouvieje)
 * 
 * 
 * WANT TO CONTACT ME ?
 * E-mail :
 * 		jerome.jouvie@gmail.com
 * My web sites :
 * 		http://jerome.jouvie.free.fr/
 * 		http://topresult.tomato.co.uk/~jerome/
 * 
 * 
 * INTRODUCTION
 * FMOD Ex is an API (Application Programming Interface) that allow you to use music
 * and creating sound effects with a lot of sort of musics.
 * FMOD is at :
 * 		http://www.fmod.org/
 * The reason of this project is that FMOD Ex can't be used direcly with Java, so I've created
 * this project to do this.
 * 
 * 
 * GNU LESSER GENERAL PUBLIC LICENSE
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of the License,
 * or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA 
 */
#include "Utils.h"
#include "Pointer.h"
#include "fmod.h"
#include "fmod.hpp"
#include "fmod_codec.h"
#include "fmod_dsp.h"
#include "fmod_output.h"
#include "org_jouvieje_FmodEx_Structures_StructureJNI.h"
#include "CallbackManager.h"

JNIEXPORT jlong JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1VECTOR_1create(JNIEnv *jenv, jclass jcls, jfloat x, jfloat y, jfloat z) {
	FMOD_VECTOR *result_ = new FMOD_VECTOR();
	result_->x = (float)x;
	result_->y = (float)y;
	result_->z = (float)z;
	jlong jresult = 0;
	*(FMOD_VECTOR **)&jresult = result_;
	return jresult;
}

JNIEXPORT jlong JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1VECTOR_1new(JNIEnv *jenv, jclass jcls) {
	FMOD_VECTOR *result_ = new FMOD_VECTOR();
	jlong jresult = 0;
	*(FMOD_VECTOR **)&jresult = result_;
	return jresult;
}

JNIEXPORT jlong JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1VECTOR_1newArray(JNIEnv *jenv, jclass jcls, jint length) {
	FMOD_VECTOR *array = new FMOD_VECTOR[(int)length];
	jlong jresult = 0;
	*(FMOD_VECTOR **)&jresult = array;
	return jresult;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1VECTOR_1SIZEOF(JNIEnv *jenv, jclass jcls) {
	return (jint)sizeof(FMOD_VECTOR);
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1VECTOR_1delete(JNIEnv *jenv, jclass jcls, jlong pointer) {
	delete *(FMOD_VECTOR **)&pointer;
}

JNIEXPORT jfloat JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1VECTOR_1get_1x(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_VECTOR);
		return 0;
	}
	float result_ = (*(FMOD_VECTOR **)&pointer)->x;
	return (jfloat)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1VECTOR_1set_1x(JNIEnv *jenv, jclass jcls, jlong pointer, jfloat jx) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_VECTOR);
		return;
	}
	float x = (float)jx;
	(*(FMOD_VECTOR **)&pointer)->x = x;
}

JNIEXPORT jfloat JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1VECTOR_1get_1y(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_VECTOR);
		return 0;
	}
	float result_ = (*(FMOD_VECTOR **)&pointer)->y;
	return (jfloat)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1VECTOR_1set_1y(JNIEnv *jenv, jclass jcls, jlong pointer, jfloat jy) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_VECTOR);
		return;
	}
	float y = (float)jy;
	(*(FMOD_VECTOR **)&pointer)->y = y;
}

JNIEXPORT jfloat JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1VECTOR_1get_1z(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_VECTOR);
		return 0;
	}
	float result_ = (*(FMOD_VECTOR **)&pointer)->z;
	return (jfloat)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1VECTOR_1set_1z(JNIEnv *jenv, jclass jcls, jlong pointer, jfloat jz) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_VECTOR);
		return;
	}
	float z = (float)jz;
	(*(FMOD_VECTOR **)&pointer)->z = z;
}


JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1VECTOR_1set_1xyz__JJ(JNIEnv *jenv, jclass jcls, jlong pointer, jlong vector) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_VECTOR);
		return;
	}
	if(vector) {
		FMOD_VECTOR *pointer_ = (*(FMOD_VECTOR **)&pointer);
		FMOD_VECTOR *vector_ = (*(FMOD_VECTOR **)&vector);
		
		pointer_->x = vector_->x;
		pointer_->y = vector_->y;
		pointer_->z = vector_->z;
	}
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1VECTOR_1set_1xyz__JFFF(JNIEnv *jenv, jclass jcls, jlong pointer, jfloat x, jfloat y, jfloat z) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_VECTOR);
		return;
	}
	FMOD_VECTOR *pointer_ = (*(FMOD_VECTOR **)&pointer);
	pointer_->x = (float)x;
	pointer_->y = (float)y;
	pointer_->z = (float)z;
}


