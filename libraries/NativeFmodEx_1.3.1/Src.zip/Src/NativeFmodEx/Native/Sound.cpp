/**
 * 							NativeFmodEx Project
 *
 * Do you want to use FMOD Ex API (www.fmod.org) with the Java language ? I've created NativeFmodEx for you.
 * Copyright � 2005-2006 J�r�me JOUVIE (Jouvieje)
 *
 * Created on 23 feb. 2005
 * @version file v1.0.0
 * @author J�r�me JOUVIE (Jouvieje)
 * 
 * 
 * WANT TO CONTACT ME ?
 * E-mail :
 * 		jerome.jouvie@gmail.com
 * My web sites :
 * 		http://jerome.jouvie.free.fr/
 * 		http://topresult.tomato.co.uk/~jerome/
 * 
 * 
 * INTRODUCTION
 * FMOD Ex is an API (Application Programming Interface) that allow you to use music
 * and creating sound effects with a lot of sort of musics.
 * FMOD is at :
 * 		http://www.fmod.org/
 * The reason of this project is that FMOD Ex can't be used direcly with Java, so I've created
 * this project to do this.
 * 
 * 
 * GNU LESSER GENERAL PUBLIC LICENSE
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of the License,
 * or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA 
 */
#include "Utils.h"
#include "Pointer.h"
#include "fmod.h"
#include "fmod.hpp"
#include "fmod_codec.h"
#include "fmod_dsp.h"
#include "fmod_output.h"
#include "org_jouvieje_FmodEx_FmodExJNI.h"
#include "CallbackManager.h"

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1release(JNIEnv *jenv, jclass jcls, jlong jPointer) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->release();

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1getSystemObject(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jsystem) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	FMOD::System *system;

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->getSystemObject(&system);

	if(system && jsystem) {
		jlong newAddress = 0;
		*(FMOD::System **)&newAddress = system;
		setPointerAddress(jenv, jsystem, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1lock(JNIEnv *jenv, jclass jcls, jlong jPointer, jint joffset, jint jlength, jobjectArray jptr1, jobjectArray jptr2, jobject jlen1, jlong jlen1_, jobject jlen2, jlong jlen2_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	int offset = (int)joffset;
	int length = (int)jlength;
	void *ptr1;
	void *ptr2;
	unsigned int *len1 = 0;
	if(jlen1) {
		len1 = (unsigned int *)((char *)jenv->GetDirectBufferAddress(jlen1)+jlen1_);
	}
	unsigned int *len2 = 0;
	if(jlen2) {
		len2 = (unsigned int *)((char *)jenv->GetDirectBufferAddress(jlen2)+jlen2_);
	}

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->lock(offset, length, &ptr1, &ptr2, len1, len2);

	if(ptr1 && jptr1 && jenv->GetArrayLength(jptr1) >= 1) {
		jenv->SetObjectArrayElement(jptr1, 0, jenv->NewDirectByteBuffer(ptr1, *len1));
	}
	if(ptr2 && jptr2 && jenv->GetArrayLength(jptr2) >= 1) {
		jenv->SetObjectArrayElement(jptr2, 0, jenv->NewDirectByteBuffer(ptr2, *len2));
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1unlock(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jptr1, jlong jptr1_, jobject jptr2, jlong jptr2_, jint jlen1, jint jlen2) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	void *ptr1 = 0;
	if(jptr1) {
		ptr1 = (void *)((char *)jenv->GetDirectBufferAddress(jptr1)+jptr1_);
	}
	void *ptr2 = 0;
	if(jptr2) {
		ptr2 = (void *)((char *)jenv->GetDirectBufferAddress(jptr2)+jptr2_);
	}
	int len1 = (int)jlen1;
	int len2 = (int)jlen2;

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->unlock(ptr1, ptr2, len1, len2);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1setDefaults(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jfrequency, jfloat jvolume, jfloat jpan, jint jpriority) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	float frequency = (float)jfrequency;
	float volume = (float)jvolume;
	float pan = (float)jpan;
	int priority = (int)jpriority;

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->setDefaults(frequency, volume, pan, priority);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1getDefaults(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jfrequency, jlong jfrequency_, jobject jvolume, jlong jvolume_, jobject jpan, jlong jpan_, jobject jpriority, jlong jpriority_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	float *frequency = 0;
	if(jfrequency) {
		frequency = (float *)((char *)jenv->GetDirectBufferAddress(jfrequency)+jfrequency_);
	}
	float *volume = 0;
	if(jvolume) {
		volume = (float *)((char *)jenv->GetDirectBufferAddress(jvolume)+jvolume_);
	}
	float *pan = 0;
	if(jpan) {
		pan = (float *)((char *)jenv->GetDirectBufferAddress(jpan)+jpan_);
	}
	int *priority = 0;
	if(jpriority) {
		priority = (int *)((char *)jenv->GetDirectBufferAddress(jpriority)+jpriority_);
	}

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->getDefaults(frequency, volume, pan, priority);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1setVariations(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jfrequencyvar, jfloat jvolumevar, jfloat jpanvar) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	float frequencyvar = (float)jfrequencyvar;
	float volumevar = (float)jvolumevar;
	float panvar = (float)jpanvar;

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->setVariations(frequencyvar, volumevar, panvar);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1getVariations(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jfrequencyvar, jlong jfrequencyvar_, jobject jvolumevar, jlong jvolumevar_, jobject jpanvar, jlong jpanvar_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	float *frequencyvar = 0;
	if(jfrequencyvar) {
		frequencyvar = (float *)((char *)jenv->GetDirectBufferAddress(jfrequencyvar)+jfrequencyvar_);
	}
	float *volumevar = 0;
	if(jvolumevar) {
		volumevar = (float *)((char *)jenv->GetDirectBufferAddress(jvolumevar)+jvolumevar_);
	}
	float *panvar = 0;
	if(jpanvar) {
		panvar = (float *)((char *)jenv->GetDirectBufferAddress(jpanvar)+jpanvar_);
	}

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->getVariations(frequencyvar, volumevar, panvar);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1set3DMinMaxDistance(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jmin, jfloat jmax) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	float min = (float)jmin;
	float max = (float)jmax;

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->set3DMinMaxDistance(min, max);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1get3DMinMaxDistance(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jmin, jlong jmin_, jobject jmax, jlong jmax_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	float *min = 0;
	if(jmin) {
		min = (float *)((char *)jenv->GetDirectBufferAddress(jmin)+jmin_);
	}
	float *max = 0;
	if(jmax) {
		max = (float *)((char *)jenv->GetDirectBufferAddress(jmax)+jmax_);
	}

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->get3DMinMaxDistance(min, max);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1set3DConeSettings(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jinsideconeangle, jfloat joutsideconeangle, jfloat joutsidevolume) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	float insideconeangle = (float)jinsideconeangle;
	float outsideconeangle = (float)joutsideconeangle;
	float outsidevolume = (float)joutsidevolume;

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->set3DConeSettings(insideconeangle, outsideconeangle, outsidevolume);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1get3DConeSettings(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jinsideconeangle, jlong jinsideconeangle_, jobject joutsideconeangle, jlong joutsideconeangle_, jobject joutsidevolume, jlong joutsidevolume_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	float *insideconeangle = 0;
	if(jinsideconeangle) {
		insideconeangle = (float *)((char *)jenv->GetDirectBufferAddress(jinsideconeangle)+jinsideconeangle_);
	}
	float *outsideconeangle = 0;
	if(joutsideconeangle) {
		outsideconeangle = (float *)((char *)jenv->GetDirectBufferAddress(joutsideconeangle)+joutsideconeangle_);
	}
	float *outsidevolume = 0;
	if(joutsidevolume) {
		outsidevolume = (float *)((char *)jenv->GetDirectBufferAddress(joutsidevolume)+joutsidevolume_);
	}

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->get3DConeSettings(insideconeangle, outsideconeangle, outsidevolume);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1set3DCustomRolloff(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jpoints, jint jnumpoints) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	FMOD_VECTOR *points = *(FMOD_VECTOR **)&jpoints;
	int numpoints = (int)jnumpoints;

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->set3DCustomRolloff(points, numpoints);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1get3DCustomRolloff(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jpoints, jobject jnumpoints, jlong jnumpoints_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	FMOD_VECTOR *points;
	int *numpoints = 0;
	if(jnumpoints) {
		numpoints = (int *)((char *)jenv->GetDirectBufferAddress(jnumpoints)+jnumpoints_);
	}

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->get3DCustomRolloff(&points, numpoints);

	if(points && jpoints) {
		jlong newAddress = 0;
		*(FMOD_VECTOR **)&newAddress = points;
		setPointerAddress(jenv, jpoints, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1setSubSound(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jlong jsubsound) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	int index = (int)jindex;
	FMOD::Sound *subsound = *(FMOD::Sound **)&jsubsound;

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->setSubSound(index, subsound);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1getSubSound(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jobject jsubsound) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	int index = (int)jindex;
	FMOD::Sound *subsound;

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->getSubSound(index, &subsound);

	if(subsound && jsubsound) {
		jlong newAddress = 0;
		*(FMOD::Sound **)&newAddress = subsound;
		setPointerAddress(jenv, jsubsound, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1setSubSoundSentence(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jsubsoundlist, jlong jsubsoundlist_, jint jnumsubsounds) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	int *subsoundlist = 0;
	if(jsubsoundlist) {
		subsoundlist = (int *)((char *)jenv->GetDirectBufferAddress(jsubsoundlist)+jsubsoundlist_);
	}
	int numsubsounds = (int)jnumsubsounds;

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->setSubSoundSentence(subsoundlist, numsubsounds);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1getName(JNIEnv *jenv, jclass jcls, jlong jPointer, 	jobject jname, jlong jname_, jint jnamelen) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	char *name = 0;
	if(jname) {
		name = (char *)jenv->GetDirectBufferAddress(jname)+jname_;
	}
	int namelen = (int)jnamelen;

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->getName(name, namelen);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1getLength(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jlength, jlong jlength_, jint jlengthtype) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	unsigned int *length = 0;
	if(jlength) {
		length = (unsigned int *)((char *)jenv->GetDirectBufferAddress(jlength)+jlength_);
	}
	FMOD_TIMEUNIT lengthtype = (FMOD_TIMEUNIT)jlengthtype;

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->getLength(length, lengthtype);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1getFormat(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jtypePointer, jobject jformatPointer, jobject jchannels, jlong jchannels_, jobject jbits, jlong jbits_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	FMOD_SOUND_TYPE type;
	FMOD_SOUND_FORMAT format;
	int *channels = 0;
	if(jchannels) {
		channels = (int *)((char *)jenv->GetDirectBufferAddress(jchannels)+jchannels_);
	}
	int *bits = 0;
	if(jbits) {
		bits = (int *)((char *)jenv->GetDirectBufferAddress(jbits)+jbits_);
	}

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->getFormat(&type, &format, channels, bits);

	if(jtypePointer) {
		int *typePointer = (int *)jenv->GetDirectBufferAddress(jtypePointer);
		typePointer[0] = type;
	}
	if(jformatPointer) {
		int *formatPointer = (int *)jenv->GetDirectBufferAddress(jformatPointer);
		formatPointer[0] = format;
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1getNumSubSounds(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jnumsubsounds, jlong jnumsubsounds_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	int *numsubsounds = 0;
	if(jnumsubsounds) {
		numsubsounds = (int *)((char *)jenv->GetDirectBufferAddress(jnumsubsounds)+jnumsubsounds_);
	}

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->getNumSubSounds(numsubsounds);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1getNumTags(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jnumtags, jlong jnumtags_, jobject jnumtagsupdated, jlong jnumtagsupdated_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	int *numtags = 0;
	if(jnumtags) {
		numtags = (int *)((char *)jenv->GetDirectBufferAddress(jnumtags)+jnumtags_);
	}
	int *numtagsupdated = 0;
	if(jnumtagsupdated) {
		numtagsupdated = (int *)((char *)jenv->GetDirectBufferAddress(jnumtagsupdated)+jnumtagsupdated_);
	}

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->getNumTags(numtags, numtagsupdated);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1getTag(JNIEnv *jenv, jclass jcls, jlong jPointer, jbyteArray jname, jint jindex, jlong jtag) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	char *name = getByteArrayElements(jenv, jname);
	int index = (int)jindex;
	FMOD_TAG *tag = *(FMOD_TAG **)&jtag;

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->getTag(name, index, tag);

	releaseByteArrayElements(jenv, jname, (const char *)name);
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1getOpenState(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jopenstatePointer, jobject jpercentbuffered, jlong jpercentbuffered_, jobject jstarving, jlong jstarving_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	FMOD_OPENSTATE openstate;
	unsigned int *percentbuffered = 0;
	if(jpercentbuffered) {
		percentbuffered = (unsigned int *)((char *)jenv->GetDirectBufferAddress(jpercentbuffered)+jpercentbuffered_);
	}
	bool *starving =  0;
	if(jstarving) {
		starving = (bool *)((char *)jenv->GetDirectBufferAddress(jstarving)+jstarving_);
	}

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->getOpenState(&openstate, percentbuffered, starving);

	if(jopenstatePointer) {
		int *openstatePointer = (int *)jenv->GetDirectBufferAddress(jopenstatePointer);
		openstatePointer[0] = openstate;
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1readData(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jbuffer, jlong jbuffer_, jint jlenbytes, jobject jread, jlong jread_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	void *buffer = 0;
	if(jbuffer) {
		buffer = (void *)((char *)jenv->GetDirectBufferAddress(jbuffer)+jbuffer_);
	}
	int lenbytes = (int)jlenbytes;
	unsigned int *read = 0;
	if(jread) {
		read = (unsigned int *)((char *)jenv->GetDirectBufferAddress(jread)+jread_);
	}

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->readData(buffer, lenbytes, read);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1seekData(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jpcm) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	int pcm = (int)jpcm;

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->seekData(pcm);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1getNumSyncPoints(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jnumsyncpoints, jlong jnumsyncpoints_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	int *numsyncpoints = 0;
	if(jnumsyncpoints) {
		numsyncpoints = (int *)((char *)jenv->GetDirectBufferAddress(jnumsyncpoints)+jnumsyncpoints_);
	}

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->getNumSyncPoints(numsyncpoints);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1getSyncPoint(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jobject jpoint) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	int index = (int)jindex;
	FMOD_SYNCPOINT *point;

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->getSyncPoint(index, &point);

	if(point && jpoint) {
		jlong newAddress = 0;
		*(FMOD_SYNCPOINT **)&newAddress = point;
		setPointerAddress(jenv, jpoint, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1getSyncPointInfo(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jpoint, 	jobject jname, jlong jname_, jint jnamelen, jobject joffset, jlong joffset_, jint joffsettype) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	FMOD_SYNCPOINT *point = *(FMOD_SYNCPOINT **)&jpoint;
	char *name = 0;
	if(jname) {
		name = (char *)jenv->GetDirectBufferAddress(jname)+jname_;
	}
	int namelen = (int)jnamelen;
	unsigned int *offset = 0;
	if(joffset) {
		offset = (unsigned int *)((char *)jenv->GetDirectBufferAddress(joffset)+joffset_);
	}
	FMOD_TIMEUNIT offsettype = (FMOD_TIMEUNIT)joffsettype;

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->getSyncPointInfo(point, name, namelen, offset, offsettype);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1addSyncPoint(JNIEnv *jenv, jclass jcls, jlong jPointer, jint joffset, jint joffsettype, jbyteArray jname, jobject jpoint) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	int offset = (int)joffset;
	FMOD_TIMEUNIT offsettype = (FMOD_TIMEUNIT)joffsettype;
	char *name = getByteArrayElements(jenv, jname);
	FMOD_SYNCPOINT *point;

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->addSyncPoint(offset, offsettype, name, &point);

	releaseByteArrayElements(jenv, jname, (const char *)name);
	if(point && jpoint) {
		jlong newAddress = 0;
		*(FMOD_SYNCPOINT **)&newAddress = point;
		setPointerAddress(jenv, jpoint, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1deleteSyncPoint(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jpoint) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	FMOD_SYNCPOINT *point = *(FMOD_SYNCPOINT **)&jpoint;

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->deleteSyncPoint(point);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1setMode(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jmode) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	FMOD_MODE mode = (FMOD_MODE)jmode;

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->setMode(mode);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1getMode(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jmode, jlong jmode_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	FMOD_MODE *mode = 0;
	if(jmode) {
		mode = (FMOD_MODE *)(int *)((char *)jenv->GetDirectBufferAddress(jmode)+jmode_);
	}

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->getMode(mode);

	jobject jresult = 0;
	if(result_) {
		jresult = jenv->NewDirectByteBuffer((FMOD_MODE *)(int *)result_, (jlong)-1);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1setLoopCount(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jloopcount) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	int loopcount = (int)jloopcount;

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->setLoopCount(loopcount);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1getLoopCount(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jloopcount, jlong jloopcount_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	int *loopcount = 0;
	if(jloopcount) {
		loopcount = (int *)((char *)jenv->GetDirectBufferAddress(jloopcount)+jloopcount_);
	}

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->getLoopCount(loopcount);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1setLoopPoints(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jloopstart, jint jloopstarttype, jint jloopend, jint jloopendtype) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	int loopstart = (int)jloopstart;
	FMOD_TIMEUNIT loopstarttype = (FMOD_TIMEUNIT)jloopstarttype;
	int loopend = (int)jloopend;
	FMOD_TIMEUNIT loopendtype = (FMOD_TIMEUNIT)jloopendtype;

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->setLoopPoints(loopstart, loopstarttype, loopend, loopendtype);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1getLoopPoints(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jloopstart, jlong jloopstart_, jint jloopstarttype, jobject jloopend, jlong jloopend_, jint jloopendtype) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	unsigned int *loopstart = 0;
	if(jloopstart) {
		loopstart = (unsigned int *)((char *)jenv->GetDirectBufferAddress(jloopstart)+jloopstart_);
	}
	FMOD_TIMEUNIT loopstarttype = (FMOD_TIMEUNIT)jloopstarttype;
	unsigned int *loopend = 0;
	if(jloopend) {
		loopend = (unsigned int *)((char *)jenv->GetDirectBufferAddress(jloopend)+jloopend_);
	}
	FMOD_TIMEUNIT loopendtype = (FMOD_TIMEUNIT)jloopendtype;

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->getLoopPoints(loopstart, loopstarttype, loopend, loopendtype);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1setUserData(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong juserdata) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	void *userdata = *(void **)&juserdata;

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->setUserData(userdata);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Sound_1getUserData(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject juserdata) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SOUND);
		return 0;
	}
	void *userdata;

	FMOD_RESULT result_ = (*(FMOD::Sound **)&jPointer)->getUserData(&userdata);

	if(userdata && juserdata) {
		jlong newAddress;
		*(void **)&newAddress = userdata;
		setPointerAddress(jenv, juserdata, newAddress);
	}
	return (jint)result_;
}


