/**
 * 							NativeFmodEx Project
 *
 * Do you want to use FMOD Ex API (www.fmod.org) with the Java language ? I've created NativeFmodEx for you.
 * Copyright � 2005-2006 J�r�me JOUVIE (Jouvieje)
 *
 * Created on 23 feb. 2005
 * @version file v1.0.0
 * @author J�r�me JOUVIE (Jouvieje)
 * 
 * 
 * WANT TO CONTACT ME ?
 * E-mail :
 * 		jerome.jouvie@gmail.com
 * My web sites :
 * 		http://jerome.jouvie.free.fr/
 * 		http://topresult.tomato.co.uk/~jerome/
 * 
 * 
 * INTRODUCTION
 * FMOD Ex is an API (Application Programming Interface) that allow you to use music
 * and creating sound effects with a lot of sort of musics.
 * FMOD is at :
 * 		http://www.fmod.org/
 * The reason of this project is that FMOD Ex can't be used direcly with Java, so I've created
 * this project to do this.
 * 
 * 
 * GNU LESSER GENERAL PUBLIC LICENSE
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of the License,
 * or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA 
 */
#include "Utils.h"
#include "Pointer.h"
#include "fmod.h"
#include "fmod.hpp"
#include "fmod_codec.h"
#include "fmod_dsp.h"
#include "fmod_output.h"
#include "org_jouvieje_FmodEx_FmodExJNI.h"
#include "CallbackManager.h"

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1release(JNIEnv *jenv, jclass jcls, jlong jPointer) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->release();

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1getSystemObject(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jsystem) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	FMOD::System *system;

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->getSystemObject(&system);

	if(system && jsystem) {
		jlong newAddress = 0;
		*(FMOD::System **)&newAddress = system;
		setPointerAddress(jenv, jsystem, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1addInput(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jtarget) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	FMOD::DSP *target = *(FMOD::DSP **)&jtarget;

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->addInput(target);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1disconnectFrom(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jtarget) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	FMOD::DSP *target = *(FMOD::DSP **)&jtarget;

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->disconnectFrom(target);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1remove(JNIEnv *jenv, jclass jcls, jlong jPointer) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->remove();

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1getNumInputs(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jnuminputs, jlong jnuminputs_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	int *numinputs = 0;
	if(jnuminputs) {
		numinputs = (int *)((char *)jenv->GetDirectBufferAddress(jnuminputs)+jnuminputs_);
	}

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->getNumInputs(numinputs);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1getNumOutputs(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jnumoutputs, jlong jnumoutputs_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	int *numoutputs = 0;
	if(jnumoutputs) {
		numoutputs = (int *)((char *)jenv->GetDirectBufferAddress(jnumoutputs)+jnumoutputs_);
	}

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->getNumOutputs(numoutputs);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1getInput(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jobject jinput) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	int index = (int)jindex;
	FMOD::DSP *input;

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->getInput(index, &input);

	if(input && jinput) {
		jlong newAddress = 0;
		*(FMOD::DSP **)&newAddress = input;
		setPointerAddress(jenv, jinput, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1getOutput(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jobject joutput) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	int index = (int)jindex;
	FMOD::DSP *output;

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->getOutput(index, &output);

	if(output && joutput) {
		jlong newAddress = 0;
		*(FMOD::DSP **)&newAddress = output;
		setPointerAddress(jenv, joutput, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1setInputMix(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jfloat jvolume) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	int index = (int)jindex;
	float volume = (float)jvolume;

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->setInputMix(index, volume);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1getInputMix(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jobject jvolume, jlong jvolume_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	int index = (int)jindex;
	float *volume = 0;
	if(jvolume) {
		volume = (float *)((char *)jenv->GetDirectBufferAddress(jvolume)+jvolume_);
	}

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->getInputMix(index, volume);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1setInputLevels(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jint jspeaker, jobject jlevels, jlong jlevels_, jint jnumlevels) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	int index = (int)jindex;
	FMOD_SPEAKER speaker = (FMOD_SPEAKER)jspeaker;
	float *levels = 0;
	if(jlevels) {
		levels = (float *)((char *)jenv->GetDirectBufferAddress(jlevels)+jlevels_);
	}
	int numlevels = (int)jnumlevels;

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->setInputLevels(index, speaker, levels, numlevels);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1getInputLevels(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jint jspeaker, jobject jlevels, jlong jlevels_, jint jnumlevels) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	int index = (int)jindex;
	FMOD_SPEAKER speaker = (FMOD_SPEAKER)jspeaker;
	float *levels = 0;
	if(jlevels) {
		levels = (float *)((char *)jenv->GetDirectBufferAddress(jlevels)+jlevels_);
	}
	int numlevels = (int)jnumlevels;

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->getInputLevels(index, speaker, levels, numlevels);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1setOutputMix(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jfloat jvolume) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	int index = (int)jindex;
	float volume = (float)jvolume;

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->setOutputMix(index, volume);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1getOutputMix(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jobject jvolume, jlong jvolume_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	int index = (int)jindex;
	float *volume = 0;
	if(jvolume) {
		volume = (float *)((char *)jenv->GetDirectBufferAddress(jvolume)+jvolume_);
	}

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->getOutputMix(index, volume);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1setOutputLevels(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jint jspeaker, jobject jlevels, jlong jlevels_, jint jnumlevels) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	int index = (int)jindex;
	FMOD_SPEAKER speaker = (FMOD_SPEAKER)jspeaker;
	float *levels = 0;
	if(jlevels) {
		levels = (float *)((char *)jenv->GetDirectBufferAddress(jlevels)+jlevels_);
	}
	int numlevels = (int)jnumlevels;

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->setOutputLevels(index, speaker, levels, numlevels);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1getOutputLevels(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jint jspeaker, jobject jlevels, jlong jlevels_, jint jnumlevels) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	int index = (int)jindex;
	FMOD_SPEAKER speaker = (FMOD_SPEAKER)jspeaker;
	float *levels = 0;
	if(jlevels) {
		levels = (float *)((char *)jenv->GetDirectBufferAddress(jlevels)+jlevels_);
	}
	int numlevels = (int)jnumlevels;

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->getOutputLevels(index, speaker, levels, numlevels);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1setActive(JNIEnv *jenv, jclass jcls, jlong jPointer, jboolean jactive) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	bool active = (bool)(jactive != 0);

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->setActive(active);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1getActive(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jactive, jlong jactive_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	bool *active =  0;
	if(jactive) {
		active = (bool *)((char *)jenv->GetDirectBufferAddress(jactive)+jactive_);
	}

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->getActive(active);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1setBypass(JNIEnv *jenv, jclass jcls, jlong jPointer, jboolean jbypass) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	bool bypass = (bool)(jbypass != 0);

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->setBypass(bypass);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1getBypass(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jbypass, jlong jbypass_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	bool *bypass =  0;
	if(jbypass) {
		bypass = (bool *)((char *)jenv->GetDirectBufferAddress(jbypass)+jbypass_);
	}

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->getBypass(bypass);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1reset(JNIEnv *jenv, jclass jcls, jlong jPointer) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->reset();

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1setParameter(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jfloat jvalue) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	int index = (int)jindex;
	float value = (float)jvalue;

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->setParameter(index, value);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1getParameter(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jobject jvalue, jlong jvalue_, 	jobject jvaluestr, jlong jvaluestr_, jint jvaluestrlen) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	int index = (int)jindex;
	float *value = 0;
	if(jvalue) {
		value = (float *)((char *)jenv->GetDirectBufferAddress(jvalue)+jvalue_);
	}
	char *valuestr = 0;
	if(jvaluestr) {
		valuestr = (char *)jenv->GetDirectBufferAddress(jvaluestr)+jvaluestr_;
	}
	int valuestrlen = (int)jvaluestrlen;

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->getParameter(index, value, valuestr, valuestrlen);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1getNumParameters(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jnumparams, jlong jnumparams_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	int *numparams = 0;
	if(jnumparams) {
		numparams = (int *)((char *)jenv->GetDirectBufferAddress(jnumparams)+jnumparams_);
	}

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->getNumParameters(numparams);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1getParameterInfo(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, 	jobject jname, jlong jname_, 	jobject jlabel, jlong jlabel_, 	jobject jdescription, jlong jdescription_, jint jdescriptionlen, jobject jmin, jlong jmin_, jobject jmax, jlong jmax_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	int index = (int)jindex;
	char *name = 0;
	if(jname) {
		name = (char *)jenv->GetDirectBufferAddress(jname)+jname_;
	}
	char *label = 0;
	if(jlabel) {
		label = (char *)jenv->GetDirectBufferAddress(jlabel)+jlabel_;
	}
	char *description = 0;
	if(jdescription) {
		description = (char *)jenv->GetDirectBufferAddress(jdescription)+jdescription_;
	}
	int descriptionlen = (int)jdescriptionlen;
	float *min = 0;
	if(jmin) {
		min = (float *)((char *)jenv->GetDirectBufferAddress(jmin)+jmin_);
	}
	float *max = 0;
	if(jmax) {
		max = (float *)((char *)jenv->GetDirectBufferAddress(jmax)+jmax_);
	}

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->getParameterInfo(index, name, label, description, descriptionlen, min, max);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1showConfigDialog(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jhwnd, jlong hwndHwnd, jboolean jshow) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	jlong handle = 0;
	if(jhwnd) {
		handle = Java_org_jouvieje_FmodEx_FmodExJNI_getHwnd(jenv, jcls, jhwnd);
	}
	bool show = (bool)(jshow != 0);
	
	ConfigDialogThreadParams *params = new ConfigDialogThreadParams();
	params->jPointer = jPointer;
	params->handle = handle;
	params->hwndHwnd = hwndHwnd;
	params->show = show;
	params->isShown = false;
	
	_beginthread(configDialogThread, 0, (void *)params);
	
	while(params->isShown == false) {
		Sleep(1);
	}
	return (jint)(params->result);
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1getInfo(JNIEnv *jenv, jclass jcls, jlong jPointer, 	jobject jname, jlong jname_, jobject jversion, jlong jversion_, jobject jchannels, jlong jchannels_, jobject jconfigwidth, jlong jconfigwidth_, jobject jconfigheight, jlong jconfigheight_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	char *name = 0;
	if(jname) {
		name = (char *)jenv->GetDirectBufferAddress(jname)+jname_;
	}
	unsigned int *version = 0;
	if(jversion) {
		version = (unsigned int *)((char *)jenv->GetDirectBufferAddress(jversion)+jversion_);
	}
	int *channels = 0;
	if(jchannels) {
		channels = (int *)((char *)jenv->GetDirectBufferAddress(jchannels)+jchannels_);
	}
	int *configwidth = 0;
	if(jconfigwidth) {
		configwidth = (int *)((char *)jenv->GetDirectBufferAddress(jconfigwidth)+jconfigwidth_);
	}
	int *configheight = 0;
	if(jconfigheight) {
		configheight = (int *)((char *)jenv->GetDirectBufferAddress(jconfigheight)+jconfigheight_);
	}

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->getInfo(name, version, channels, configwidth, configheight);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1setDefaults(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jfrequency, jfloat jvolume, jfloat jpan, jint jpriority) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	float frequency = (float)jfrequency;
	float volume = (float)jvolume;
	float pan = (float)jpan;
	int priority = (int)jpriority;

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->setDefaults(frequency, volume, pan, priority);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1getDefaults(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jfrequency, jlong jfrequency_, jobject jvolume, jlong jvolume_, jobject jpan, jlong jpan_, jobject jpriority, jlong jpriority_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	float *frequency = 0;
	if(jfrequency) {
		frequency = (float *)((char *)jenv->GetDirectBufferAddress(jfrequency)+jfrequency_);
	}
	float *volume = 0;
	if(jvolume) {
		volume = (float *)((char *)jenv->GetDirectBufferAddress(jvolume)+jvolume_);
	}
	float *pan = 0;
	if(jpan) {
		pan = (float *)((char *)jenv->GetDirectBufferAddress(jpan)+jpan_);
	}
	int *priority = 0;
	if(jpriority) {
		priority = (int *)((char *)jenv->GetDirectBufferAddress(jpriority)+jpriority_);
	}

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->getDefaults(frequency, volume, pan, priority);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1setUserData(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong juserdata) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	void *userdata = *(void **)&juserdata;

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->setUserData(userdata);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_DSP_1getUserData(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject juserdata) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_DSP);
		return 0;
	}
	void *userdata;

	FMOD_RESULT result_ = (*(FMOD::DSP **)&jPointer)->getUserData(&userdata);

	if(userdata && juserdata) {
		jlong newAddress;
		*(void **)&newAddress = userdata;
		setPointerAddress(jenv, juserdata, newAddress);
	}
	return (jint)result_;
}


