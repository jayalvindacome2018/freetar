/**
 * 							NativeFmodEx Project
 *
 * Do you want to use FMOD Ex API (www.fmod.org) with the Java language ? I've created NativeFmodEx for you.
 * Copyright � 2005-2006 J�r�me JOUVIE (Jouvieje)
 *
 * Created on 23 feb. 2005
 * @version file v1.0.0
 * @author J�r�me JOUVIE (Jouvieje)
 * 
 * 
 * WANT TO CONTACT ME ?
 * E-mail :
 * 		jerome.jouvie@gmail.com
 * My web sites :
 * 		http://jerome.jouvie.free.fr/
 * 		http://topresult.tomato.co.uk/~jerome/
 * 
 * 
 * INTRODUCTION
 * FMOD Ex is an API (Application Programming Interface) that allow you to use music
 * and creating sound effects with a lot of sort of musics.
 * FMOD is at :
 * 		http://www.fmod.org/
 * The reason of this project is that FMOD Ex can't be used direcly with Java, so I've created
 * this project to do this.
 * 
 * 
 * GNU LESSER GENERAL PUBLIC LICENSE
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of the License,
 * or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA 
 */
#include "Utils.h"
#include "Pointer.h"
#include "fmod.h"
#include "fmod.hpp"
#include "fmod_codec.h"
#include "fmod_dsp.h"
#include "fmod_output.h"
#include "org_jouvieje_FmodEx_Structures_StructureJNI.h"
#include "CallbackManager.h"

JNIEXPORT jlong JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CODEC_1STATE_1new(JNIEnv *jenv, jclass jcls) {
	FMOD_CODEC_STATE *result_ = new FMOD_CODEC_STATE();
	jlong jresult = 0;
	*(FMOD_CODEC_STATE **)&jresult = result_;
	return jresult;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CODEC_1STATE_1delete(JNIEnv *jenv, jclass jcls, jlong pointer) {
	delete *(FMOD_CODEC_STATE **)&pointer;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CODEC_1STATE_1get_1numsubsounds(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CODEC_STATE);
		return 0;
	}
	int result_ = (*(FMOD_CODEC_STATE **)&pointer)->numsubsounds;
	return (jint)result_;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CODEC_1STATE_1set_1numsubsounds(JNIEnv *jenv, jclass jcls, jlong pointer, jint jnumsubsounds) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CODEC_STATE);
		return;
	}
	int numsubsounds = (int)jnumsubsounds;
	(*(FMOD_CODEC_STATE **)&pointer)->numsubsounds = numsubsounds;
}

JNIEXPORT jlong JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CODEC_1STATE_1get_1waveformat(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CODEC_STATE);
		return 0;
	}
	jlong jresult;
	*(FMOD_CODEC_WAVEFORMAT **)&jresult = (*(FMOD_CODEC_STATE **)&pointer)->waveformat;
	return jresult;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CODEC_1STATE_1set_1waveformat(JNIEnv *jenv, jclass jcls, jlong pointer, jlong jwaveformat) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CODEC_STATE);
		return;
	}
	(*(FMOD_CODEC_STATE **)&pointer)->waveformat = *(FMOD_CODEC_WAVEFORMAT **)&jwaveformat;
}

JNIEXPORT jlong JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CODEC_1STATE_1get_1plugindata(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CODEC_STATE);
		return 0;
	}
	jlong jresult;
	*(void **)&jresult = (*(FMOD_CODEC_STATE **)&pointer)->plugindata;
	return jresult;
}

JNIEXPORT void JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CODEC_1STATE_1set_1plugindata(JNIEnv *jenv, jclass jcls, jlong pointer, jlong jplugindata) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CODEC_STATE);
		return;
	}
	(*(FMOD_CODEC_STATE **)&pointer)->plugindata = *(void **)&jplugindata;
}

JNIEXPORT jlong JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CODEC_1STATE_1get_1filehandle(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CODEC_STATE);
		return 0;
	}
	jlong jresult;
	*(void **)&jresult = (*(FMOD_CODEC_STATE **)&pointer)->filehandle;
	return jresult;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CODEC_1STATE_1get_1filesize(JNIEnv *jenv, jclass jcls, jlong pointer) {
	if(!pointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CODEC_STATE);
		return 0;
	}
	int result_ = (*(FMOD_CODEC_STATE **)&pointer)->filesize;
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CODEC_1STATE_1invoke_1fileread(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jhandle, jobject jbuffer, jlong jbuffer_, jint jsizebytes, jobject jbytesread, jlong jbytesread_, jlong juserdata) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CODEC_STATE);
		return 0;
	}
	void *handle = *(void **)&jhandle;
	void *buffer = 0;
	if(jbuffer) {
		buffer = (void *)((char *)jenv->GetDirectBufferAddress(jbuffer)+jbuffer_);
	}
	int sizebytes = (int)jsizebytes;
	unsigned int *bytesread = 0;
	if(jbytesread) {
		bytesread = (unsigned int *)((char *)jenv->GetDirectBufferAddress(jbytesread)+jbytesread_);
	}
	void *userdata = *(void **)&juserdata;

	FMOD_RESULT result_ = (*(FMOD_CODEC_STATE **)&jPointer)->fileread(handle, buffer, sizebytes, bytesread, userdata);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CODEC_1STATE_1invoke_1fileseek(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jhandle, jint jpos, jlong juserdata) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CODEC_STATE);
		return 0;
	}
	void *handle = *(void **)&jhandle;
	int pos = (int)jpos;
	void *userdata = *(void **)&juserdata;

	FMOD_RESULT result_ = (*(FMOD_CODEC_STATE **)&jPointer)->fileseek(handle, pos, userdata);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_Structures_StructureJNI_FMOD_1CODEC_1STATE_1invoke_1metadata(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jcodec_state, jint jtagtype, 	jobject jname, jlong jname_, jlong jdata, jint jdatalen, jint jdatatype, jint junique) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_FMOD_CODEC_STATE);
		return 0;
	}
	FMOD_CODEC_STATE *codec_state = *(FMOD_CODEC_STATE **)&jcodec_state;
	FMOD_TAGTYPE tagtype = (FMOD_TAGTYPE)jtagtype;
	char *name = 0;
	if(jname) {
		name = (char *)jenv->GetDirectBufferAddress(jname)+jname_;
	}
	void *data = *(void **)&jdata;
	int datalen = (int)jdatalen;
	FMOD_TAGDATATYPE datatype = (FMOD_TAGDATATYPE)jdatatype;
	int unique = (int)junique;

	FMOD_RESULT result_ = (*(FMOD_CODEC_STATE **)&jPointer)->metadata(codec_state, tagtype, name, data, datalen, datatype, unique);

	return (jint)result_;
}



