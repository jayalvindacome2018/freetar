/**
 * 							NativeFmodEx Project
 *
 * Do you want to use FMOD Ex API (www.fmod.org) with the Java language ? I've created NativeFmodEx for you.
 * Copyright � 2005-2006 J�r�me JOUVIE (Jouvieje)
 *
 * Created on 23 feb. 2005
 * @version file v1.0.0
 * @author J�r�me JOUVIE (Jouvieje)
 * 
 * 
 * WANT TO CONTACT ME ?
 * E-mail :
 * 		jerome.jouvie@gmail.com
 * My web sites :
 * 		http://jerome.jouvie.free.fr/
 * 		http://topresult.tomato.co.uk/~jerome/
 * 
 * 
 * INTRODUCTION
 * FMOD Ex is an API (Application Programming Interface) that allow you to use music
 * and creating sound effects with a lot of sort of musics.
 * FMOD is at :
 * 		http://www.fmod.org/
 * The reason of this project is that FMOD Ex can't be used direcly with Java, so I've created
 * this project to do this.
 * 
 * 
 * GNU LESSER GENERAL PUBLIC LICENSE
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of the License,
 * or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA 
 */
#include "Utils.h"
#include "Pointer.h"
#include "fmod.h"
#include "fmod.hpp"
#include "fmod_codec.h"
#include "fmod_dsp.h"
#include "fmod_output.h"
#include "malloc.h"
#include "CallbackManager.h"

jclass byteBufferClass = 0;
jclass getByteBufferClass(JNIEnv *jenv) {
	if(!byteBufferClass) {
		byteBufferClass = (jclass)jenv->NewGlobalRef(jenv->FindClass("java/nio/ByteBuffer"));
	}
	return byteBufferClass;
}

jclass caller = 0;
void connectCaller(JNIEnv *jenv) {
	caller = (jclass)jenv->NewGlobalRef(jenv->FindClass("org/jouvieje/FmodEx/Callbacks/CallbackBridge"));
	if(jenv->ExceptionCheck()) {
		jenv->ExceptionClear();
		caller = 0;
		ThrowException(jenv, InitException, "Connection to CallbackBridge fails.");
	}
}

jmethodID callbackId[28];
void connectCallbacks(JNIEnv *jenv) {
	static struct {
		const char *name;
		const char *signature;
	}callbacks[28] = {
		{"FMOD_SOUND_NONBLOCKCALLBACK_BRIDGE", "(JI)I"},
		{"FMOD_SOUND_PCMREADCALLBACK_BRIDGE", "(JLjava/nio/ByteBuffer;I)I"},
		{"FMOD_SOUND_PCMSETPOSCALLBACK_BRIDGE", "(JIII)I"},
		{"FMOD_CHANNEL_CALLBACK_BRIDGE", "(JIIII)I"},
		{"FMOD_FILE_OPENCALLBACK_BRIDGE", "(Ljava/lang/String;ILjava/nio/ByteBuffer;Lorg/jouvieje/FmodEx/Misc/Pointer;Lorg/jouvieje/FmodEx/Misc/Pointer;)I"},
		{"FMOD_FILE_CLOSECALLBACK_BRIDGE", "(JJ)I"},
		{"FMOD_FILE_READCALLBACK_BRIDGE", "(JLjava/nio/ByteBuffer;ILjava/nio/ByteBuffer;J)I"},
		{"FMOD_FILE_SEEKCALLBACK_BRIDGE", "(JIJ)I"},
		{"FMOD_MEMORY_ALLOCCALLBACK_BRIDGE", "(I)Ljava/nio/ByteBuffer;"},
		{"FMOD_MEMORY_REALLOCCALLBACK_BRIDGE", "(Ljava/nio/ByteBuffer;I)Ljava/nio/ByteBuffer;"},
		{"FMOD_MEMORY_FREECALLBACK_BRIDGE", "(Ljava/nio/ByteBuffer;)V"},
		{"FMOD_CODEC_OPENCALLBACK_BRIDGE", "(JIJ)I"},
		{"FMOD_CODEC_CLOSECALLBACK_BRIDGE", "(J)I"},
		{"FMOD_CODEC_READCALLBACK_BRIDGE", "(JLjava/nio/ByteBuffer;ILjava/nio/ByteBuffer;)I"},
		{"FMOD_CODEC_GETLENGTHCALLBACK_BRIDGE", "(JLjava/nio/ByteBuffer;I)I"},
		{"FMOD_CODEC_SETPOSITIONCALLBACK_BRIDGE", "(JIII)I"},
		{"FMOD_CODEC_GETPOSITIONCALLBACK_BRIDGE", "(JLjava/nio/ByteBuffer;I)I"},
		{"FMOD_CODEC_SOUNDCREATECALLBACK_BRIDGE", "(JIJ)I"},
		{"FMOD_CODEC_METADATACALLBACK_BRIDGE", "(JILjava/nio/ByteBuffer;JIII)I"},
		{"FMOD_CODEC_GETWAVEFORMAT_BRIDGE", "(JIJ)I"},
		{"FMOD_DSP_CREATECALLBACK_BRIDGE", "(J)I"},
		{"FMOD_DSP_RELEASECALLBACK_BRIDGE", "(J)I"},
		{"FMOD_DSP_RESETCALLBACK_BRIDGE", "(J)I"},
		{"FMOD_DSP_READCALLBACK_BRIDGE", "(JLjava/nio/ByteBuffer;Ljava/nio/ByteBuffer;III)I"},
		{"FMOD_DSP_SETPOSITIONCALLBACK_BRIDGE", "(JI)I"},
		{"FMOD_DSP_SETPARAMCALLBACK_BRIDGE", "(JIF)I"},
		{"FMOD_DSP_GETPARAMCALLBACK_BRIDGE", "(JILjava/nio/ByteBuffer;Ljava/nio/ByteBuffer;)I"},
		{"FMOD_DSP_DIALOGCALLBACK_BRIDGE", "(JJI)I"}
	};

	for(int i = 0; i < 28; i++) {
		callbackId[i] = jenv->GetStaticMethodID(caller, callbacks[i].name, callbacks[i].signature);
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionClear();
			ThrowException(jenv, InitException, "Connection to a Callback fails.");
			return;
		}
	}
}

JavaVM *jvm;
void attachJavaVM(JNIEnv *jenv) {
	jenv->GetJavaVM(&jvm);
	connectCaller(jenv);
	if(caller) {
		connectCallbacks(jenv);
	}
}
bool acquire_jenv(JNIEnv **jenv) {
	if(jvm->GetEnv((void **)jenv, JNI_VERSION_1_4) != JNI_OK) {
		jvm->AttachCurrentThread((void **)jenv, 0);
		return true;
	}
	return false;
}
void leave_jenv(bool attached) {
	if(attached) {
		jvm->DetachCurrentThread();
	}
}

FMOD_RESULT F_CALLBACK FMOD_SOUND_NONBLOCKCALLBACK_BRIDGE(FMOD_SOUND * sound, FMOD_RESULT result) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jlong jsound = 0;
	*(FMOD::Sound **)&jsound = (FMOD::Sound *)sound;
	jint result_ = jenv->CallStaticIntMethod(caller, callbackId[0], jsound, (jint)result);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	leave_jenv(attached);
	return (FMOD_RESULT)result_;
}

FMOD_RESULT F_CALLBACK FMOD_SOUND_PCMREADCALLBACK_BRIDGE(FMOD_SOUND * sound, void * data, unsigned int datalen) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jlong jsound = 0;
	*(FMOD::Sound **)&jsound = (FMOD::Sound *)sound;
	jobject jdata = 0;
	if(data) {
		jdata = jenv->NewDirectByteBuffer(data, datalen);
	}
	jint result_ = jenv->CallStaticIntMethod(caller, callbackId[1], jsound, jdata, (jint)datalen);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	leave_jenv(attached);
	return (FMOD_RESULT)result_;
}

FMOD_RESULT F_CALLBACK FMOD_SOUND_PCMSETPOSCALLBACK_BRIDGE(FMOD_SOUND * sound, int subsound, unsigned int position, FMOD_TIMEUNIT postype) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jlong jsound = 0;
	*(FMOD::Sound **)&jsound = (FMOD::Sound *)sound;
	jint result_ = jenv->CallStaticIntMethod(caller, callbackId[2], jsound, (jint)subsound, (jint)position, (jint)postype);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	leave_jenv(attached);
	return (FMOD_RESULT)result_;
}

FMOD_RESULT F_CALLBACK FMOD_CHANNEL_CALLBACK_BRIDGE(FMOD_CHANNEL * channel, FMOD_CHANNEL_CALLBACKTYPE type, int command, unsigned int commanddata1, unsigned int commanddata2) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jlong jchannel = 0;
	*(FMOD::Channel **)&jchannel = (FMOD::Channel *)channel;
	jint result_ = jenv->CallStaticIntMethod(caller, callbackId[3], jchannel, (jint)type, (jint)command, (jint)commanddata1, (jint)commanddata2);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	leave_jenv(attached);
	return (FMOD_RESULT)result_;
}

FMOD_RESULT F_CALLBACK FMOD_FILE_OPENCALLBACK_BRIDGE(const char * name, int unicode, unsigned int * filesize, void ** handle, void ** userdata) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jstring jname = 0;
	if(name) {
		jname = jenv->NewStringUTF(name);
	}
	jobject jfilesize = 0;
	if(filesize) {
		jfilesize = jenv->NewDirectByteBuffer(filesize, 4);
	}
	jobject jhandle = newPointer(jenv);
	jobject juserdata = newPointer(jenv);
	jint result_ = jenv->CallStaticIntMethod(caller, callbackId[4], jname, (jint)unicode, jfilesize, jhandle, juserdata);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	if(jhandle) {
		long jhandleAddress = getPointerAddress(jenv, jhandle);
		*handle = *(void **)&jhandleAddress;
	}
	if(juserdata) {
		long juserdataAddress = getPointerAddress(jenv, juserdata);
		*userdata = *(void **)&juserdataAddress;
	}
	leave_jenv(attached);
	return (FMOD_RESULT)result_;
}

FMOD_RESULT F_CALLBACK FMOD_FILE_CLOSECALLBACK_BRIDGE(void * handle, void * userdata) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jlong jhandle = 0;
	*(void **)&jhandle = handle;
	jlong juserdata = 0;
	*(void **)&juserdata = userdata;
	jint result_ = jenv->CallStaticIntMethod(caller, callbackId[5], jhandle, juserdata);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	leave_jenv(attached);
	return (FMOD_RESULT)result_;
}

FMOD_RESULT F_CALLBACK FMOD_FILE_READCALLBACK_BRIDGE(void * handle, void * buffer, unsigned int sizebytes, unsigned int * bytesread, void * userdata) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jlong jhandle = 0;
	*(void **)&jhandle = handle;
	jobject jbuffer = 0;
	if(buffer) {
		jbuffer = jenv->NewDirectByteBuffer(buffer, sizebytes);
	}
	jobject jbytesread = 0;
	if(bytesread) {
		jbytesread = jenv->NewDirectByteBuffer(bytesread, 4);
	}
	jlong juserdata = 0;
	*(void **)&juserdata = userdata;
	jint result_ = jenv->CallStaticIntMethod(caller, callbackId[6], jhandle, jbuffer, (jint)sizebytes, jbytesread, juserdata);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	leave_jenv(attached);
	return (FMOD_RESULT)result_;
}

FMOD_RESULT F_CALLBACK FMOD_FILE_SEEKCALLBACK_BRIDGE(void * handle, unsigned int pos, void * userdata) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jlong jhandle = 0;
	*(void **)&jhandle = handle;
	jlong juserdata = 0;
	*(void **)&juserdata = userdata;
	jint result_ = jenv->CallStaticIntMethod(caller, callbackId[7], jhandle, (jint)pos, juserdata);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	leave_jenv(attached);
	return (FMOD_RESULT)result_;
}

void * F_CALLBACK FMOD_MEMORY_ALLOCCALLBACK_BRIDGE(unsigned int size) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jobject result_ = jenv->CallStaticObjectMethod(caller, callbackId[8], (jint)size);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	if(result_) {
		jobject globalRef = jenv->NewGlobalRef(result_);
		if(globalRef) {
			return jenv->GetDirectBufferAddress(globalRef);
		}
		else {
			ThrowException(jenv, OutOfMemoryError, "");
		}
	}
	leave_jenv(attached);
	return 0;
}

void * F_CALLBACK FMOD_MEMORY_REALLOCCALLBACK_BRIDGE(void * ptr, unsigned int size) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jobject jptr = 0;
	if(ptr) {
		jptr = jenv->NewDirectByteBuffer(ptr, _msize(ptr));
	}
	jobject result_ = jenv->CallStaticObjectMethod(caller, callbackId[9], jptr, (jint)size);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	if(result_) {
		jobject globalRef = jenv->NewGlobalRef(result_);
		if(globalRef) {
			return jenv->GetDirectBufferAddress(globalRef);
		}
		else {
			ThrowException(jenv, OutOfMemoryError, "");
		}
	}
	leave_jenv(attached);
	return 0;
}

void F_CALLBACK FMOD_MEMORY_FREECALLBACK_BRIDGE(void * ptr) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jobject jptr = 0;
	if(ptr) {
		jptr = jenv->NewDirectByteBuffer(ptr, _msize(ptr));
	}
	jenv->CallStaticVoidMethod(caller, callbackId[10], jptr);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	leave_jenv(attached);

}

FMOD_RESULT F_CALLBACK FMOD_CODEC_OPENCALLBACK_BRIDGE(FMOD_CODEC_STATE * codec_state, FMOD_MODE usermode, FMOD_CREATESOUNDEXINFO * userexinfo) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jlong jcodec_state = 0;
	*(FMOD_CODEC_STATE **)&jcodec_state = (FMOD_CODEC_STATE *)codec_state;
	jlong juserexinfo = 0;
	*(FMOD_CREATESOUNDEXINFO **)&juserexinfo = (FMOD_CREATESOUNDEXINFO *)userexinfo;
	jint result_ = jenv->CallStaticIntMethod(caller, callbackId[11], jcodec_state, (jint)usermode, juserexinfo);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	leave_jenv(attached);
	return (FMOD_RESULT)result_;
}

FMOD_RESULT F_CALLBACK FMOD_CODEC_CLOSECALLBACK_BRIDGE(FMOD_CODEC_STATE * codec_state) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jlong jcodec_state = 0;
	*(FMOD_CODEC_STATE **)&jcodec_state = (FMOD_CODEC_STATE *)codec_state;
	jint result_ = jenv->CallStaticIntMethod(caller, callbackId[12], jcodec_state);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	leave_jenv(attached);
	return (FMOD_RESULT)result_;
}

FMOD_RESULT F_CALLBACK FMOD_CODEC_READCALLBACK_BRIDGE(FMOD_CODEC_STATE * codec_state, void * buffer, unsigned int sizebytes, unsigned int * bytesread) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jlong jcodec_state = 0;
	*(FMOD_CODEC_STATE **)&jcodec_state = (FMOD_CODEC_STATE *)codec_state;
	jobject jbuffer = 0;
	if(buffer) {
		jbuffer = jenv->NewDirectByteBuffer(buffer, sizebytes);
	}
	jobject jbytesread = 0;
	if(bytesread) {
		jbytesread = jenv->NewDirectByteBuffer(bytesread, 4);
	}
	jint result_ = jenv->CallStaticIntMethod(caller, callbackId[13], jcodec_state, jbuffer, (jint)sizebytes, jbytesread);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	leave_jenv(attached);
	return (FMOD_RESULT)result_;
}

FMOD_RESULT F_CALLBACK FMOD_CODEC_GETLENGTHCALLBACK_BRIDGE(FMOD_CODEC_STATE * codec_state, unsigned int * length, FMOD_TIMEUNIT lengthtype) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jlong jcodec_state = 0;
	*(FMOD_CODEC_STATE **)&jcodec_state = (FMOD_CODEC_STATE *)codec_state;
	jobject jlength = 0;
	if(length) {
		jlength = jenv->NewDirectByteBuffer(length, 4);
	}
	jint result_ = jenv->CallStaticIntMethod(caller, callbackId[14], jcodec_state, jlength, (jint)lengthtype);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	leave_jenv(attached);
	return (FMOD_RESULT)result_;
}

FMOD_RESULT F_CALLBACK FMOD_CODEC_SETPOSITIONCALLBACK_BRIDGE(FMOD_CODEC_STATE * codec_state, int subsound, unsigned int position, FMOD_TIMEUNIT postype) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jlong jcodec_state = 0;
	*(FMOD_CODEC_STATE **)&jcodec_state = (FMOD_CODEC_STATE *)codec_state;
	jint result_ = jenv->CallStaticIntMethod(caller, callbackId[15], jcodec_state, (jint)subsound, (jint)position, (jint)postype);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	leave_jenv(attached);
	return (FMOD_RESULT)result_;
}

FMOD_RESULT F_CALLBACK FMOD_CODEC_GETPOSITIONCALLBACK_BRIDGE(FMOD_CODEC_STATE * codec_state, unsigned int * position, FMOD_TIMEUNIT postype) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jlong jcodec_state = 0;
	*(FMOD_CODEC_STATE **)&jcodec_state = (FMOD_CODEC_STATE *)codec_state;
	jobject jposition = 0;
	if(position) {
		jposition = jenv->NewDirectByteBuffer(position, 4);
	}
	jint result_ = jenv->CallStaticIntMethod(caller, callbackId[16], jcodec_state, jposition, (jint)postype);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	leave_jenv(attached);
	return (FMOD_RESULT)result_;
}

FMOD_RESULT F_CALLBACK FMOD_CODEC_SOUNDCREATECALLBACK_BRIDGE(FMOD_CODEC_STATE * codec_state, int subsound, FMOD_SOUND * sound) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jlong jcodec_state = 0;
	*(FMOD_CODEC_STATE **)&jcodec_state = (FMOD_CODEC_STATE *)codec_state;
	jlong jsound = 0;
	*(FMOD::Sound **)&jsound = (FMOD::Sound *)sound;
	jint result_ = jenv->CallStaticIntMethod(caller, callbackId[17], jcodec_state, (jint)subsound, jsound);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	leave_jenv(attached);
	return (FMOD_RESULT)result_;
}

FMOD_RESULT F_CALLBACK FMOD_CODEC_METADATACALLBACK_BRIDGE(FMOD_CODEC_STATE * codec_state, FMOD_TAGTYPE tagtype, char * name, void * data, unsigned int datalen, FMOD_TAGDATATYPE datatype, int unique) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jlong jcodec_state = 0;
	*(FMOD_CODEC_STATE **)&jcodec_state = (FMOD_CODEC_STATE *)codec_state;
	jobject jname = 0;
	if(name) {
		jname = jenv->NewDirectByteBuffer(name, strlen((const char *)name));
	}
	jlong jdata = 0;
	*(void **)&jdata = data;
	jint result_ = jenv->CallStaticIntMethod(caller, callbackId[18], jcodec_state, (jint)tagtype, jname, jdata, (jint)datalen, (jint)datatype, (jint)unique);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	leave_jenv(attached);
	return (FMOD_RESULT)result_;
}

FMOD_RESULT F_CALLBACK FMOD_CODEC_GETWAVEFORMAT_BRIDGE(FMOD_CODEC_STATE * codec_state, int index, FMOD_CODEC_WAVEFORMAT * waveformat) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jlong jcodec_state = 0;
	*(FMOD_CODEC_STATE **)&jcodec_state = (FMOD_CODEC_STATE *)codec_state;
	jlong jwaveformat = 0;
	*(FMOD_CODEC_WAVEFORMAT **)&jwaveformat = (FMOD_CODEC_WAVEFORMAT *)waveformat;
	jint result_ = jenv->CallStaticIntMethod(caller, callbackId[19], jcodec_state, (jint)index, jwaveformat);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	leave_jenv(attached);
	return (FMOD_RESULT)result_;
}

FMOD_RESULT F_CALLBACK FMOD_DSP_CREATECALLBACK_BRIDGE(FMOD_DSP_STATE * dsp_state) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jlong jdsp_state = 0;
	*(FMOD_DSP_STATE **)&jdsp_state = (FMOD_DSP_STATE *)dsp_state;
	jint result_ = jenv->CallStaticIntMethod(caller, callbackId[20], jdsp_state);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	leave_jenv(attached);
	return (FMOD_RESULT)result_;
}

FMOD_RESULT F_CALLBACK FMOD_DSP_RELEASECALLBACK_BRIDGE(FMOD_DSP_STATE * dsp_state) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jlong jdsp_state = 0;
	*(FMOD_DSP_STATE **)&jdsp_state = (FMOD_DSP_STATE *)dsp_state;
	jint result_ = jenv->CallStaticIntMethod(caller, callbackId[21], jdsp_state);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	leave_jenv(attached);
	return (FMOD_RESULT)result_;
}

FMOD_RESULT F_CALLBACK FMOD_DSP_RESETCALLBACK_BRIDGE(FMOD_DSP_STATE * dsp_state) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jlong jdsp_state = 0;
	*(FMOD_DSP_STATE **)&jdsp_state = (FMOD_DSP_STATE *)dsp_state;
	jint result_ = jenv->CallStaticIntMethod(caller, callbackId[22], jdsp_state);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	leave_jenv(attached);
	return (FMOD_RESULT)result_;
}

FMOD_RESULT F_CALLBACK FMOD_DSP_READCALLBACK_BRIDGE(FMOD_DSP_STATE * dsp_state, float * inbuffer, float * outbuffer, unsigned int length, int inchannels, int outchannels) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jlong jdsp_state = 0;
	*(FMOD_DSP_STATE **)&jdsp_state = (FMOD_DSP_STATE *)dsp_state;
	jobject jinbuffer = 0;
	if(inbuffer) {
		jinbuffer = jenv->NewDirectByteBuffer(inbuffer, length*inchannels*4);
	}
	jobject joutbuffer = 0;
	if(outbuffer) {
		joutbuffer = jenv->NewDirectByteBuffer(outbuffer, length*outchannels*4);
	}
	jint result_ = jenv->CallStaticIntMethod(caller, callbackId[23], jdsp_state, jinbuffer, joutbuffer, (jint)length, (jint)inchannels, (jint)outchannels);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	leave_jenv(attached);
	return (FMOD_RESULT)result_;
}

FMOD_RESULT F_CALLBACK FMOD_DSP_SETPOSITIONCALLBACK_BRIDGE(FMOD_DSP_STATE * dsp_state, unsigned int pos) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jlong jdsp_state = 0;
	*(FMOD_DSP_STATE **)&jdsp_state = (FMOD_DSP_STATE *)dsp_state;
	jint result_ = jenv->CallStaticIntMethod(caller, callbackId[24], jdsp_state, (jint)pos);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	leave_jenv(attached);
	return (FMOD_RESULT)result_;
}

FMOD_RESULT F_CALLBACK FMOD_DSP_SETPARAMCALLBACK_BRIDGE(FMOD_DSP_STATE * dsp_state, int index, float value) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jlong jdsp_state = 0;
	*(FMOD_DSP_STATE **)&jdsp_state = (FMOD_DSP_STATE *)dsp_state;
	jint result_ = jenv->CallStaticIntMethod(caller, callbackId[25], jdsp_state, (jint)index, (jfloat)value);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	leave_jenv(attached);
	return (FMOD_RESULT)result_;
}

FMOD_RESULT F_CALLBACK FMOD_DSP_GETPARAMCALLBACK_BRIDGE(FMOD_DSP_STATE * dsp_state, int index, float * value, char * valuestr) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jlong jdsp_state = 0;
	*(FMOD_DSP_STATE **)&jdsp_state = (FMOD_DSP_STATE *)dsp_state;
	jobject jvalue = 0;
	if(value) {
		jvalue = jenv->NewDirectByteBuffer(value, 4);
	}
	jobject jvaluestr = 0;
	if(valuestr) {
		jvaluestr = jenv->NewDirectByteBuffer(valuestr, 16);
	}
	jint result_ = jenv->CallStaticIntMethod(caller, callbackId[26], jdsp_state, (jint)index, jvalue, jvaluestr);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	leave_jenv(attached);
	return (FMOD_RESULT)result_;
}

FMOD_RESULT F_CALLBACK FMOD_DSP_DIALOGCALLBACK_BRIDGE(FMOD_DSP_STATE * dsp_state, void * hwnd, int show) {
	JNIEnv *jenv = 0;
	bool attached = acquire_jenv(&jenv);
	jlong jdsp_state = 0;
	*(FMOD_DSP_STATE **)&jdsp_state = (FMOD_DSP_STATE *)dsp_state;
	jlong jhwnd = 0;
	*(void **)&jhwnd = hwnd;
	jint result_ = jenv->CallStaticIntMethod(caller, callbackId[27], jdsp_state, jhwnd, (jint)show);
	if(jenv->ExceptionCheck()) {
		jenv->Throw(jenv->ExceptionOccurred());
		if(jenv->ExceptionCheck()) {
			jenv->ExceptionDescribe();
			jenv->FatalError(FATAL_ERROR_MESSAGE);
		}
	}
	leave_jenv(attached);
	return (FMOD_RESULT)result_;
}


