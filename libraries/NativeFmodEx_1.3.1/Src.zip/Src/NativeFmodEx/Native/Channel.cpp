/**
 * 							NativeFmodEx Project
 *
 * Do you want to use FMOD Ex API (www.fmod.org) with the Java language ? I've created NativeFmodEx for you.
 * Copyright � 2005-2006 J�r�me JOUVIE (Jouvieje)
 *
 * Created on 23 feb. 2005
 * @version file v1.0.0
 * @author J�r�me JOUVIE (Jouvieje)
 * 
 * 
 * WANT TO CONTACT ME ?
 * E-mail :
 * 		jerome.jouvie@gmail.com
 * My web sites :
 * 		http://jerome.jouvie.free.fr/
 * 		http://topresult.tomato.co.uk/~jerome/
 * 
 * 
 * INTRODUCTION
 * FMOD Ex is an API (Application Programming Interface) that allow you to use music
 * and creating sound effects with a lot of sort of musics.
 * FMOD is at :
 * 		http://www.fmod.org/
 * The reason of this project is that FMOD Ex can't be used direcly with Java, so I've created
 * this project to do this.
 * 
 * 
 * GNU LESSER GENERAL PUBLIC LICENSE
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of the License,
 * or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA 
 */
#include "Utils.h"
#include "Pointer.h"
#include "fmod.h"
#include "fmod.hpp"
#include "fmod_codec.h"
#include "fmod_dsp.h"
#include "fmod_output.h"
#include "org_jouvieje_FmodEx_FmodExJNI.h"
#include "CallbackManager.h"

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1getSystemObject(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jsystem) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	FMOD::System *system;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->getSystemObject(&system);

	if(system && jsystem) {
		jlong newAddress = 0;
		*(FMOD::System **)&newAddress = system;
		setPointerAddress(jenv, jsystem, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1stop(JNIEnv *jenv, jclass jcls, jlong jPointer) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->stop();

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1setPaused(JNIEnv *jenv, jclass jcls, jlong jPointer, jboolean jpaused) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	bool paused = (bool)(jpaused != 0);

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->setPaused(paused);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1getPaused(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jpaused, jlong jpaused_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	bool *paused =  0;
	if(jpaused) {
		paused = (bool *)((char *)jenv->GetDirectBufferAddress(jpaused)+jpaused_);
	}

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->getPaused(paused);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1setVolume(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jvolume) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	float volume = (float)jvolume;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->setVolume(volume);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1getVolume(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jvolume, jlong jvolume_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	float *volume = 0;
	if(jvolume) {
		volume = (float *)((char *)jenv->GetDirectBufferAddress(jvolume)+jvolume_);
	}

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->getVolume(volume);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1setFrequency(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jfrequency) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	float frequency = (float)jfrequency;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->setFrequency(frequency);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1getFrequency(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jfrequency, jlong jfrequency_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	float *frequency = 0;
	if(jfrequency) {
		frequency = (float *)((char *)jenv->GetDirectBufferAddress(jfrequency)+jfrequency_);
	}

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->getFrequency(frequency);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1setPan(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jpan) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	float pan = (float)jpan;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->setPan(pan);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1getPan(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jpan, jlong jpan_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	float *pan = 0;
	if(jpan) {
		pan = (float *)((char *)jenv->GetDirectBufferAddress(jpan)+jpan_);
	}

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->getPan(pan);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1setDelay(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jstartdelay, jint jenddelay) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	int startdelay = (int)jstartdelay;
	int enddelay = (int)jenddelay;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->setDelay(startdelay, enddelay);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1getDelay(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jstartdelay, jlong jstartdelay_, jobject jenddelay, jlong jenddelay_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	unsigned int *startdelay = 0;
	if(jstartdelay) {
		startdelay = (unsigned int *)((char *)jenv->GetDirectBufferAddress(jstartdelay)+jstartdelay_);
	}
	unsigned int *enddelay = 0;
	if(jenddelay) {
		enddelay = (unsigned int *)((char *)jenv->GetDirectBufferAddress(jenddelay)+jenddelay_);
	}

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->getDelay(startdelay, enddelay);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1setSpeakerMix(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jfrontleft, jfloat jfrontright, jfloat jcenter, jfloat jlfe, jfloat jbackleft, jfloat jbackright, jfloat jsideleft, jfloat jsideright) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	float frontleft = (float)jfrontleft;
	float frontright = (float)jfrontright;
	float center = (float)jcenter;
	float lfe = (float)jlfe;
	float backleft = (float)jbackleft;
	float backright = (float)jbackright;
	float sideleft = (float)jsideleft;
	float sideright = (float)jsideright;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->setSpeakerMix(frontleft, frontright, center, lfe, backleft, backright, sideleft, sideright);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1getSpeakerMix(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jfrontleft, jlong jfrontleft_, jobject jfrontright, jlong jfrontright_, jobject jcenter, jlong jcenter_, jobject jlfe, jlong jlfe_, jobject jbackleft, jlong jbackleft_, jobject jbackright, jlong jbackright_, jobject jsideleft, jlong jsideleft_, jobject jsideright, jlong jsideright_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	float *frontleft = 0;
	if(jfrontleft) {
		frontleft = (float *)((char *)jenv->GetDirectBufferAddress(jfrontleft)+jfrontleft_);
	}
	float *frontright = 0;
	if(jfrontright) {
		frontright = (float *)((char *)jenv->GetDirectBufferAddress(jfrontright)+jfrontright_);
	}
	float *center = 0;
	if(jcenter) {
		center = (float *)((char *)jenv->GetDirectBufferAddress(jcenter)+jcenter_);
	}
	float *lfe = 0;
	if(jlfe) {
		lfe = (float *)((char *)jenv->GetDirectBufferAddress(jlfe)+jlfe_);
	}
	float *backleft = 0;
	if(jbackleft) {
		backleft = (float *)((char *)jenv->GetDirectBufferAddress(jbackleft)+jbackleft_);
	}
	float *backright = 0;
	if(jbackright) {
		backright = (float *)((char *)jenv->GetDirectBufferAddress(jbackright)+jbackright_);
	}
	float *sideleft = 0;
	if(jsideleft) {
		sideleft = (float *)((char *)jenv->GetDirectBufferAddress(jsideleft)+jsideleft_);
	}
	float *sideright = 0;
	if(jsideright) {
		sideright = (float *)((char *)jenv->GetDirectBufferAddress(jsideright)+jsideright_);
	}

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->getSpeakerMix(frontleft, frontright, center, lfe, backleft, backright, sideleft, sideright);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1setSpeakerLevels(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jspeaker, jobject jlevels, jlong jlevels_, jint jnumlevels) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	FMOD_SPEAKER speaker = (FMOD_SPEAKER)jspeaker;
	float *levels = 0;
	if(jlevels) {
		levels = (float *)((char *)jenv->GetDirectBufferAddress(jlevels)+jlevels_);
	}
	int numlevels = (int)jnumlevels;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->setSpeakerLevels(speaker, levels, numlevels);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1getSpeakerLevels(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jspeaker, jobject jlevels, jlong jlevels_, jint jnumlevels) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	FMOD_SPEAKER speaker = (FMOD_SPEAKER)jspeaker;
	float *levels = 0;
	if(jlevels) {
		levels = (float *)((char *)jenv->GetDirectBufferAddress(jlevels)+jlevels_);
	}
	int numlevels = (int)jnumlevels;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->getSpeakerLevels(speaker, levels, numlevels);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1setMute(JNIEnv *jenv, jclass jcls, jlong jPointer, jboolean jmute) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	bool mute = (bool)(jmute != 0);

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->setMute(mute);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1getMute(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jmute, jlong jmute_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	bool *mute =  0;
	if(jmute) {
		mute = (bool *)((char *)jenv->GetDirectBufferAddress(jmute)+jmute_);
	}

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->getMute(mute);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1setPriority(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jpriority) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	int priority = (int)jpriority;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->setPriority(priority);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1getPriority(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jpriority, jlong jpriority_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	int *priority = 0;
	if(jpriority) {
		priority = (int *)((char *)jenv->GetDirectBufferAddress(jpriority)+jpriority_);
	}

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->getPriority(priority);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1setPosition(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jposition, jint jpostype) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	int position = (int)jposition;
	FMOD_TIMEUNIT postype = (FMOD_TIMEUNIT)jpostype;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->setPosition(position, postype);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1getPosition(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jposition, jlong jposition_, jint jpostype) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	unsigned int *position = 0;
	if(jposition) {
		position = (unsigned int *)((char *)jenv->GetDirectBufferAddress(jposition)+jposition_);
	}
	FMOD_TIMEUNIT postype = (FMOD_TIMEUNIT)jpostype;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->getPosition(position, postype);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1setReverbProperties(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jprop) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	FMOD_REVERB_CHANNELPROPERTIES *prop = *(FMOD_REVERB_CHANNELPROPERTIES **)&jprop;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->setReverbProperties(prop);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1getReverbProperties(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jprop) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	FMOD_REVERB_CHANNELPROPERTIES *prop = *(FMOD_REVERB_CHANNELPROPERTIES **)&jprop;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->getReverbProperties(prop);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1setChannelGroup(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jchannelgroup) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	FMOD::ChannelGroup *channelgroup = *(FMOD::ChannelGroup **)&jchannelgroup;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->setChannelGroup(channelgroup);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1getChannelGroup(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jchannelgroup) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	FMOD::ChannelGroup *channelgroup;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->getChannelGroup(&channelgroup);

	if(channelgroup && jchannelgroup) {
		jlong newAddress = 0;
		*(FMOD::ChannelGroup **)&newAddress = channelgroup;
		setPointerAddress(jenv, jchannelgroup, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1setCallback(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jtype, jboolean jcallback, jint jcommand) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	FMOD_CHANNEL_CALLBACKTYPE type = (FMOD_CHANNEL_CALLBACKTYPE)jtype;
	int command = (int)jcommand;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->setCallback(type, jcallback == 0 ? NULL : FMOD_CHANNEL_CALLBACK_BRIDGE, command);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1set3DAttributes(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jpos, jlong jvel) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	FMOD_VECTOR *pos = *(FMOD_VECTOR **)&jpos;
	FMOD_VECTOR *vel = *(FMOD_VECTOR **)&jvel;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->set3DAttributes(pos, vel);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1get3DAttributes(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jpos, jlong jvel) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	FMOD_VECTOR *pos = *(FMOD_VECTOR **)&jpos;
	FMOD_VECTOR *vel = *(FMOD_VECTOR **)&jvel;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->get3DAttributes(pos, vel);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1set3DMinMaxDistance(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jmindistance, jfloat jmaxdistance) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	float mindistance = (float)jmindistance;
	float maxdistance = (float)jmaxdistance;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->set3DMinMaxDistance(mindistance, maxdistance);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1get3DMinMaxDistance(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jmindistance, jlong jmindistance_, jobject jmaxdistance, jlong jmaxdistance_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	float *mindistance = 0;
	if(jmindistance) {
		mindistance = (float *)((char *)jenv->GetDirectBufferAddress(jmindistance)+jmindistance_);
	}
	float *maxdistance = 0;
	if(jmaxdistance) {
		maxdistance = (float *)((char *)jenv->GetDirectBufferAddress(jmaxdistance)+jmaxdistance_);
	}

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->get3DMinMaxDistance(mindistance, maxdistance);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1set3DConeSettings(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jinsideconeangle, jfloat joutsideconeangle, jfloat joutsidevolume) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	float insideconeangle = (float)jinsideconeangle;
	float outsideconeangle = (float)joutsideconeangle;
	float outsidevolume = (float)joutsidevolume;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->set3DConeSettings(insideconeangle, outsideconeangle, outsidevolume);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1get3DConeSettings(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jinsideconeangle, jlong jinsideconeangle_, jobject joutsideconeangle, jlong joutsideconeangle_, jobject joutsidevolume, jlong joutsidevolume_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	float *insideconeangle = 0;
	if(jinsideconeangle) {
		insideconeangle = (float *)((char *)jenv->GetDirectBufferAddress(jinsideconeangle)+jinsideconeangle_);
	}
	float *outsideconeangle = 0;
	if(joutsideconeangle) {
		outsideconeangle = (float *)((char *)jenv->GetDirectBufferAddress(joutsideconeangle)+joutsideconeangle_);
	}
	float *outsidevolume = 0;
	if(joutsidevolume) {
		outsidevolume = (float *)((char *)jenv->GetDirectBufferAddress(joutsidevolume)+joutsidevolume_);
	}

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->get3DConeSettings(insideconeangle, outsideconeangle, outsidevolume);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1set3DConeOrientation(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jorientation) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	FMOD_VECTOR *orientation = *(FMOD_VECTOR **)&jorientation;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->set3DConeOrientation(orientation);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1get3DConeOrientation(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jorientation) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	FMOD_VECTOR *orientation = *(FMOD_VECTOR **)&jorientation;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->get3DConeOrientation(orientation);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1set3DCustomRolloff(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jpoints, jint jnumpoints) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	FMOD_VECTOR *points = *(FMOD_VECTOR **)&jpoints;
	int numpoints = (int)jnumpoints;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->set3DCustomRolloff(points, numpoints);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1get3DCustomRolloff(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jpoints, jobject jnumpoints, jlong jnumpoints_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	FMOD_VECTOR *points;
	int *numpoints = 0;
	if(jnumpoints) {
		numpoints = (int *)((char *)jenv->GetDirectBufferAddress(jnumpoints)+jnumpoints_);
	}

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->get3DCustomRolloff(&points, numpoints);

	if(points && jpoints) {
		jlong newAddress = 0;
		*(FMOD_VECTOR **)&newAddress = points;
		setPointerAddress(jenv, jpoints, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1set3DOcclusion(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jdirectocclusion, jfloat jreverbocclusion) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	float directocclusion = (float)jdirectocclusion;
	float reverbocclusion = (float)jreverbocclusion;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->set3DOcclusion(directocclusion, reverbocclusion);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1get3DOcclusion(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jdirectocclusion, jlong jdirectocclusion_, jobject jreverbocclusion, jlong jreverbocclusion_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	float *directocclusion = 0;
	if(jdirectocclusion) {
		directocclusion = (float *)((char *)jenv->GetDirectBufferAddress(jdirectocclusion)+jdirectocclusion_);
	}
	float *reverbocclusion = 0;
	if(jreverbocclusion) {
		reverbocclusion = (float *)((char *)jenv->GetDirectBufferAddress(jreverbocclusion)+jreverbocclusion_);
	}

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->get3DOcclusion(directocclusion, reverbocclusion);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1set3DSpread(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jangle) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	float angle = (float)jangle;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->set3DSpread(angle);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1get3DSpread(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jangle, jlong jangle_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	float *angle = 0;
	if(jangle) {
		angle = (float *)((char *)jenv->GetDirectBufferAddress(jangle)+jangle_);
	}

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->get3DSpread(angle);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1set3DPanLevel(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jlevel) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	float level = (float)jlevel;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->set3DPanLevel(level);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1get3DPanLevel(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jlevel, jlong jlevel_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	float *level = 0;
	if(jlevel) {
		level = (float *)((char *)jenv->GetDirectBufferAddress(jlevel)+jlevel_);
	}

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->get3DPanLevel(level);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1getDSPHead(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jdsp) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	FMOD::DSP *dsp;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->getDSPHead(&dsp);

	if(dsp && jdsp) {
		jlong newAddress = 0;
		*(FMOD::DSP **)&newAddress = dsp;
		setPointerAddress(jenv, jdsp, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1addDSP(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jdsp) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	FMOD::DSP *dsp = *(FMOD::DSP **)&jdsp;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->addDSP(dsp);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1isPlaying(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jisplaying, jlong jisplaying_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	bool *isplaying =  0;
	if(jisplaying) {
		isplaying = (bool *)((char *)jenv->GetDirectBufferAddress(jisplaying)+jisplaying_);
	}

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->isPlaying(isplaying);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1isVirtual(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jisvirtual, jlong jisvirtual_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	bool *isvirtual =  0;
	if(jisvirtual) {
		isvirtual = (bool *)((char *)jenv->GetDirectBufferAddress(jisvirtual)+jisvirtual_);
	}

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->isVirtual(isvirtual);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1getAudibility(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jaudibility, jlong jaudibility_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	float *audibility = 0;
	if(jaudibility) {
		audibility = (float *)((char *)jenv->GetDirectBufferAddress(jaudibility)+jaudibility_);
	}

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->getAudibility(audibility);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1getCurrentSound(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jsound) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	FMOD::Sound *sound;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->getCurrentSound(&sound);

	if(sound && jsound) {
		jlong newAddress = 0;
		*(FMOD::Sound **)&newAddress = sound;
		setPointerAddress(jenv, jsound, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1getSpectrum(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jspectrumarray, jlong jspectrumarray_, jint jnumvalues, jint jchanneloffset, jint jwindowtype) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	float *spectrumarray = 0;
	if(jspectrumarray) {
		spectrumarray = (float *)((char *)jenv->GetDirectBufferAddress(jspectrumarray)+jspectrumarray_);
	}
	int numvalues = (int)jnumvalues;
	int channeloffset = (int)jchanneloffset;
	FMOD_DSP_FFT_WINDOW windowtype = (FMOD_DSP_FFT_WINDOW)jwindowtype;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->getSpectrum(spectrumarray, numvalues, channeloffset, windowtype);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1getWaveData(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jwavearray, jlong jwavearray_, jint jnumvalues, jint jchanneloffset) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	float *wavearray = 0;
	if(jwavearray) {
		wavearray = (float *)((char *)jenv->GetDirectBufferAddress(jwavearray)+jwavearray_);
	}
	int numvalues = (int)jnumvalues;
	int channeloffset = (int)jchanneloffset;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->getWaveData(wavearray, numvalues, channeloffset);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1getIndex(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jindex, jlong jindex_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	int *index = 0;
	if(jindex) {
		index = (int *)((char *)jenv->GetDirectBufferAddress(jindex)+jindex_);
	}

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->getIndex(index);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1setMode(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jmode) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	FMOD_MODE mode = (FMOD_MODE)jmode;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->setMode(mode);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1getMode(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jmode, jlong jmode_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	FMOD_MODE *mode = 0;
	if(jmode) {
		mode = (FMOD_MODE *)(int *)((char *)jenv->GetDirectBufferAddress(jmode)+jmode_);
	}

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->getMode(mode);

	jobject jresult = 0;
	if(result_) {
		jresult = jenv->NewDirectByteBuffer((FMOD_MODE *)(int *)result_, (jlong)-1);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1setLoopCount(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jloopcount) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	int loopcount = (int)jloopcount;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->setLoopCount(loopcount);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1getLoopCount(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jloopcount, jlong jloopcount_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	int *loopcount = 0;
	if(jloopcount) {
		loopcount = (int *)((char *)jenv->GetDirectBufferAddress(jloopcount)+jloopcount_);
	}

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->getLoopCount(loopcount);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1setLoopPoints(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jloopstart, jint jloopstarttype, jint jloopend, jint jloopendtype) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	int loopstart = (int)jloopstart;
	FMOD_TIMEUNIT loopstarttype = (FMOD_TIMEUNIT)jloopstarttype;
	int loopend = (int)jloopend;
	FMOD_TIMEUNIT loopendtype = (FMOD_TIMEUNIT)jloopendtype;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->setLoopPoints(loopstart, loopstarttype, loopend, loopendtype);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1getLoopPoints(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jloopstart, jlong jloopstart_, jint jloopstarttype, jobject jloopend, jlong jloopend_, jint jloopendtype) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	unsigned int *loopstart = 0;
	if(jloopstart) {
		loopstart = (unsigned int *)((char *)jenv->GetDirectBufferAddress(jloopstart)+jloopstart_);
	}
	FMOD_TIMEUNIT loopstarttype = (FMOD_TIMEUNIT)jloopstarttype;
	unsigned int *loopend = 0;
	if(jloopend) {
		loopend = (unsigned int *)((char *)jenv->GetDirectBufferAddress(jloopend)+jloopend_);
	}
	FMOD_TIMEUNIT loopendtype = (FMOD_TIMEUNIT)jloopendtype;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->getLoopPoints(loopstart, loopstarttype, loopend, loopendtype);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1setUserData(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong juserdata) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	void *userdata = *(void **)&juserdata;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->setUserData(userdata);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Channel_1getUserData(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject juserdata) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNEL);
		return 0;
	}
	void *userdata;

	FMOD_RESULT result_ = (*(FMOD::Channel **)&jPointer)->getUserData(&userdata);

	if(userdata && juserdata) {
		jlong newAddress;
		*(void **)&newAddress = userdata;
		setPointerAddress(jenv, juserdata, newAddress);
	}
	return (jint)result_;
}


