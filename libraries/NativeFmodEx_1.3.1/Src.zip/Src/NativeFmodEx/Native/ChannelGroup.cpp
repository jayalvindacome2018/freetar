/**
 * 							NativeFmodEx Project
 *
 * Do you want to use FMOD Ex API (www.fmod.org) with the Java language ? I've created NativeFmodEx for you.
 * Copyright � 2005-2006 J�r�me JOUVIE (Jouvieje)
 *
 * Created on 23 feb. 2005
 * @version file v1.0.0
 * @author J�r�me JOUVIE (Jouvieje)
 * 
 * 
 * WANT TO CONTACT ME ?
 * E-mail :
 * 		jerome.jouvie@gmail.com
 * My web sites :
 * 		http://jerome.jouvie.free.fr/
 * 		http://topresult.tomato.co.uk/~jerome/
 * 
 * 
 * INTRODUCTION
 * FMOD Ex is an API (Application Programming Interface) that allow you to use music
 * and creating sound effects with a lot of sort of musics.
 * FMOD is at :
 * 		http://www.fmod.org/
 * The reason of this project is that FMOD Ex can't be used direcly with Java, so I've created
 * this project to do this.
 * 
 * 
 * GNU LESSER GENERAL PUBLIC LICENSE
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of the License,
 * or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA 
 */
#include "Utils.h"
#include "Pointer.h"
#include "fmod.h"
#include "fmod.hpp"
#include "fmod_codec.h"
#include "fmod_dsp.h"
#include "fmod_output.h"
#include "org_jouvieje_FmodEx_FmodExJNI.h"
#include "CallbackManager.h"

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_ChannelGroup_1release(JNIEnv *jenv, jclass jcls, jlong jPointer) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNELGROUP);
		return 0;
	}

	FMOD_RESULT result_ = (*(FMOD::ChannelGroup **)&jPointer)->release();

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_ChannelGroup_1getSystemObject(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jsystem) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNELGROUP);
		return 0;
	}
	FMOD::System *system;

	FMOD_RESULT result_ = (*(FMOD::ChannelGroup **)&jPointer)->getSystemObject(&system);

	if(system && jsystem) {
		jlong newAddress = 0;
		*(FMOD::System **)&newAddress = system;
		setPointerAddress(jenv, jsystem, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_ChannelGroup_1setVolume(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jvolume) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNELGROUP);
		return 0;
	}
	float volume = (float)jvolume;

	FMOD_RESULT result_ = (*(FMOD::ChannelGroup **)&jPointer)->setVolume(volume);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_ChannelGroup_1getVolume(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jvolume, jlong jvolume_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNELGROUP);
		return 0;
	}
	float *volume = 0;
	if(jvolume) {
		volume = (float *)((char *)jenv->GetDirectBufferAddress(jvolume)+jvolume_);
	}

	FMOD_RESULT result_ = (*(FMOD::ChannelGroup **)&jPointer)->getVolume(volume);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_ChannelGroup_1setPitch(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jpitch) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNELGROUP);
		return 0;
	}
	float pitch = (float)jpitch;

	FMOD_RESULT result_ = (*(FMOD::ChannelGroup **)&jPointer)->setPitch(pitch);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_ChannelGroup_1getPitch(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jpitch, jlong jpitch_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNELGROUP);
		return 0;
	}
	float *pitch = 0;
	if(jpitch) {
		pitch = (float *)((char *)jenv->GetDirectBufferAddress(jpitch)+jpitch_);
	}

	FMOD_RESULT result_ = (*(FMOD::ChannelGroup **)&jPointer)->getPitch(pitch);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_ChannelGroup_1stop(JNIEnv *jenv, jclass jcls, jlong jPointer) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNELGROUP);
		return 0;
	}

	FMOD_RESULT result_ = (*(FMOD::ChannelGroup **)&jPointer)->stop();

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_ChannelGroup_1overridePaused(JNIEnv *jenv, jclass jcls, jlong jPointer, jboolean jpaused) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNELGROUP);
		return 0;
	}
	bool paused = (bool)(jpaused != 0);

	FMOD_RESULT result_ = (*(FMOD::ChannelGroup **)&jPointer)->overridePaused(paused);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_ChannelGroup_1overrideVolume(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jvolume) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNELGROUP);
		return 0;
	}
	float volume = (float)jvolume;

	FMOD_RESULT result_ = (*(FMOD::ChannelGroup **)&jPointer)->overrideVolume(volume);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_ChannelGroup_1overrideFrequency(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jfrequency) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNELGROUP);
		return 0;
	}
	float frequency = (float)jfrequency;

	FMOD_RESULT result_ = (*(FMOD::ChannelGroup **)&jPointer)->overrideFrequency(frequency);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_ChannelGroup_1overridePan(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jpan) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNELGROUP);
		return 0;
	}
	float pan = (float)jpan;

	FMOD_RESULT result_ = (*(FMOD::ChannelGroup **)&jPointer)->overridePan(pan);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_ChannelGroup_1overrideMute(JNIEnv *jenv, jclass jcls, jlong jPointer, jboolean jmute) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNELGROUP);
		return 0;
	}
	bool mute = (bool)(jmute != 0);

	FMOD_RESULT result_ = (*(FMOD::ChannelGroup **)&jPointer)->overrideMute(mute);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_ChannelGroup_1overrideReverbProperties(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jprop) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNELGROUP);
		return 0;
	}
	FMOD_REVERB_CHANNELPROPERTIES *prop = *(FMOD_REVERB_CHANNELPROPERTIES **)&jprop;

	FMOD_RESULT result_ = (*(FMOD::ChannelGroup **)&jPointer)->overrideReverbProperties(prop);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_ChannelGroup_1override3DAttributes(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jpos, jlong jvel) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNELGROUP);
		return 0;
	}
	FMOD_VECTOR *pos = *(FMOD_VECTOR **)&jpos;
	FMOD_VECTOR *vel = *(FMOD_VECTOR **)&jvel;

	FMOD_RESULT result_ = (*(FMOD::ChannelGroup **)&jPointer)->override3DAttributes(pos, vel);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_ChannelGroup_1overrideSpeakerMix(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jfrontleft, jfloat jfrontright, jfloat jcenter, jfloat jlfe, jfloat jbackleft, jfloat jbackright, jfloat jsideleft, jfloat jsideright) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNELGROUP);
		return 0;
	}
	float frontleft = (float)jfrontleft;
	float frontright = (float)jfrontright;
	float center = (float)jcenter;
	float lfe = (float)jlfe;
	float backleft = (float)jbackleft;
	float backright = (float)jbackright;
	float sideleft = (float)jsideleft;
	float sideright = (float)jsideright;

	FMOD_RESULT result_ = (*(FMOD::ChannelGroup **)&jPointer)->overrideSpeakerMix(frontleft, frontright, center, lfe, backleft, backright, sideleft, sideright);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_ChannelGroup_1addGroup(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jgroup) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNELGROUP);
		return 0;
	}
	FMOD::ChannelGroup *group = *(FMOD::ChannelGroup **)&jgroup;

	FMOD_RESULT result_ = (*(FMOD::ChannelGroup **)&jPointer)->addGroup(group);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_ChannelGroup_1getNumGroups(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jnumgroups, jlong jnumgroups_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNELGROUP);
		return 0;
	}
	int *numgroups = 0;
	if(jnumgroups) {
		numgroups = (int *)((char *)jenv->GetDirectBufferAddress(jnumgroups)+jnumgroups_);
	}

	FMOD_RESULT result_ = (*(FMOD::ChannelGroup **)&jPointer)->getNumGroups(numgroups);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_ChannelGroup_1getGroup(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jobject jgroup) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNELGROUP);
		return 0;
	}
	int index = (int)jindex;
	FMOD::ChannelGroup *group;

	FMOD_RESULT result_ = (*(FMOD::ChannelGroup **)&jPointer)->getGroup(index, &group);

	if(group && jgroup) {
		jlong newAddress = 0;
		*(FMOD::ChannelGroup **)&newAddress = group;
		setPointerAddress(jenv, jgroup, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_ChannelGroup_1getDSPHead(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jdsp) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNELGROUP);
		return 0;
	}
	FMOD::DSP *dsp;

	FMOD_RESULT result_ = (*(FMOD::ChannelGroup **)&jPointer)->getDSPHead(&dsp);

	if(dsp && jdsp) {
		jlong newAddress = 0;
		*(FMOD::DSP **)&newAddress = dsp;
		setPointerAddress(jenv, jdsp, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_ChannelGroup_1addDSP(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jdsp) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNELGROUP);
		return 0;
	}
	FMOD::DSP *dsp = *(FMOD::DSP **)&jdsp;

	FMOD_RESULT result_ = (*(FMOD::ChannelGroup **)&jPointer)->addDSP(dsp);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_ChannelGroup_1getName(JNIEnv *jenv, jclass jcls, jlong jPointer, 	jobject jname, jlong jname_, jint jnamelen) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNELGROUP);
		return 0;
	}
	char *name = 0;
	if(jname) {
		name = (char *)jenv->GetDirectBufferAddress(jname)+jname_;
	}
	int namelen = (int)jnamelen;

	FMOD_RESULT result_ = (*(FMOD::ChannelGroup **)&jPointer)->getName(name, namelen);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_ChannelGroup_1getNumChannels(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jnumchannels, jlong jnumchannels_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNELGROUP);
		return 0;
	}
	int *numchannels = 0;
	if(jnumchannels) {
		numchannels = (int *)((char *)jenv->GetDirectBufferAddress(jnumchannels)+jnumchannels_);
	}

	FMOD_RESULT result_ = (*(FMOD::ChannelGroup **)&jPointer)->getNumChannels(numchannels);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_ChannelGroup_1getChannel(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jobject jchannel) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNELGROUP);
		return 0;
	}
	int index = (int)jindex;
	FMOD::Channel *channel;

	FMOD_RESULT result_ = (*(FMOD::ChannelGroup **)&jPointer)->getChannel(index, &channel);

	if(channel && jchannel) {
		jlong newAddress = 0;
		*(FMOD::Channel **)&newAddress = channel;
		setPointerAddress(jenv, jchannel, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_ChannelGroup_1getSpectrum(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jspectrumarray, jlong jspectrumarray_, jint jnumvalues, jint jchanneloffset, jint jwindowtype) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNELGROUP);
		return 0;
	}
	float *spectrumarray = 0;
	if(jspectrumarray) {
		spectrumarray = (float *)((char *)jenv->GetDirectBufferAddress(jspectrumarray)+jspectrumarray_);
	}
	int numvalues = (int)jnumvalues;
	int channeloffset = (int)jchanneloffset;
	FMOD_DSP_FFT_WINDOW windowtype = (FMOD_DSP_FFT_WINDOW)jwindowtype;

	FMOD_RESULT result_ = (*(FMOD::ChannelGroup **)&jPointer)->getSpectrum(spectrumarray, numvalues, channeloffset, windowtype);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_ChannelGroup_1getWaveData(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jwavearray, jlong jwavearray_, jint jnumvalues, jint jchanneloffset) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNELGROUP);
		return 0;
	}
	float *wavearray = 0;
	if(jwavearray) {
		wavearray = (float *)((char *)jenv->GetDirectBufferAddress(jwavearray)+jwavearray_);
	}
	int numvalues = (int)jnumvalues;
	int channeloffset = (int)jchanneloffset;

	FMOD_RESULT result_ = (*(FMOD::ChannelGroup **)&jPointer)->getWaveData(wavearray, numvalues, channeloffset);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_ChannelGroup_1setUserData(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong juserdata) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNELGROUP);
		return 0;
	}
	void *userdata = *(void **)&juserdata;

	FMOD_RESULT result_ = (*(FMOD::ChannelGroup **)&jPointer)->setUserData(userdata);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_ChannelGroup_1getUserData(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject juserdata) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_CHANNELGROUP);
		return 0;
	}
	void *userdata;

	FMOD_RESULT result_ = (*(FMOD::ChannelGroup **)&jPointer)->getUserData(&userdata);

	if(userdata && juserdata) {
		jlong newAddress;
		*(void **)&newAddress = userdata;
		setPointerAddress(jenv, juserdata, newAddress);
	}
	return (jint)result_;
}


