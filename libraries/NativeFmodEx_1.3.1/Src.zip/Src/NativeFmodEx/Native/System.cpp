/**
 * 							NativeFmodEx Project
 *
 * Do you want to use FMOD Ex API (www.fmod.org) with the Java language ? I've created NativeFmodEx for you.
 * Copyright � 2005-2006 J�r�me JOUVIE (Jouvieje)
 *
 * Created on 23 feb. 2005
 * @version file v1.0.0
 * @author J�r�me JOUVIE (Jouvieje)
 * 
 * 
 * WANT TO CONTACT ME ?
 * E-mail :
 * 		jerome.jouvie@gmail.com
 * My web sites :
 * 		http://jerome.jouvie.free.fr/
 * 		http://topresult.tomato.co.uk/~jerome/
 * 
 * 
 * INTRODUCTION
 * FMOD Ex is an API (Application Programming Interface) that allow you to use music
 * and creating sound effects with a lot of sort of musics.
 * FMOD is at :
 * 		http://www.fmod.org/
 * The reason of this project is that FMOD Ex can't be used direcly with Java, so I've created
 * this project to do this.
 * 
 * 
 * GNU LESSER GENERAL PUBLIC LICENSE
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of the License,
 * or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA 
 */
#include "Utils.h"
#include "Pointer.h"
#include "fmod.h"
#include "fmod.hpp"
#include "fmod_codec.h"
#include "fmod_dsp.h"
#include "fmod_output.h"
#include "org_jouvieje_FmodEx_FmodExJNI.h"
#include "CallbackManager.h"

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1release(JNIEnv *jenv, jclass jcls, jlong jPointer) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->release();

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1setOutput(JNIEnv *jenv, jclass jcls, jlong jPointer, jint joutput) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	FMOD_OUTPUTTYPE output = (FMOD_OUTPUTTYPE)joutput;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->setOutput(output);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getOutput(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject joutputPointer) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	FMOD_OUTPUTTYPE output;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getOutput(&output);

	if(joutputPointer) {
		int *outputPointer = (int *)jenv->GetDirectBufferAddress(joutputPointer);
		outputPointer[0] = output;
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getNumDrivers(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jnumdrivers, jlong jnumdrivers_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int *numdrivers = 0;
	if(jnumdrivers) {
		numdrivers = (int *)((char *)jenv->GetDirectBufferAddress(jnumdrivers)+jnumdrivers_);
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getNumDrivers(numdrivers);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getDriverName(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jid, 	jobject jname, jlong jname_, jint jnamelen) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int id = (int)jid;
	char *name = 0;
	if(jname) {
		name = (char *)jenv->GetDirectBufferAddress(jname)+jname_;
	}
	int namelen = (int)jnamelen;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getDriverName(id, name, namelen);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getDriverCaps(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jid, jobject jcaps, jlong jcaps_, jobject jminfrequency, jlong jminfrequency_, jobject jmaxfrequency, jlong jmaxfrequency_, jobject jcontrolpanelspeakermodePointer) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int id = (int)jid;
	FMOD_CAPS *caps = 0;
	if(jcaps) {
		caps = (FMOD_CAPS *)(int *)((char *)jenv->GetDirectBufferAddress(jcaps)+jcaps_);
	}
	int *minfrequency = 0;
	if(jminfrequency) {
		minfrequency = (int *)((char *)jenv->GetDirectBufferAddress(jminfrequency)+jminfrequency_);
	}
	int *maxfrequency = 0;
	if(jmaxfrequency) {
		maxfrequency = (int *)((char *)jenv->GetDirectBufferAddress(jmaxfrequency)+jmaxfrequency_);
	}
	FMOD_SPEAKERMODE controlpanelspeakermode;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getDriverCaps(id, caps, minfrequency, maxfrequency, &controlpanelspeakermode);

	jobject jresult = 0;
	if(result_) {
		jresult = jenv->NewDirectByteBuffer((FMOD_CAPS *)(int *)result_, (jlong)-1);
	}
	if(jcontrolpanelspeakermodePointer) {
		int *controlpanelspeakermodePointer = (int *)jenv->GetDirectBufferAddress(jcontrolpanelspeakermodePointer);
		controlpanelspeakermodePointer[0] = controlpanelspeakermode;
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1setDriver(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jdriver) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int driver = (int)jdriver;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->setDriver(driver);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getDriver(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jdriver, jlong jdriver_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int *driver = 0;
	if(jdriver) {
		driver = (int *)((char *)jenv->GetDirectBufferAddress(jdriver)+jdriver_);
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getDriver(driver);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1setHardwareChannels(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jmin2d, jint jmax2d, jint jmin3d, jint jmax3d) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int min2d = (int)jmin2d;
	int max2d = (int)jmax2d;
	int min3d = (int)jmin3d;
	int max3d = (int)jmax3d;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->setHardwareChannels(min2d, max2d, min3d, max3d);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getHardwareChannels(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jnum2d, jlong jnum2d_, jobject jnum3d, jlong jnum3d_, jobject jtotal, jlong jtotal_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int *num2d = 0;
	if(jnum2d) {
		num2d = (int *)((char *)jenv->GetDirectBufferAddress(jnum2d)+jnum2d_);
	}
	int *num3d = 0;
	if(jnum3d) {
		num3d = (int *)((char *)jenv->GetDirectBufferAddress(jnum3d)+jnum3d_);
	}
	int *total = 0;
	if(jtotal) {
		total = (int *)((char *)jenv->GetDirectBufferAddress(jtotal)+jtotal_);
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getHardwareChannels(num2d, num3d, total);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1setSoftwareChannels(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jnumsoftwarechannels) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int numsoftwarechannels = (int)jnumsoftwarechannels;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->setSoftwareChannels(numsoftwarechannels);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getSoftwareChannels(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jnumsoftwarechannels, jlong jnumsoftwarechannels_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int *numsoftwarechannels = 0;
	if(jnumsoftwarechannels) {
		numsoftwarechannels = (int *)((char *)jenv->GetDirectBufferAddress(jnumsoftwarechannels)+jnumsoftwarechannels_);
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getSoftwareChannels(numsoftwarechannels);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1setSoftwareFormat(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jsamplerate, jint jformat, jint jnumoutputchannels, jint jmaxinputchannels, jint jresamplemethod) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int samplerate = (int)jsamplerate;
	FMOD_SOUND_FORMAT format = (FMOD_SOUND_FORMAT)jformat;
	int numoutputchannels = (int)jnumoutputchannels;
	int maxinputchannels = (int)jmaxinputchannels;
	FMOD_DSP_RESAMPLER resamplemethod = (FMOD_DSP_RESAMPLER)jresamplemethod;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->setSoftwareFormat(samplerate, format, numoutputchannels, maxinputchannels, resamplemethod);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getSoftwareFormat(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jsamplerate, jlong jsamplerate_, jobject jformatPointer, jobject jnumoutputchannels, jlong jnumoutputchannels_, jobject jmaxinputchannels, jlong jmaxinputchannels_, jobject jresamplemethodPointer, jobject jbits, jlong jbits_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int *samplerate = 0;
	if(jsamplerate) {
		samplerate = (int *)((char *)jenv->GetDirectBufferAddress(jsamplerate)+jsamplerate_);
	}
	FMOD_SOUND_FORMAT format;
	int *numoutputchannels = 0;
	if(jnumoutputchannels) {
		numoutputchannels = (int *)((char *)jenv->GetDirectBufferAddress(jnumoutputchannels)+jnumoutputchannels_);
	}
	int *maxinputchannels = 0;
	if(jmaxinputchannels) {
		maxinputchannels = (int *)((char *)jenv->GetDirectBufferAddress(jmaxinputchannels)+jmaxinputchannels_);
	}
	FMOD_DSP_RESAMPLER resamplemethod;
	int *bits = 0;
	if(jbits) {
		bits = (int *)((char *)jenv->GetDirectBufferAddress(jbits)+jbits_);
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getSoftwareFormat(samplerate, &format, numoutputchannels, maxinputchannels, &resamplemethod, bits);

	if(jformatPointer) {
		int *formatPointer = (int *)jenv->GetDirectBufferAddress(jformatPointer);
		formatPointer[0] = format;
	}
	if(jresamplemethodPointer) {
		int *resamplemethodPointer = (int *)jenv->GetDirectBufferAddress(jresamplemethodPointer);
		resamplemethodPointer[0] = resamplemethod;
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1setDSPBufferSize(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jbufferlength, jint jnumbuffers) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int bufferlength = (int)jbufferlength;
	int numbuffers = (int)jnumbuffers;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->setDSPBufferSize(bufferlength, numbuffers);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getDSPBufferSize(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jbufferlength, jlong jbufferlength_, jobject jnumbuffers, jlong jnumbuffers_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	unsigned int *bufferlength = 0;
	if(jbufferlength) {
		bufferlength = (unsigned int *)((char *)jenv->GetDirectBufferAddress(jbufferlength)+jbufferlength_);
	}
	int *numbuffers = 0;
	if(jnumbuffers) {
		numbuffers = (int *)((char *)jenv->GetDirectBufferAddress(jnumbuffers)+jnumbuffers_);
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getDSPBufferSize(bufferlength, numbuffers);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1setFileSystem(JNIEnv *jenv, jclass jcls, jlong jPointer, jboolean juseropen, jboolean juserclose, jboolean juserread, jboolean juserseek, jint jblocksize) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int blocksize = (int)jblocksize;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->setFileSystem(juseropen == 0 ? NULL : FMOD_FILE_OPENCALLBACK_BRIDGE, juserclose == 0 ? NULL : FMOD_FILE_CLOSECALLBACK_BRIDGE, juserread == 0 ? NULL : FMOD_FILE_READCALLBACK_BRIDGE, juserseek == 0 ? NULL : FMOD_FILE_SEEKCALLBACK_BRIDGE, blocksize);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1attachFileSystem(JNIEnv *jenv, jclass jcls, jlong jPointer, jboolean juseropen, jboolean juserclose, jboolean juserread, jboolean juserseek) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->attachFileSystem(juseropen == 0 ? NULL : FMOD_FILE_OPENCALLBACK_BRIDGE, juserclose == 0 ? NULL : FMOD_FILE_CLOSECALLBACK_BRIDGE, juserread == 0 ? NULL : FMOD_FILE_READCALLBACK_BRIDGE, juserseek == 0 ? NULL : FMOD_FILE_SEEKCALLBACK_BRIDGE);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1setAdvancedSettings(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jsettings) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	FMOD_ADVANCEDSETTINGS *settings = *(FMOD_ADVANCEDSETTINGS **)&jsettings;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->setAdvancedSettings(settings);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getAdvancedSettings(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jsettings) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	FMOD_ADVANCEDSETTINGS *settings = *(FMOD_ADVANCEDSETTINGS **)&jsettings;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getAdvancedSettings(settings);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1setSpeakerMode(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jspeakermode) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	FMOD_SPEAKERMODE speakermode = (FMOD_SPEAKERMODE)jspeakermode;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->setSpeakerMode(speakermode);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getSpeakerMode(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jspeakermodePointer) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	FMOD_SPEAKERMODE speakermode;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getSpeakerMode(&speakermode);

	if(jspeakermodePointer) {
		int *speakermodePointer = (int *)jenv->GetDirectBufferAddress(jspeakermodePointer);
		speakermodePointer[0] = speakermode;
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1setPluginPath(JNIEnv *jenv, jclass jcls, jlong jPointer, jbyteArray jpath) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	char *path = getByteArrayElements(jenv, jpath);

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->setPluginPath(path);

	releaseByteArrayElements(jenv, jpath, (const char *)path);
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1loadPlugin(JNIEnv *jenv, jclass jcls, jlong jPointer, jbyteArray jfilename, jobject jplugintypePointer, jobject jindex, jlong jindex_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	char *filename = getByteArrayElements(jenv, jfilename);
	FMOD_PLUGINTYPE plugintype;
	int *index = 0;
	if(jindex) {
		index = (int *)((char *)jenv->GetDirectBufferAddress(jindex)+jindex_);
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->loadPlugin(filename, &plugintype, index);

	releaseByteArrayElements(jenv, jfilename, (const char *)filename);
	if(jplugintypePointer) {
		int *plugintypePointer = (int *)jenv->GetDirectBufferAddress(jplugintypePointer);
		plugintypePointer[0] = plugintype;
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getNumPlugins(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jplugintype, jobject jnumplugins, jlong jnumplugins_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	FMOD_PLUGINTYPE plugintype = (FMOD_PLUGINTYPE)jplugintype;
	int *numplugins = 0;
	if(jnumplugins) {
		numplugins = (int *)((char *)jenv->GetDirectBufferAddress(jnumplugins)+jnumplugins_);
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getNumPlugins(plugintype, numplugins);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getPluginInfo(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jplugintype, jint jindex, 	jobject jname, jlong jname_, jint jnamelen, jobject jversion, jlong jversion_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	FMOD_PLUGINTYPE plugintype = (FMOD_PLUGINTYPE)jplugintype;
	int index = (int)jindex;
	char *name = 0;
	if(jname) {
		name = (char *)jenv->GetDirectBufferAddress(jname)+jname_;
	}
	int namelen = (int)jnamelen;
	unsigned int *version = 0;
	if(jversion) {
		version = (unsigned int *)((char *)jenv->GetDirectBufferAddress(jversion)+jversion_);
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getPluginInfo(plugintype, index, name, namelen, version);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1unloadPlugin(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jplugintype, jint jindex) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	FMOD_PLUGINTYPE plugintype = (FMOD_PLUGINTYPE)jplugintype;
	int index = (int)jindex;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->unloadPlugin(plugintype, index);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1setOutputByPlugin(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int index = (int)jindex;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->setOutputByPlugin(index);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getOutputByPlugin(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jindex, jlong jindex_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int *index = 0;
	if(jindex) {
		index = (int *)((char *)jenv->GetDirectBufferAddress(jindex)+jindex_);
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getOutputByPlugin(index);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1createCodec(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jdescription) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	FMOD_CODEC_DESCRIPTION *description = *(FMOD_CODEC_DESCRIPTION **)&jdescription;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->createCodec(description);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1init(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jmaxchannels, jint jflags, jlong jextradriverdata) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int maxchannels = (int)jmaxchannels;
	FMOD_INITFLAGS flags = (FMOD_INITFLAGS)jflags;
	void *extradriverdata = *(void **)&jextradriverdata;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->init(maxchannels, flags, extradriverdata);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1close(JNIEnv *jenv, jclass jcls, jlong jPointer) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->close();

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1update(JNIEnv *jenv, jclass jcls, jlong jPointer) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->update();

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1set3DSettings(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jdopplerscale, jfloat jdistancefactor, jfloat jrolloffscale) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	float dopplerscale = (float)jdopplerscale;
	float distancefactor = (float)jdistancefactor;
	float rolloffscale = (float)jrolloffscale;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->set3DSettings(dopplerscale, distancefactor, rolloffscale);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1get3DSettings(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jdopplerscale, jlong jdopplerscale_, jobject jdistancefactor, jlong jdistancefactor_, jobject jrolloffscale, jlong jrolloffscale_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	float *dopplerscale = 0;
	if(jdopplerscale) {
		dopplerscale = (float *)((char *)jenv->GetDirectBufferAddress(jdopplerscale)+jdopplerscale_);
	}
	float *distancefactor = 0;
	if(jdistancefactor) {
		distancefactor = (float *)((char *)jenv->GetDirectBufferAddress(jdistancefactor)+jdistancefactor_);
	}
	float *rolloffscale = 0;
	if(jrolloffscale) {
		rolloffscale = (float *)((char *)jenv->GetDirectBufferAddress(jrolloffscale)+jrolloffscale_);
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->get3DSettings(dopplerscale, distancefactor, rolloffscale);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1set3DNumListeners(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jnumlisteners) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int numlisteners = (int)jnumlisteners;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->set3DNumListeners(numlisteners);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1get3DNumListeners(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jnumlisteners, jlong jnumlisteners_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int *numlisteners = 0;
	if(jnumlisteners) {
		numlisteners = (int *)((char *)jenv->GetDirectBufferAddress(jnumlisteners)+jnumlisteners_);
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->get3DNumListeners(numlisteners);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1set3DListenerAttributes(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jlistener, jlong jpos, jlong jvel, jlong jforward, jlong jup) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int listener = (int)jlistener;
	FMOD_VECTOR *pos = *(FMOD_VECTOR **)&jpos;
	FMOD_VECTOR *vel = *(FMOD_VECTOR **)&jvel;
	FMOD_VECTOR *forward = *(FMOD_VECTOR **)&jforward;
	FMOD_VECTOR *up = *(FMOD_VECTOR **)&jup;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->set3DListenerAttributes(listener, pos, vel, forward, up);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1get3DListenerAttributes(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jlistener, jlong jpos, jlong jvel, jlong jforward, jlong jup) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int listener = (int)jlistener;
	FMOD_VECTOR *pos = *(FMOD_VECTOR **)&jpos;
	FMOD_VECTOR *vel = *(FMOD_VECTOR **)&jvel;
	FMOD_VECTOR *forward = *(FMOD_VECTOR **)&jforward;
	FMOD_VECTOR *up = *(FMOD_VECTOR **)&jup;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->get3DListenerAttributes(listener, pos, vel, forward, up);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1setSpeakerPosition(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jspeaker, jfloat jx, jfloat jy) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	FMOD_SPEAKER speaker = (FMOD_SPEAKER)jspeaker;
	float x = (float)jx;
	float y = (float)jy;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->setSpeakerPosition(speaker, x, y);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getSpeakerPosition(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jspeaker, jobject jx, jlong jx_, jobject jy, jlong jy_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	FMOD_SPEAKER speaker = (FMOD_SPEAKER)jspeaker;
	float *x = 0;
	if(jx) {
		x = (float *)((char *)jenv->GetDirectBufferAddress(jx)+jx_);
	}
	float *y = 0;
	if(jy) {
		y = (float *)((char *)jenv->GetDirectBufferAddress(jy)+jy_);
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getSpeakerPosition(speaker, x, y);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1setStreamBufferSize(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jfilebuffersize, jint jfilebuffersizetype) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int filebuffersize = (int)jfilebuffersize;
	FMOD_TIMEUNIT filebuffersizetype = (FMOD_TIMEUNIT)jfilebuffersizetype;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->setStreamBufferSize(filebuffersize, filebuffersizetype);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getStreamBufferSize(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jfilebuffersize, jlong jfilebuffersize_, jobject jfilebuffersizetype, jlong jfilebuffersizetype_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	unsigned int *filebuffersize = 0;
	if(jfilebuffersize) {
		filebuffersize = (unsigned int *)((char *)jenv->GetDirectBufferAddress(jfilebuffersize)+jfilebuffersize_);
	}
	FMOD_TIMEUNIT *filebuffersizetype = 0;
	if(jfilebuffersizetype) {
		filebuffersizetype = (FMOD_TIMEUNIT *)(int *)((char *)jenv->GetDirectBufferAddress(jfilebuffersizetype)+jfilebuffersizetype_);
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getStreamBufferSize(filebuffersize, filebuffersizetype);

	jobject jresult = 0;
	if(result_) {
		jresult = jenv->NewDirectByteBuffer((FMOD_TIMEUNIT *)(int *)result_, (jlong)-1);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getVersion(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jversion, jlong jversion_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	unsigned int *version = 0;
	if(jversion) {
		version = (unsigned int *)((char *)jenv->GetDirectBufferAddress(jversion)+jversion_);
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getVersion(version);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getOutputHandle(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jhandle) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	void *handle;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getOutputHandle(&handle);

	if(handle && jhandle) {
		jlong newAddress;
		*(void **)&newAddress = handle;
		setPointerAddress(jenv, jhandle, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getChannelsPlaying(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jchannels, jlong jchannels_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int *channels = 0;
	if(jchannels) {
		channels = (int *)((char *)jenv->GetDirectBufferAddress(jchannels)+jchannels_);
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getChannelsPlaying(channels);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getCPUUsage(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jdsp, jlong jdsp_, jobject jstream, jlong jstream_, jobject jupdate, jlong jupdate_, jobject jtotal, jlong jtotal_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	float *dsp = 0;
	if(jdsp) {
		dsp = (float *)((char *)jenv->GetDirectBufferAddress(jdsp)+jdsp_);
	}
	float *stream = 0;
	if(jstream) {
		stream = (float *)((char *)jenv->GetDirectBufferAddress(jstream)+jstream_);
	}
	float *update = 0;
	if(jupdate) {
		update = (float *)((char *)jenv->GetDirectBufferAddress(jupdate)+jupdate_);
	}
	float *total = 0;
	if(jtotal) {
		total = (float *)((char *)jenv->GetDirectBufferAddress(jtotal)+jtotal_);
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getCPUUsage(dsp, stream, update, total);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getSoundRAM(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jcurrentalloced, jlong jcurrentalloced_, jobject jmaxalloced, jlong jmaxalloced_, jobject jtotal, jlong jtotal_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int *currentalloced = 0;
	if(jcurrentalloced) {
		currentalloced = (int *)((char *)jenv->GetDirectBufferAddress(jcurrentalloced)+jcurrentalloced_);
	}
	int *maxalloced = 0;
	if(jmaxalloced) {
		maxalloced = (int *)((char *)jenv->GetDirectBufferAddress(jmaxalloced)+jmaxalloced_);
	}
	int *total = 0;
	if(jtotal) {
		total = (int *)((char *)jenv->GetDirectBufferAddress(jtotal)+jtotal_);
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getSoundRAM(currentalloced, maxalloced, total);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getNumCDROMDrives(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jnumdrives, jlong jnumdrives_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int *numdrives = 0;
	if(jnumdrives) {
		numdrives = (int *)((char *)jenv->GetDirectBufferAddress(jnumdrives)+jnumdrives_);
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getNumCDROMDrives(numdrives);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getCDROMDriveName(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jdrive, 	jobject jdrivename, jlong jdrivename_, jint jdrivenamelen, 	jobject jscsiname, jlong jscsiname_, jint jscsinamelen, 	jobject jdevicename, jlong jdevicename_, jint jdevicenamelen) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int drive = (int)jdrive;
	char *drivename = 0;
	if(jdrivename) {
		drivename = (char *)jenv->GetDirectBufferAddress(jdrivename)+jdrivename_;
	}
	int drivenamelen = (int)jdrivenamelen;
	char *scsiname = 0;
	if(jscsiname) {
		scsiname = (char *)jenv->GetDirectBufferAddress(jscsiname)+jscsiname_;
	}
	int scsinamelen = (int)jscsinamelen;
	char *devicename = 0;
	if(jdevicename) {
		devicename = (char *)jenv->GetDirectBufferAddress(jdevicename)+jdevicename_;
	}
	int devicenamelen = (int)jdevicenamelen;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getCDROMDriveName(drive, drivename, drivenamelen, scsiname, scsinamelen, devicename, devicenamelen);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getSpectrum(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jspectrumarray, jlong jspectrumarray_, jint jnumvalues, jint jchanneloffset, jint jwindowtype) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	float *spectrumarray = 0;
	if(jspectrumarray) {
		spectrumarray = (float *)((char *)jenv->GetDirectBufferAddress(jspectrumarray)+jspectrumarray_);
	}
	int numvalues = (int)jnumvalues;
	int channeloffset = (int)jchanneloffset;
	FMOD_DSP_FFT_WINDOW windowtype = (FMOD_DSP_FFT_WINDOW)jwindowtype;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getSpectrum(spectrumarray, numvalues, channeloffset, windowtype);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getWaveData(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jwavearray, jlong jwavearray_, jint jnumvalues, jint jchanneloffset) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	float *wavearray = 0;
	if(jwavearray) {
		wavearray = (float *)((char *)jenv->GetDirectBufferAddress(jwavearray)+jwavearray_);
	}
	int numvalues = (int)jnumvalues;
	int channeloffset = (int)jchanneloffset;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getWaveData(wavearray, numvalues, channeloffset);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1createSound__J_3BIJLorg_jouvieje_FmodEx_Sound_2(JNIEnv *jenv, jclass jcls, jlong jPointer, jbyteArray jname_or_data, jint jmode, jlong jexinfo, jobject jsound) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	char *name_or_data = getByteArrayElements(jenv, jname_or_data);
	FMOD_MODE mode = (FMOD_MODE)jmode;
	FMOD_CREATESOUNDEXINFO *exinfo = *(FMOD_CREATESOUNDEXINFO **)&jexinfo;
	FMOD::Sound *sound;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->createSound(name_or_data, mode, exinfo, &sound);

	releaseByteArrayElements(jenv, jname_or_data, (const char *)name_or_data);
	if(sound && jsound) {
		jlong newAddress = 0;
		*(FMOD::Sound **)&newAddress = sound;
		setPointerAddress(jenv, jsound, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1createSound__JLjava_nio_ByteBuffer_2JIJLorg_jouvieje_FmodEx_Sound_2(JNIEnv *jenv, jclass jcls, jlong jPointer, 	jobject jname_or_data, jlong jname_or_data_, jint jmode, jlong jexinfo, jobject jsound) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	char *name_or_data = 0;
	if(jname_or_data) {
		name_or_data = (char *)jenv->GetDirectBufferAddress(jname_or_data)+jname_or_data_;
	}
	FMOD_MODE mode = (FMOD_MODE)jmode;
	FMOD_CREATESOUNDEXINFO *exinfo = *(FMOD_CREATESOUNDEXINFO **)&jexinfo;
	FMOD::Sound *sound;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->createSound(name_or_data, mode, exinfo, &sound);

	if(sound && jsound) {
		jlong newAddress = 0;
		*(FMOD::Sound **)&newAddress = sound;
		setPointerAddress(jenv, jsound, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1createStream__J_3BIJLorg_jouvieje_FmodEx_Sound_2(JNIEnv *jenv, jclass jcls, jlong jPointer, jbyteArray jname_or_data, jint jmode, jlong jexinfo, jobject jsound) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	char *name_or_data = getByteArrayElements(jenv, jname_or_data);
	FMOD_MODE mode = (FMOD_MODE)jmode;
	FMOD_CREATESOUNDEXINFO *exinfo = *(FMOD_CREATESOUNDEXINFO **)&jexinfo;
	FMOD::Sound *sound;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->createStream(name_or_data, mode, exinfo, &sound);

	releaseByteArrayElements(jenv, jname_or_data, (const char *)name_or_data);
	if(sound && jsound) {
		jlong newAddress = 0;
		*(FMOD::Sound **)&newAddress = sound;
		setPointerAddress(jenv, jsound, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1createStream__JLjava_nio_ByteBuffer_2JIJLorg_jouvieje_FmodEx_Sound_2(JNIEnv *jenv, jclass jcls, jlong jPointer, 	jobject jname_or_data, jlong jname_or_data_, jint jmode, jlong jexinfo, jobject jsound) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	char *name_or_data = 0;
	if(jname_or_data) {
		name_or_data = (char *)jenv->GetDirectBufferAddress(jname_or_data)+jname_or_data_;
	}
	FMOD_MODE mode = (FMOD_MODE)jmode;
	FMOD_CREATESOUNDEXINFO *exinfo = *(FMOD_CREATESOUNDEXINFO **)&jexinfo;
	FMOD::Sound *sound;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->createStream(name_or_data, mode, exinfo, &sound);

	if(sound && jsound) {
		jlong newAddress = 0;
		*(FMOD::Sound **)&newAddress = sound;
		setPointerAddress(jenv, jsound, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1createDSP(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jdescription, jobject jdsp) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	FMOD_DSP_DESCRIPTION *description = *(FMOD_DSP_DESCRIPTION **)&jdescription;
	FMOD::DSP *dsp;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->createDSP(description, &dsp);

	if(dsp && jdsp) {
		jlong newAddress = 0;
		*(FMOD::DSP **)&newAddress = dsp;
		setPointerAddress(jenv, jdsp, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1createDSPByType(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jtype, jobject jdsp) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	FMOD_DSP_TYPE type = (FMOD_DSP_TYPE)jtype;
	FMOD::DSP *dsp;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->createDSPByType(type, &dsp);

	if(dsp && jdsp) {
		jlong newAddress = 0;
		*(FMOD::DSP **)&newAddress = dsp;
		setPointerAddress(jenv, jdsp, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1createDSPByIndex(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jobject jdsp) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int index = (int)jindex;
	FMOD::DSP *dsp;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->createDSPByIndex(index, &dsp);

	if(dsp && jdsp) {
		jlong newAddress = 0;
		*(FMOD::DSP **)&newAddress = dsp;
		setPointerAddress(jenv, jdsp, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1createChannelGroup(JNIEnv *jenv, jclass jcls, jlong jPointer, jbyteArray jname, jobject jchannelgroup) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	char *name = getByteArrayElements(jenv, jname);
	FMOD::ChannelGroup *channelgroup;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->createChannelGroup(name, &channelgroup);

	releaseByteArrayElements(jenv, jname, (const char *)name);
	if(channelgroup && jchannelgroup) {
		jlong newAddress = 0;
		*(FMOD::ChannelGroup **)&newAddress = channelgroup;
		setPointerAddress(jenv, jchannelgroup, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1playSound(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jchannelid, jlong jsound, jboolean jpaused, jobject jchannel) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	FMOD_CHANNELINDEX channelid = (FMOD_CHANNELINDEX)jchannelid;
	FMOD::Sound *sound = *(FMOD::Sound **)&jsound;
	bool paused = (bool)(jpaused != 0);
	FMOD::Channel *channel;
	if(jchannel) {
		long jchannelAddress = getPointerAddress(jenv, jchannel);
		channel = *(FMOD::Channel **)&jchannelAddress;
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->playSound(channelid, sound, paused, &channel);

	if(channel && jchannel) {
		jlong newAddress = 0;
		*(FMOD::Channel **)&newAddress = channel;
		setPointerAddress(jenv, jchannel, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1playDSP(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jchannelid, jlong jdsp, jboolean jpaused, jobject jchannel) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	FMOD_CHANNELINDEX channelid = (FMOD_CHANNELINDEX)jchannelid;
	FMOD::DSP *dsp = *(FMOD::DSP **)&jdsp;
	bool paused = (bool)(jpaused != 0);
	FMOD::Channel *channel;
	if(jchannel) {
		long jchannelAddress = getPointerAddress(jenv, jchannel);
		channel = *(FMOD::Channel **)&jchannelAddress;
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->playDSP(channelid, dsp, paused, &channel);

	if(channel && jchannel) {
		jlong newAddress = 0;
		*(FMOD::Channel **)&newAddress = channel;
		setPointerAddress(jenv, jchannel, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getChannel(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jchannelid, jobject jchannel) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int channelid = (int)jchannelid;
	FMOD::Channel *channel;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getChannel(channelid, &channel);

	if(channel && jchannel) {
		jlong newAddress = 0;
		*(FMOD::Channel **)&newAddress = channel;
		setPointerAddress(jenv, jchannel, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getMasterChannelGroup(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jchannelgroup) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	FMOD::ChannelGroup *channelgroup;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getMasterChannelGroup(&channelgroup);

	if(channelgroup && jchannelgroup) {
		jlong newAddress = 0;
		*(FMOD::ChannelGroup **)&newAddress = channelgroup;
		setPointerAddress(jenv, jchannelgroup, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1setReverbProperties(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jprop) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	FMOD_REVERB_PROPERTIES *prop = *(FMOD_REVERB_PROPERTIES **)&jprop;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->setReverbProperties(prop);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getReverbProperties(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jprop) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	FMOD_REVERB_PROPERTIES *prop = *(FMOD_REVERB_PROPERTIES **)&jprop;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getReverbProperties(prop);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getDSPHead(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jdsp) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	FMOD::DSP *dsp;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getDSPHead(&dsp);

	if(dsp && jdsp) {
		jlong newAddress = 0;
		*(FMOD::DSP **)&newAddress = dsp;
		setPointerAddress(jenv, jdsp, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1addDSP(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jdsp) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	FMOD::DSP *dsp = *(FMOD::DSP **)&jdsp;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->addDSP(dsp);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1lockDSP(JNIEnv *jenv, jclass jcls, jlong jPointer) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->lockDSP();

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1unlockDSP(JNIEnv *jenv, jclass jcls, jlong jPointer) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->unlockDSP();

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1setRecordDriver(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jdriver) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int driver = (int)jdriver;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->setRecordDriver(driver);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getRecordDriver(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jdriver, jlong jdriver_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int *driver = 0;
	if(jdriver) {
		driver = (int *)((char *)jenv->GetDirectBufferAddress(jdriver)+jdriver_);
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getRecordDriver(driver);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getRecordNumDrivers(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jnumdrivers, jlong jnumdrivers_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int *numdrivers = 0;
	if(jnumdrivers) {
		numdrivers = (int *)((char *)jenv->GetDirectBufferAddress(jnumdrivers)+jnumdrivers_);
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getRecordNumDrivers(numdrivers);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getRecordDriverName(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jid, 	jobject jname, jlong jname_, jint jnamelen) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int id = (int)jid;
	char *name = 0;
	if(jname) {
		name = (char *)jenv->GetDirectBufferAddress(jname)+jname_;
	}
	int namelen = (int)jnamelen;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getRecordDriverName(id, name, namelen);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getRecordPosition(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jposition, jlong jposition_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	unsigned int *position = 0;
	if(jposition) {
		position = (unsigned int *)((char *)jenv->GetDirectBufferAddress(jposition)+jposition_);
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getRecordPosition(position);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1recordStart(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jsound, jboolean jloop) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	FMOD::Sound *sound = *(FMOD::Sound **)&jsound;
	bool loop = (bool)(jloop != 0);

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->recordStart(sound, loop);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1recordStop(JNIEnv *jenv, jclass jcls, jlong jPointer) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->recordStop();

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1isRecording(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jrecording, jlong jrecording_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	bool *recording =  0;
	if(jrecording) {
		recording = (bool *)((char *)jenv->GetDirectBufferAddress(jrecording)+jrecording_);
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->isRecording(recording);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1createGeometry(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jmaxpolygons, jint jmaxvertices, jobject jgeometry) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int maxpolygons = (int)jmaxpolygons;
	int maxvertices = (int)jmaxvertices;
	FMOD::Geometry *geometry;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->createGeometry(maxpolygons, maxvertices, &geometry);

	if(geometry && jgeometry) {
		jlong newAddress = 0;
		*(FMOD::Geometry **)&newAddress = geometry;
		setPointerAddress(jenv, jgeometry, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1setGeometrySettings(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jmaxworldsize) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	float maxworldsize = (float)jmaxworldsize;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->setGeometrySettings(maxworldsize);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getGeometrySettings(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jmaxworldsize, jlong jmaxworldsize_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	float *maxworldsize = 0;
	if(jmaxworldsize) {
		maxworldsize = (float *)((char *)jenv->GetDirectBufferAddress(jmaxworldsize)+jmaxworldsize_);
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getGeometrySettings(maxworldsize);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1loadGeometry(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jdata, jlong jdata_, jint jdatasize, jobject jgeometry) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	void *data = 0;
	if(jdata) {
		data = (void *)((char *)jenv->GetDirectBufferAddress(jdata)+jdata_);
	}
	int datasize = (int)jdatasize;
	FMOD::Geometry *geometry;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->loadGeometry(data, datasize, &geometry);

	if(geometry && jgeometry) {
		jlong newAddress = 0;
		*(FMOD::Geometry **)&newAddress = geometry;
		setPointerAddress(jenv, jgeometry, newAddress);
	}
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1setNetworkProxy(JNIEnv *jenv, jclass jcls, jlong jPointer, jbyteArray jproxy) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	char *proxy = getByteArrayElements(jenv, jproxy);

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->setNetworkProxy(proxy);

	releaseByteArrayElements(jenv, jproxy, (const char *)proxy);
	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getNetworkProxy(JNIEnv *jenv, jclass jcls, jlong jPointer, 	jobject jproxy, jlong jproxy_, jint jproxylen) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	char *proxy = 0;
	if(jproxy) {
		proxy = (char *)jenv->GetDirectBufferAddress(jproxy)+jproxy_;
	}
	int proxylen = (int)jproxylen;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getNetworkProxy(proxy, proxylen);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1setNetworkTimeout(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jtimeout) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int timeout = (int)jtimeout;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->setNetworkTimeout(timeout);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getNetworkTimeout(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jtimeout, jlong jtimeout_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	int *timeout = 0;
	if(jtimeout) {
		timeout = (int *)((char *)jenv->GetDirectBufferAddress(jtimeout)+jtimeout_);
	}

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getNetworkTimeout(timeout);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1setUserData(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong juserdata) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	void *userdata = *(void **)&juserdata;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->setUserData(userdata);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_System_1getUserData(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject juserdata) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_SYSTEM);
		return 0;
	}
	void *userdata;

	FMOD_RESULT result_ = (*(FMOD::System **)&jPointer)->getUserData(&userdata);

	if(userdata && juserdata) {
		jlong newAddress;
		*(void **)&newAddress = userdata;
		setPointerAddress(jenv, juserdata, newAddress);
	}
	return (jint)result_;
}


