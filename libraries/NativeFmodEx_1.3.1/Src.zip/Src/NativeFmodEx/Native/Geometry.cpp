/**
 * 							NativeFmodEx Project
 *
 * Do you want to use FMOD Ex API (www.fmod.org) with the Java language ? I've created NativeFmodEx for you.
 * Copyright � 2005-2006 J�r�me JOUVIE (Jouvieje)
 *
 * Created on 23 feb. 2005
 * @version file v1.0.0
 * @author J�r�me JOUVIE (Jouvieje)
 * 
 * 
 * WANT TO CONTACT ME ?
 * E-mail :
 * 		jerome.jouvie@gmail.com
 * My web sites :
 * 		http://jerome.jouvie.free.fr/
 * 		http://topresult.tomato.co.uk/~jerome/
 * 
 * 
 * INTRODUCTION
 * FMOD Ex is an API (Application Programming Interface) that allow you to use music
 * and creating sound effects with a lot of sort of musics.
 * FMOD is at :
 * 		http://www.fmod.org/
 * The reason of this project is that FMOD Ex can't be used direcly with Java, so I've created
 * this project to do this.
 * 
 * 
 * GNU LESSER GENERAL PUBLIC LICENSE
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public License
 * as published by the Free Software Foundation; either version 2.1 of the License,
 * or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the
 * Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330,
 * Boston, MA 02111-1307 USA 
 */
#include "Utils.h"
#include "Pointer.h"
#include "fmod.h"
#include "fmod.hpp"
#include "fmod_codec.h"
#include "fmod_dsp.h"
#include "fmod_output.h"
#include "org_jouvieje_FmodEx_FmodExJNI.h"
#include "CallbackManager.h"

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Geometry_1release(JNIEnv *jenv, jclass jcls, jlong jPointer) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_GEOMETRY);
		return 0;
	}

	FMOD_RESULT result_ = (*(FMOD::Geometry **)&jPointer)->release();

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Geometry_1addPolygon(JNIEnv *jenv, jclass jcls, jlong jPointer, jfloat jdirectocclusion, jfloat jreverbocclusion, jboolean jdoublesided, jint jnumvertices, jlong jvertices, jobject jpolygonindex, jlong jpolygonindex_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_GEOMETRY);
		return 0;
	}
	float directocclusion = (float)jdirectocclusion;
	float reverbocclusion = (float)jreverbocclusion;
	bool doublesided = (bool)(jdoublesided != 0);
	int numvertices = (int)jnumvertices;
	FMOD_VECTOR *vertices = *(FMOD_VECTOR **)&jvertices;
	int *polygonindex = 0;
	if(jpolygonindex) {
		polygonindex = (int *)((char *)jenv->GetDirectBufferAddress(jpolygonindex)+jpolygonindex_);
	}

	FMOD_RESULT result_ = (*(FMOD::Geometry **)&jPointer)->addPolygon(directocclusion, reverbocclusion, doublesided, numvertices, vertices, polygonindex);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Geometry_1getNumPolygons(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jnumpolygons, jlong jnumpolygons_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_GEOMETRY);
		return 0;
	}
	int *numpolygons = 0;
	if(jnumpolygons) {
		numpolygons = (int *)((char *)jenv->GetDirectBufferAddress(jnumpolygons)+jnumpolygons_);
	}

	FMOD_RESULT result_ = (*(FMOD::Geometry **)&jPointer)->getNumPolygons(numpolygons);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Geometry_1getMaxPolygons(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jmaxpolygons, jlong jmaxpolygons_, jobject jmaxvertices, jlong jmaxvertices_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_GEOMETRY);
		return 0;
	}
	int *maxpolygons = 0;
	if(jmaxpolygons) {
		maxpolygons = (int *)((char *)jenv->GetDirectBufferAddress(jmaxpolygons)+jmaxpolygons_);
	}
	int *maxvertices = 0;
	if(jmaxvertices) {
		maxvertices = (int *)((char *)jenv->GetDirectBufferAddress(jmaxvertices)+jmaxvertices_);
	}

	FMOD_RESULT result_ = (*(FMOD::Geometry **)&jPointer)->getMaxPolygons(maxpolygons, maxvertices);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Geometry_1getPolygonNumVertices(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jobject jnumvertices, jlong jnumvertices_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_GEOMETRY);
		return 0;
	}
	int index = (int)jindex;
	int *numvertices = 0;
	if(jnumvertices) {
		numvertices = (int *)((char *)jenv->GetDirectBufferAddress(jnumvertices)+jnumvertices_);
	}

	FMOD_RESULT result_ = (*(FMOD::Geometry **)&jPointer)->getPolygonNumVertices(index, numvertices);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Geometry_1setPolygonVertex(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jint jvertexindex, jlong jvertex) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_GEOMETRY);
		return 0;
	}
	int index = (int)jindex;
	int vertexindex = (int)jvertexindex;
	FMOD_VECTOR *vertex = *(FMOD_VECTOR **)&jvertex;

	FMOD_RESULT result_ = (*(FMOD::Geometry **)&jPointer)->setPolygonVertex(index, vertexindex, vertex);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Geometry_1getPolygonVertex(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jint jvertexindex, jlong jvertex) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_GEOMETRY);
		return 0;
	}
	int index = (int)jindex;
	int vertexindex = (int)jvertexindex;
	FMOD_VECTOR *vertex = *(FMOD_VECTOR **)&jvertex;

	FMOD_RESULT result_ = (*(FMOD::Geometry **)&jPointer)->getPolygonVertex(index, vertexindex, vertex);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Geometry_1setPolygonAttributes(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jfloat jdirectocclusion, jfloat jreverbocclusion, jboolean jdoublesided) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_GEOMETRY);
		return 0;
	}
	int index = (int)jindex;
	float directocclusion = (float)jdirectocclusion;
	float reverbocclusion = (float)jreverbocclusion;
	bool doublesided = (bool)(jdoublesided != 0);

	FMOD_RESULT result_ = (*(FMOD::Geometry **)&jPointer)->setPolygonAttributes(index, directocclusion, reverbocclusion, doublesided);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Geometry_1getPolygonAttributes(JNIEnv *jenv, jclass jcls, jlong jPointer, jint jindex, jobject jdirectocclusion, jlong jdirectocclusion_, jobject jreverbocclusion, jlong jreverbocclusion_, jobject jdoublesided, jlong jdoublesided_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_GEOMETRY);
		return 0;
	}
	int index = (int)jindex;
	float *directocclusion = 0;
	if(jdirectocclusion) {
		directocclusion = (float *)((char *)jenv->GetDirectBufferAddress(jdirectocclusion)+jdirectocclusion_);
	}
	float *reverbocclusion = 0;
	if(jreverbocclusion) {
		reverbocclusion = (float *)((char *)jenv->GetDirectBufferAddress(jreverbocclusion)+jreverbocclusion_);
	}
	bool *doublesided =  0;
	if(jdoublesided) {
		doublesided = (bool *)((char *)jenv->GetDirectBufferAddress(jdoublesided)+jdoublesided_);
	}

	FMOD_RESULT result_ = (*(FMOD::Geometry **)&jPointer)->getPolygonAttributes(index, directocclusion, reverbocclusion, doublesided);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Geometry_1setActive(JNIEnv *jenv, jclass jcls, jlong jPointer, jboolean jactive) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_GEOMETRY);
		return 0;
	}
	bool active = (bool)(jactive != 0);

	FMOD_RESULT result_ = (*(FMOD::Geometry **)&jPointer)->setActive(active);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Geometry_1getActive(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jactive, jlong jactive_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_GEOMETRY);
		return 0;
	}
	bool *active =  0;
	if(jactive) {
		active = (bool *)((char *)jenv->GetDirectBufferAddress(jactive)+jactive_);
	}

	FMOD_RESULT result_ = (*(FMOD::Geometry **)&jPointer)->getActive(active);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Geometry_1setRotation(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jforward, jlong jup) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_GEOMETRY);
		return 0;
	}
	FMOD_VECTOR *forward = *(FMOD_VECTOR **)&jforward;
	FMOD_VECTOR *up = *(FMOD_VECTOR **)&jup;

	FMOD_RESULT result_ = (*(FMOD::Geometry **)&jPointer)->setRotation(forward, up);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Geometry_1getRotation(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jforward, jlong jup) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_GEOMETRY);
		return 0;
	}
	FMOD_VECTOR *forward = *(FMOD_VECTOR **)&jforward;
	FMOD_VECTOR *up = *(FMOD_VECTOR **)&jup;

	FMOD_RESULT result_ = (*(FMOD::Geometry **)&jPointer)->getRotation(forward, up);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Geometry_1setPosition(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jposition) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_GEOMETRY);
		return 0;
	}
	FMOD_VECTOR *position = *(FMOD_VECTOR **)&jposition;

	FMOD_RESULT result_ = (*(FMOD::Geometry **)&jPointer)->setPosition(position);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Geometry_1getPosition(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jposition) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_GEOMETRY);
		return 0;
	}
	FMOD_VECTOR *position = *(FMOD_VECTOR **)&jposition;

	FMOD_RESULT result_ = (*(FMOD::Geometry **)&jPointer)->getPosition(position);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Geometry_1setScale(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jscale) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_GEOMETRY);
		return 0;
	}
	FMOD_VECTOR *scale = *(FMOD_VECTOR **)&jscale;

	FMOD_RESULT result_ = (*(FMOD::Geometry **)&jPointer)->setScale(scale);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Geometry_1getScale(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong jscale) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_GEOMETRY);
		return 0;
	}
	FMOD_VECTOR *scale = *(FMOD_VECTOR **)&jscale;

	FMOD_RESULT result_ = (*(FMOD::Geometry **)&jPointer)->getScale(scale);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Geometry_1save(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject jdata, jlong jdata_, jobject jdatasize, jlong jdatasize_) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_GEOMETRY);
		return 0;
	}
	void *data = 0;
	if(jdata) {
		data = (void *)((char *)jenv->GetDirectBufferAddress(jdata)+jdata_);
	}
	int *datasize = 0;
	if(jdatasize) {
		datasize = (int *)((char *)jenv->GetDirectBufferAddress(jdatasize)+jdatasize_);
	}

	FMOD_RESULT result_ = (*(FMOD::Geometry **)&jPointer)->save(data, datasize);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Geometry_1setUserData(JNIEnv *jenv, jclass jcls, jlong jPointer, jlong juserdata) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_GEOMETRY);
		return 0;
	}
	void *userdata = *(void **)&juserdata;

	FMOD_RESULT result_ = (*(FMOD::Geometry **)&jPointer)->setUserData(userdata);

	return (jint)result_;
}

JNIEXPORT jint JNICALL Java_org_jouvieje_FmodEx_FmodExJNI_Geometry_1getUserData(JNIEnv *jenv, jclass jcls, jlong jPointer, jobject juserdata) {
	if(!jPointer) {
		ThrowException(jenv, NullPointerException, NULL_GEOMETRY);
		return 0;
	}
	void *userdata;

	FMOD_RESULT result_ = (*(FMOD::Geometry **)&jPointer)->getUserData(&userdata);

	if(userdata && juserdata) {
		jlong newAddress;
		*(void **)&newAddress = userdata;
		setPointerAddress(jenv, juserdata, newAddress);
	}
	return (jint)result_;
}


